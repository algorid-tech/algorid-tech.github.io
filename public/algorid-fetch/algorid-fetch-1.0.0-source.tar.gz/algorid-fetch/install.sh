#!/usr/bin/env bash
# Algorid Fetch installer for Ubuntu 22.04 / 24.04 (and Debian-based distros).
# Installs per-user: no files outside $HOME except the apt packages.
#
#   ./install.sh               GUI + CLI + yt-dlp video grabbing
#   ./install.sh --no-media    skip yt-dlp
#   ./install.sh --autostart   start minimized in the tray at login
#   ./install.sh --headless    CLI/daemon only (servers, VPS), no Qt
set -euo pipefail

MEDIA=1; AUTOSTART=0; HEADLESS=0
for a in "$@"; do
  case "$a" in
    --no-media) MEDIA=0 ;;
    --autostart) AUTOSTART=1 ;;
    --headless) HEADLESS=1 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "unknown option: $a"; exit 1 ;;
  esac
done

SRC="$(cd "$(dirname "$0")" && pwd)"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
VENV="$DATA/algorid-fetch/venv"
BIN="$HOME/.local/bin"

echo "==> Installing system packages (sudo)"
PKGS="python3 python3-venv python3-pip"
if [ "$HEADLESS" = 0 ]; then
  # apt PyQt6 avoids a 70 MB wheel and matches the system Qt theme
  # Ubuntu 24.04+ has python3-pyqt6; 20.04/22.04 only python3-pyqt5
  if apt-cache show python3-pyqt6 >/dev/null 2>&1; then QT=python3-pyqt6; else QT=python3-pyqt5; fi
  PKGS="$PKGS $QT libxcb-cursor0"
fi
if command -v apt-get >/dev/null; then
  sudo apt-get update -qq
  sudo apt-get install -y -qq $PKGS
else
  echo "   apt not found; make sure these are installed: $PKGS"
fi

echo "==> Creating virtualenv at $VENV"
python3 -m venv --system-site-packages "$VENV"
"$VENV/bin/pip" install -q --upgrade pip
"$VENV/bin/pip" install -q "$SRC"
if [ "$HEADLESS" = 0 ] && ! "$VENV/bin/python" -c "import algorid_fetch.qt" 2>/dev/null; then
  echo "   system PyQt6 not usable, installing from PyPI"
  "$VENV/bin/pip" install -q "PyQt6>=6.2"
fi

mkdir -p "$BIN"
ln -sf "$VENV/bin/algorid-fetch" "$BIN/algorid-fetch"
ln -sf "$VENV/bin/algorid-fetch-native-host" "$BIN/algorid-fetch-native-host"
"$BIN/algorid-fetch" setup-browsers >/dev/null || true
[ "$MEDIA" = 1 ] && { "$BIN/algorid-fetch" update-ytdlp || echo "   yt-dlp download failed; retry later with: algorid-fetch update-ytdlp"; }

if [ "$HEADLESS" = 0 ]; then
  echo "==> Desktop integration"
  install -Dm644 "$SRC/algorid_fetch/icon.svg" "$DATA/icons/hicolor/scalable/apps/algorid-fetch.svg"
  mkdir -p "$DATA/applications"
  cat > "$DATA/applications/algorid-fetch.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Algorid Fetch
GenericName=Downloader
Comment=Fast, resumable multi-connection downloads
Exec=$BIN/algorid-fetch gui
Icon=algorid-fetch
Terminal=false
Categories=Network;FileTransfer;
Keywords=download;downloader;accelerator;resume;video;
StartupWMClass=algorid-fetch
EOF
  update-desktop-database "$DATA/applications" 2>/dev/null || true
  if [ "$AUTOSTART" = 1 ]; then
    mkdir -p "$HOME/.config/autostart"
    sed "s|Exec=.*|Exec=$BIN/algorid-fetch gui --minimized|" "$DATA/applications/algorid-fetch.desktop" \
      > "$HOME/.config/autostart/algorid-fetch.desktop"
    echo "   autostart enabled"
  fi
else
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/algorid-fetch.service" <<EOF
[Unit]
Description=Algorid Fetch download daemon
After=network-online.target

[Service]
ExecStart=$BIN/algorid-fetch daemon --resume
Restart=on-failure

[Install]
WantedBy=default.target
EOF
  echo "   daemon unit: systemctl --user enable --now algorid-fetch"
fi

TOKEN="$("$BIN/algorid-fetch" token)"
cat <<EOF

✔ Algorid Fetch installed.

  Launch:     Algorid Fetch from the app grid, or run: algorid-fetch
  Terminal:   algorid-fetch get <url> -c 16
  Browser:    chrome://extensions → Developer mode → Load unpacked → $SRC/extension
              then paste this token in the extension popup:

              $TOKEN

EOF
case ":$PATH:" in *":$BIN:"*) ;; *) echo "  Note: add $BIN to PATH (open a new terminal on Ubuntu)." ;; esac
