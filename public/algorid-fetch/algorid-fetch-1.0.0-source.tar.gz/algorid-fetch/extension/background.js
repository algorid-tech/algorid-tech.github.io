// Algorid Fetch browser integration. Runs as the MV3 service worker in Chromium
// browsers and as the background script in Firefox (same file for both).
//
// Flow for every download / video / context-menu request:
//   1. Is the desktop app running and connected?        -> hand the URL over
//   2. Installed but closed? Start it via the launcher   -> then hand over
//      (native messaging host "com.algorid.fetch", registered by the .deb)
//   3. Not installed? Let the browser download normally and offer setup.

const B = globalThis.browser ?? globalThis.chrome;   // Firefox: browser.*, Chromium: chrome.*
const HOST = "com.algorid.fetch";

const DEFAULTS = {
  enabled: true,
  token: "",
  port: 6812,
  minSizeKB: 0,           // ignore known-size files smaller than this
  skipExts: "html htm php asp aspx jsp json xml",
  installPromptAt: 0,     // last time the setup page was suggested
  installPromptOff: false,
};
const INSTALL_PROMPT_EVERY_MS = 3 * 24 * 3600 * 1000;

const getSettings = () => B.storage.local.get(DEFAULTS);
const apiUrl = (s, path) => `http://127.0.0.1:${s.port}${path}`;
const safe = async (p) => { try { return await p; } catch { return undefined; } };

async function ping(s) {
  try {
    const r = await fetch(apiUrl(s, "/ping"), {
      headers: { "X-Algorid-Token": s.token }, signal: AbortSignal.timeout(800),
    });
    const j = await r.json();
    return j.app === "algorid-fetch" ? j : null;
  } catch {
    return null;
  }
}

// ------------------------------------------------------------ native launcher
async function native(cmd) {
  try {
    const r = await B.runtime.sendNativeMessage(HOST, { cmd });
    return r || { ok: false, error: "no answer from launcher" };
  } catch (e) {
    const m = String((e && e.message) || e);
    const missing = /not found|no such native application|forbidden|not allowed|disconnected/i.test(m);
    return { ok: false, missing, error: m };
  }
}

async function adoptToken(r) {
  if (r && r.token) {
    const patch = { token: r.token };
    if (r.port) patch.port = r.port;
    await B.storage.local.set(patch);
    return true;
  }
  return false;
}

// One-click pairing fallback (no launcher, e.g. Snap Chromium): the app asks
// the user "Allow this extension?" and returns the token on Allow.
async function pair() {
  const s = await getSettings();
  let r;
  try {
    r = await fetch(apiUrl(s, "/pair"), { method: "POST", signal: AbortSignal.timeout(125000) });
  } catch {
    return { ok: false, error: "Algorid Fetch is not running." };
  }
  const j = await r.json().catch(() => ({}));
  if (r.ok && j.token) {
    await B.storage.local.set({ token: j.token });
    return { ok: true };
  }
  return { ok: false, error: j.error || `HTTP ${r.status}` };
}

// state: connected | running (not connected yet) | stopped (installed) | missing
async function appState() {
  let s = await getSettings();
  let alive = await ping(s);
  if (alive && alive.authorized) return { state: "connected", version: alive.version };
  const n = await native("status");
  if (n.ok && n.running && (await adoptToken(n))) {
    s = await getSettings();
    alive = await ping(s);
    if (alive && alive.authorized) return { state: "connected", version: alive.version };
  }
  if (alive) return { state: "running", version: alive.version, launcher: n.ok };
  if (n.ok) return { state: "stopped", version: n.version };
  return { state: "missing", error: n.error };
}

// Make the app ready to receive work: start it if needed, connect if needed.
async function ensureApp({ interactivePair = true } = {}) {
  const st = await appState();
  if (st.state === "connected") return { ok: true, ...st };
  if (st.state === "stopped") {
    const r = await native("launch");
    if (r.ok && r.running && (await adoptToken(r))) return { ok: true, state: "connected", launched: true };
    return { ok: false, state: "stopped", error: r.error || "Algorid Fetch could not be started." };
  }
  if (st.state === "running" && interactivePair) {
    const p = await pair();
    return p.ok ? { ok: true, state: "connected" } : { ok: false, state: "running", error: p.error };
  }
  return { ok: false, ...st };
}

async function maybeSuggestInstall(reason) {
  const s = await getSettings();
  if (s.installPromptOff || Date.now() - s.installPromptAt < INSTALL_PROMPT_EVERY_MS) return;
  await B.storage.local.set({ installPromptAt: Date.now() });
  openWelcome(reason);
}

async function openWelcome(reason = "") {
  const url = B.runtime.getURL(`welcome.html${reason ? "?reason=" + reason : ""}`);
  // Right after browser start-up there may be no window yet; retry briefly.
  for (let i = 0; i < 20; i++) {
    try {
      await B.tabs.create({ url });
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 500));
    }
  }
}

// ------------------------------------------------------------ talking to the app
async function cookiesFor(url) {
  let list = await safe(B.cookies.getAll({ url }));
  if (!list) list = (await safe(B.cookies.getAll({ url, firstPartyDomain: null }))) || []; // Firefox FPI
  // Full cookies (with domain/path) so the app can give yt-dlp a real cookie
  // jar: Drive/YouTube fetch from several *.google.com hosts.
  return list.map((c) => ({
    name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure,
    hostOnly: c.hostOnly, expirationDate: c.expirationDate,
  }));
}

async function send(payload) {
  const s = await getSettings();
  const r = await fetch(apiUrl(s, "/add"), {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Algorid-Token": s.token },
    body: JSON.stringify({ user_agent: navigator.userAgent, cookies: await cookiesFor(payload.url), ...payload }),
  });
  if (r.status === 401) throw new Error("token");
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

function notify(message) {
  safe(B.notifications.create({ type: "basic", iconUrl: "icons/icon48.png", title: "Algorid Fetch", message }));
}

function describe(r) {
  if (r.state === "missing") return "Algorid Fetch is not installed. Open the extension to set it up.";
  if (r.state === "running") return "Not connected. Click Allow in Algorid Fetch, or press Connect in the extension.";
  return r.error || "Algorid Fetch is not available.";
}

const MEDIA_HOST_RE = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|vimeo\.com|dailymotion\.com)$/i;

// Video button (content.js) -> app.
async function grab(msg, sender) {
  // A player inside an iframe (Google Drive, embedded players on blogs) reports
  // the frame's URL; yt-dlp understands the page you are looking at better,
  // unless the frame itself is a known video host (e.g. a YouTube embed).
  if (msg.media && sender && sender.frameId !== 0 && sender.tab && sender.tab.url) {
    let host = "";
    try { host = new URL(msg.url).hostname; } catch {}
    if (!MEDIA_HOST_RE.test(host)) msg = { ...msg, url: sender.tab.url, referrer: sender.tab.url };
  }
  const ready = await ensureApp();
  if (!ready.ok) {
    if (ready.state === "missing") openWelcome("video");
    return { ok: false, error: describe(ready) };
  }
  try {
    await send({ url: msg.url, referrer: msg.referrer, media: !!msg.media, quality: msg.quality, ask: true });
    return { ok: true, launched: !!ready.launched };
  } catch (e) {
    return { ok: false, error: e.message === "token" ? describe({ state: "running" }) : e.message };
  }
}

B.runtime.onMessage.addListener((msg, sender, reply) => {
  const handlers = {
    grab: () => grab(msg, sender),
    pair: () => pair(),
    state: () => appState(),
    start: () => ensureApp(),
    welcome: async () => { openWelcome(msg.reason); return { ok: true }; },
    installPromptOff: async () => { await B.storage.local.set({ installPromptOff: !!msg.value }); return { ok: true }; },
  };
  const h = msg && handlers[msg.type];
  if (!h) return false;
  h().then(reply, (e) => reply({ ok: false, error: String(e) }));
  return true; // async reply
});

// ------------------------------------------------------------ catching downloads
function extOf(name) {
  const base = (name || "").split(/[?#]/)[0].split(/[\\/]/).pop();
  const i = base.lastIndexOf(".");
  return i > 0 ? base.slice(i + 1).toLowerCase() : "";
}

const passthrough = new Set();   // downloads handed back to the browser

B.downloads.onCreated.addListener(async (item) => {
  const url = item.finalUrl || item.url;
  if (!/^https?:/i.test(url)) return;                 // blob:, data:, file:
  if (item.byExtensionId && item.byExtensionId === B.runtime.id) return;
  if (passthrough.delete(url)) return;
  if (item.state && item.state !== "in_progress") return;

  const s = await getSettings();
  if (!s.enabled) return;
  const size = item.totalBytes > 0 ? item.totalBytes : item.fileSize;
  if (size > 0 && size < s.minSizeKB * 1024) return;
  if (s.skipExts.split(/\s+/).includes(extOf(item.filename || url))) return;

  let st = await appState();
  if (st.state === "missing") {                       // keep the browser download, offer setup
    maybeSuggestInstall("download");
    return;
  }
  if (st.state !== "connected") {
    // Hold the browser's copy while the app starts / connects.
    await safe(B.downloads.pause(item.id));
    st = await ensureApp();
    if (!st.ok) {
      await safe(B.downloads.resume(item.id));
      notify(`${describe(st)} Downloading in the browser instead.`);
      return;
    }
  }
  try {
    await B.downloads.cancel(item.id);
  } catch {
    return;                                           // already finished in the browser
  }
  await safe(B.downloads.erase({ id: item.id }));
  try {
    await send({
      url,
      referrer: item.referrer || "",
      filename: (item.filename || "").split(/[\\/]/).pop() || null,
      ask: true,
    });
  } catch (e) {
    notify("Could not reach Algorid Fetch; downloading in the browser instead.");
    passthrough.add(url);
    B.downloads.download({ url });
  }
});

// ------------------------------------------------------------ install & menus
B.runtime.onInstalled.addListener(async (details) => {
  const removed = B.contextMenus.removeAll();
  if (removed && removed.then) await safe(removed);
  B.contextMenus.create({ id: "af-link", title: "Fetch link with Algorid Fetch", contexts: ["link", "video", "audio", "image"] });
  B.contextMenus.create({ id: "af-media", title: "Fetch video from this page", contexts: ["page", "video"] });
  B.contextMenus.create({ id: "af-all", title: "Fetch all links in selection", contexts: ["selection"] });

  if (details.reason !== "install") return;
  const st = await appState();                         // connects silently via the launcher
  if (st.state === "connected") {
    notify("Connected to Algorid Fetch. Browser downloads will open in the app.");
  } else if (st.state === "running") {
    const p = await pair();
    if (p.ok) notify("Connected to Algorid Fetch.");
  } else if (st.state === "missing") {
    openWelcome("install");
  }
  // "stopped": nothing to do now; the app starts on the first download.
});

B.contextMenus.onClicked.addListener(async (info, tab) => {
  const ready = await ensureApp();
  if (!ready.ok) {
    if (ready.state === "missing") openWelcome("menu");
    else notify(describe(ready));
    return;
  }
  try {
    if (info.menuItemId === "af-link") {
      await send({ url: info.linkUrl || info.srcUrl, referrer: info.pageUrl, ask: true });
    } else if (info.menuItemId === "af-media") {
      await send({ url: info.pageUrl || tab.url, referrer: info.pageUrl, media: true, ask: true });
    } else if (info.menuItemId === "af-all") {
      const [res] = await B.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const sel = getSelection();
          if (!sel.rangeCount) return [];
          const frag = sel.getRangeAt(0).cloneContents();
          return [...frag.querySelectorAll("a[href]")].map((a) => a.href);
        },
      });
      const links = (res && res.result) || [];
      const urls = [...new Set(links)].filter((u) => /^https?:/i.test(u));
      for (const url of urls) await send({ url, referrer: info.pageUrl });
      notify(`Queued ${urls.length} link(s) in Algorid Fetch.`);
    }
  } catch (e) {
    notify(e.message === "token" ? describe({ state: "running" }) : `Failed: ${e.message}`);
  }
});
