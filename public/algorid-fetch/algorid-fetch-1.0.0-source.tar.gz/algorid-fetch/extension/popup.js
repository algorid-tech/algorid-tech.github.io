const B = globalThis.browser ?? globalThis.chrome;
// Connection details (token and port) are never shown or edited here: the
// background script gets both from the app automatically.
const DEFAULTS = { enabled: true, showVideoButton: true, minSizeKB: 0,
                   skipExts: "html htm php asp aspx jsp json xml" };
const $ = (id) => document.getElementById(id);
const ask = (msg) => B.runtime.sendMessage(msg);

// What the single action button does in each app state.
const ACTIONS = {
  running: { label: "Connect to Algorid Fetch", type: "pair",
             hint: "Click Allow in Algorid Fetch. This popup may close; reopen it to see the green dot." },
  stopped: { label: "Start Algorid Fetch", type: "start",
             hint: "Algorid Fetch also starts by itself when you download something." },
  missing: { label: "Install Algorid Fetch", type: "welcome",
             hint: "The desktop app is needed for fast downloads. Until then the browser downloads normally." },
};

function show(st) {
  const dot = $("dot"), txt = $("stxt");
  const text = {
    connected: `Connected to Algorid Fetch ${st.version || ""}`,
    running: "Algorid Fetch is running but not connected yet",
    stopped: "Algorid Fetch is installed but closed",
    missing: "Algorid Fetch is not installed on this computer",
  }[st.state] || "Checking…";
  dot.className = "dot " + ({ connected: "ok", running: "warn", stopped: "warn", missing: "bad" }[st.state] || "");
  txt.textContent = text;
  const a = ACTIONS[st.state];
  $("connectBox").hidden = !a;
  if (a) {
    $("action").textContent = a.label;
    $("action").dataset.type = a.type;
    $("actionHint").textContent = a.hint;
  }
}

async function refresh() {
  show(await ask({ type: "state" }));
}

async function load() {
  const s = await B.storage.local.get(DEFAULTS);
  $("enabled").checked = s.enabled;
  $("showVideoButton").checked = s.showVideoButton;
  $("minSizeKB").value = s.minSizeKB;
  $("skipExts").value = s.skipExts;
  refresh();
}

$("action").addEventListener("click", async () => {
  const type = $("action").dataset.type;
  if (type === "welcome") { await ask({ type: "welcome", reason: "popup" }); window.close(); return; }
  $("action").disabled = true;
  $("action").textContent = type === "start" ? "Starting Algorid Fetch…" : "Waiting for you to click Allow…";
  const res = await ask({ type });
  $("action").disabled = false;
  if (res && !res.ok && res.error) $("actionHint").textContent = res.error;
  refresh();
});

$("enabled").addEventListener("change", () => B.storage.local.set({ enabled: $("enabled").checked }));
$("showVideoButton").addEventListener("change", () => B.storage.local.set({ showVideoButton: $("showVideoButton").checked }));

$("save").addEventListener("click", async () => {
  await B.storage.local.set({
    enabled: $("enabled").checked,
    showVideoButton: $("showVideoButton").checked,
    minSizeKB: parseInt($("minSizeKB").value, 10) || 0,
    skipExts: $("skipExts").value.trim(),
  });
  $("save").textContent = "Saved ✓";
  setTimeout(() => ($("save").textContent = "Save"), 1200);
  refresh();
});

load();
