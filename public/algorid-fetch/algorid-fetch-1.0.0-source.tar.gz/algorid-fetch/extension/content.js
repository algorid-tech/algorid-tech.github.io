// Algorid Fetch: "Fetch video" button over playing/hovered videos.
// Runs in every frame. UI lives in a closed shadow root so page CSS can't touch it.
(() => {
  if (window.__algoridFetchButton) return;
  window.__algoridFetchButton = true;

  const MIN_W = 200, MIN_H = 120;
  const QUALITIES = [
    ["best", "Best quality"], ["1080", "1080p"], ["720", "720p"],
    ["480", "480p"], ["360", "360p"], ["audio", "Audio only"],
  ];
  const MEDIA_HOSTS = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|vimeo\.com|facebook\.com|fb\.watch|x\.com|twitter\.com|tiktok\.com|instagram\.com|dailymotion\.com|twitch\.tv|bilibili\.com|reddit\.com|soundcloud\.com)$/i;

  let enabled = true;
  let dismissed = false;
  let target = null;          // video currently decorated
  let hideTimer = 0;

  chrome.storage.local.get({ showVideoButton: true }, (s) => { enabled = s.showVideoButton; });
  chrome.storage.onChanged.addListener((c) => {
    if (c.showVideoButton) { enabled = c.showVideoButton.newValue; if (!enabled) hide(); }
  });

  // ---------------------------------------------------------------- UI
  const host = document.createElement("algorid-fetch-button");
  host.style.cssText = "all: initial; position: fixed; z-index: 2147483647; top: 0; left: 0; display: none;";
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      .wrap { font: 600 13px/1 system-ui, sans-serif; display: flex; flex-direction: column; align-items: flex-end; gap: 4px; }
      .pill { display: flex; align-items: stretch; border-radius: 18px; overflow: hidden;
              box-shadow: 0 2px 10px rgba(0,0,0,.35); background: #0e7490; color: #fff; user-select: none; }
      .pill button { all: unset; cursor: pointer; padding: 8px 12px; display: flex; align-items: center; gap: 6px; color: #fff; }
      .pill button:hover { background: rgba(255,255,255,.15); }
      .pill .x { padding: 8px 10px; border-left: 1px solid rgba(255,255,255,.25); opacity: .85; }
      svg { width: 15px; height: 15px; }
      .menu { display: none; background: #1f2937; color: #f9fafb; border-radius: 10px; padding: 4px; min-width: 150px;
              box-shadow: 0 6px 20px rgba(0,0,0,.45); }
      .menu.open { display: block; }
      .menu button { all: unset; display: block; width: 100%; box-sizing: border-box; padding: 8px 12px; border-radius: 6px;
                     cursor: pointer; font: 500 13px system-ui, sans-serif; color: #f9fafb; }
      .menu button:hover { background: #0e7490; }
      .toast { background: #111827; color: #fff; padding: 7px 11px; border-radius: 8px; font: 500 12px system-ui, sans-serif;
               box-shadow: 0 2px 10px rgba(0,0,0,.35); display: none; max-width: 280px; }
    </style>
    <div class="wrap">
      <div class="pill">
        <button class="dl" title="Fetch with Algorid Fetch">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 3v12M6 11l6 6 6-6M5 21h14"/></svg>
          <span class="label">Fetch video</span>
        </button>
        <button class="x" title="Hide on this page">✕</button>
      </div>
      <div class="menu"></div>
      <div class="toast"></div>
    </div>`;
  const $ = (sel) => root.querySelector(sel);
  const menu = $(".menu");
  for (const [key, label] of QUALITIES) {
    const b = document.createElement("button");
    b.textContent = label;
    b.dataset.q = key;
    menu.appendChild(b);
  }

  function mount() {
    const parent = document.fullscreenElement || document.documentElement;
    if (parent && host.parentNode !== parent) parent.appendChild(host);
  }

  // ---------------------------------------------------------------- logic
  function isStreamingPage() {
    return MEDIA_HOSTS.test(location.hostname);
  }

  function directSrc(v) {
    const src = v.currentSrc || v.src || "";
    return /^https?:/i.test(src) ? src : "";  // blob:/MSE streams need yt-dlp
  }

  function useMedia(v) {
    return isStreamingPage() || !directSrc(v);
  }

  function grab(quality) {
    const v = target;
    menu.classList.remove("open");
    if (!v) return;
    const media = useMedia(v);
    chrome.runtime.sendMessage({
      type: "grab",
      url: media ? location.href : directSrc(v),
      referrer: location.href,
      media,
      quality: media ? quality : null,
      title: document.title,
    }, (res) => {
      if (chrome.runtime.lastError) return toast("Algorid Fetch extension was updated, reload this page.");
      toast(res && res.ok ? "Sent to Algorid Fetch" : (res && res.error) || "Algorid Fetch is not running");
    });
  }

  function toast(msg) {
    const t = $(".toast");
    t.textContent = msg;
    t.style.display = "block";
    clearTimeout(t._h);
    t._h = setTimeout(() => (t.style.display = "none"), 3500);
  }

  // Sites like Google Drive and YouTube install capture-phase click handlers on
  // window that swallow clicks before they reach page elements. This script runs
  // at document_start, so its window capture listeners are registered first:
  // it claims events aimed at the button and hides them from the page.
  function ourButton(e) {
    if (host.style.display !== "block" || !e.composedPath().includes(host)) return null;
    const el = root.elementFromPoint(e.clientX, e.clientY);
    return (el && el.closest("button")) || root.querySelector(".dl");
  }
  function activate(btn) {
    if (btn.classList.contains("x")) { dismissed = true; hide(); return; }
    if (btn.dataset.q) { grab(btn.dataset.q); return; }
    if (target && useMedia(target)) menu.classList.toggle("open");
    else grab(null);
  }
  for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click", "dblclick", "contextmenu"]) {
    addEventListener(type, (e) => {
      const btn = ourButton(e);
      if (!btn) return;
      e.stopImmediatePropagation();
      e.preventDefault();
      if (type === "click") activate(btn);
    }, true);
  }
  root.addEventListener("mouseenter", () => clearTimeout(hideTimer), true);
  host.addEventListener("mouseleave", () => scheduleHide(1200));

  function visibleVideo(v) {
    const r = v.getBoundingClientRect();
    return r.width >= MIN_W && r.height >= MIN_H && r.bottom > 0 && r.right > 0 &&
           r.top < innerHeight && r.left < innerWidth;
  }

  function place() {
    if (!target || !target.isConnected || !visibleVideo(target)) return hide();
    const r = target.getBoundingClientRect();
    const top = Math.max(8, r.top + 10);
    const right = Math.min(innerWidth - 8, r.right - 10);
    host.style.transform = `translate(${Math.round(right)}px, ${Math.round(top)}px) translateX(-100%)`;
    $(".label").textContent = useMedia(target) ? "Fetch video ▾" : "Fetch video";
  }

  function show(v) {
    if (!enabled || dismissed) return;
    target = v;
    mount();
    host.style.display = "block";
    place();
    clearTimeout(hideTimer);
  }

  function hide() {
    host.style.display = "none";
    menu.classList.remove("open");
  }

  function scheduleHide(ms) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (!menu.classList.contains("open")) hide(); }, ms);
  }

  function videoAt(x, y) {
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && visibleVideo(v)) return v;
    }
    return null;
  }

  // Show on hover over a video, and for a few seconds when one starts playing.
  let lastMove = 0;
  document.addEventListener("mousemove", (e) => {
    const now = performance.now();
    if (now - lastMove < 120) return;
    lastMove = now;
    const v = videoAt(e.clientX, e.clientY);
    if (v) { show(v); scheduleHide(3000); }
  }, { passive: true, capture: true });

  document.addEventListener("play", (e) => {
    if (e.target instanceof HTMLVideoElement && visibleVideo(e.target)) {
      show(e.target);
      scheduleHide(5000);
    }
  }, true);

  addEventListener("scroll", () => host.style.display === "block" && place(), { passive: true, capture: true });
  addEventListener("resize", () => host.style.display === "block" && place(), { passive: true });
  document.addEventListener("fullscreenchange", () => { mount(); if (target) show(target); scheduleHide(3000); });
  document.addEventListener("click", () => menu.classList.remove("open"));

  // YouTube and other SPAs swap pages without reloading: re-arm on navigation.
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) { lastUrl = location.href; dismissed = false; hide(); }
  }, 1000);
})();
