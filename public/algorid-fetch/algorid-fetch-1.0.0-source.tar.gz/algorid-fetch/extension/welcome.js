const B = globalThis.browser ?? globalThis.chrome;

// Where the .deb is published. Each GitHub release should include a file named
// exactly "algorid-fetch_all.deb" so this link always points to the newest one.
const RELEASES = "https://github.com/gmostafa1210/algorid-fetch/releases/latest";
const DEB_URL = `${RELEASES}/download/algorid-fetch_all.deb`;
const EXE_URL = `${RELEASES}/download/algorid-fetch-setup.exe`;
const IS_WINDOWS = /Windows/i.test(navigator.userAgent);

const $ = (id) => document.getElementById(id);
$("relLink").href = RELEASES;
if (IS_WINDOWS) {
  $("dlTitle").textContent = "Download the app for Windows";
  $("debLink").textContent = "Download for Windows (.exe)";
  $("debLink").href = EXE_URL;
  $("dlNote").textContent = "Windows 10 or 11, 64-bit.";
  $("linuxSteps").hidden = true;
  $("winSteps").hidden = false;
} else {
  $("debLink").href = DEB_URL;
}

const reason = new URLSearchParams(location.search).get("reason");
const notes = {
  download: "Your download is continuing in the browser. Install the app to make future downloads faster and resumable.",
  video: "Saving videos needs the Algorid Fetch app.",
  menu: "That action needs the Algorid Fetch app.",
};
if (notes[reason]) {
  $("reasonNote").textContent = notes[reason];
  $("reasonNote").hidden = false;
}

$("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText($("cmd").textContent);
  $("copy").textContent = "Copied";
  setTimeout(() => ($("copy").textContent = "Copy"), 1500);
});

B.storage.local.get({ installPromptOff: false }).then((s) => { $("off").checked = s.installPromptOff; });
$("off").addEventListener("change", () => B.runtime.sendMessage({ type: "installPromptOff", value: $("off").checked }));

const TEXT = {
  missing: ["bad", "Waiting for the app to be installed…", "This page updates by itself once the app is installed."],
  stopped: ["warn", "Installed. Connecting…", ""],
  running: ["warn", "Algorid Fetch is running. Click Allow in the app to connect.", ""],
  connected: ["ok", "All set. Algorid Fetch is connected.", "From now on, downloads and videos open in Algorid Fetch. You can close this tab."],
};

let busy = false;
async function poll() {
  if (busy) return;
  busy = true;
  try {
    let st = await B.runtime.sendMessage({ type: "state" });
    if (st.state === "stopped") st = (await B.runtime.sendMessage({ type: "start" })).ok ? { state: "connected" } : st;
    const [cls, text, hint] = TEXT[st.state] || TEXT.missing;
    $("dot").className = "dot " + cls;
    $("stxt").textContent = text;
    $("nextHint").textContent = hint;
  } finally {
    busy = false;
  }
}
poll();
setInterval(poll, 3000);
