"""Browser launcher: algorid-fetch-native-host.exe (native messaging, stdio)"""
import sys

from algorid_fetch.native_host import main

sys.exit(main())
