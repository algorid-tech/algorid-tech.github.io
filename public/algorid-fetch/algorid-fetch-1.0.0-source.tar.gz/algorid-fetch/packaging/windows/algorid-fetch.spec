# PyInstaller spec: one folder, three programs sharing the same libraries.
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, "..", ".."))
HERE = SPECPATH
ICON = os.path.join(HERE, "algorid-fetch.ico")
VERSION = os.path.join(HERE, "version_info.txt")
DATAS = [(os.path.join(ROOT, "algorid_fetch", "icon.svg"), "algorid_fetch"),
         (os.path.join(ROOT, "algorid_fetch", "icon.png"), "algorid_fetch")]
# The app only uses widgets; keep the folder small.
EXCLUDES = ["tkinter", "unittest", "pydoc", "PyQt6.QtQml", "PyQt6.QtQuick", "PyQt6.QtNetwork",
            "PyQt6.QtWebEngineCore", "PyQt6.QtMultimedia", "PyQt6.QtPdf", "PyQt6.Qt3DCore", "PyQt5"]
HIDDEN = ["algorid_fetch.gui", "algorid_fetch.qt", "PyQt6.QtSvg"]


def analysis(script):
    return Analysis([os.path.join(HERE, script)], pathex=[ROOT], datas=DATAS, hiddenimports=HIDDEN,
                    excludes=EXCLUDES, noarchive=False)


a_gui, a_cli, a_nat = analysis("af_gui.py"), analysis("af_cli.py"), analysis("af_native.py")


def exe(a, name, console):
    return EXE(PYZ(a.pure), a.scripts, [], exclude_binaries=True, name=name, console=console,
               icon=ICON, version=VERSION, upx=False)


coll = COLLECT(
    exe(a_gui, "Algorid Fetch", console=False),
    exe(a_cli, "algorid-fetch", console=True),
    exe(a_nat, "algorid-fetch-native-host", console=True),
    a_gui.binaries, a_gui.datas, a_cli.binaries, a_cli.datas, a_nat.binaries, a_nat.datas,
    name="Algorid Fetch", upx=False)
