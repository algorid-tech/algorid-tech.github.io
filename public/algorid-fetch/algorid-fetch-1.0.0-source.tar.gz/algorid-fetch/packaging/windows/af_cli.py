"""Console entry point: algorid-fetch.exe (get / add / list / daemon / setup-browsers ...)"""
import sys

from algorid_fetch.cli import main

sys.exit(main())
