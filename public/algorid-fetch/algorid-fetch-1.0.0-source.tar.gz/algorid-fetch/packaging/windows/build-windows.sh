#!/usr/bin/env bash
# Build the Windows installer on Linux: Windows Python + PyInstaller run in Wine,
# NSIS (makensis) packs the installer. Output: dist/AlgoridFetch-Setup-<ver>.exe
# and dist/algorid-fetch-setup.exe (version-free name for GitHub releases).
#
# One-time setup (Ubuntu): sudo apt install wine64 nsis
#   WIN_PY_URL below is the standalone CPython for Windows (python-build-standalone);
#   the script installs PyInstaller + PyQt6 into it on first run.
#
# Note: Qt 6.7+ needs Windows' icu.dll, which Wine lacks, so the build pins
# PyQt6 6.6 (Qt 6.6, supports Windows 10 1809+ and Windows 11).
set -euo pipefail
cd "$(dirname "$0")/../.."
ROOT="$PWD"
VER=$(sed -n 's/^version = "\(.*\)"/\1/p' pyproject.toml)
WORK="${WIN_BUILD_DIR:-$HOME/.cache/algorid-fetch-win}"
PREFIX="$WORK/prefix"
WIN_PY_URL="https://github.com/astral-sh/python-build-standalone/releases/download/20250604/cpython-3.12.11+20250604-x86_64-pc-windows-msvc-install_only.tar.gz"

# Wine misbehaves with some glibc malloc tuning variables; run it with a clean env.
w() { env -i HOME="$WORK/home" PATH=/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8 WINEPREFIX="$PREFIX" \
        WINEDEBUG=-all WINEARCH=win64 PYTHONUTF8=1 wine "$@" 2>&1 | cat; }
winpath() { echo "Z:$(echo "$1" | sed 's#/#\\#g')"; }

mkdir -p "$WORK/home"
if [ ! -x "$PREFIX/drive_c/py/python.exe" ]; then
  echo "==> preparing Windows Python in $PREFIX"
  w cmd /c ver >/dev/null
  curl -fsSL "$WIN_PY_URL" -o "$WORK/winpy.tar.gz"
  tar xzf "$WORK/winpy.tar.gz" -C "$PREFIX/drive_c/"
  mv "$PREFIX/drive_c/python" "$PREFIX/drive_c/py"
  w 'C:\py\python.exe' -m pip install -q "pyinstaller>=6.10" "pyqt6==6.6.1" "pyqt6-qt6==6.6.3"
fi

echo "==> building executables (PyInstaller in Wine)"
rm -rf "$WORK/build" "$WORK/dist"
w 'C:\py\python.exe' -m PyInstaller --noconfirm --clean --log-level ERROR \
  --distpath "$(winpath "$WORK/dist")" --workpath "$(winpath "$WORK/build")" \
  "$(winpath "$ROOT/packaging/windows/algorid-fetch.spec")"
DISTDIR="$WORK/dist/Algorid Fetch"
[ -f "$DISTDIR/Algorid Fetch.exe" ] || { echo "PyInstaller build failed"; exit 1; }

echo "==> packing installer (NSIS)"
mkdir -p dist
SIZE_KB=$(du -sk "$DISTDIR" | cut -f1)
makensis -V2 -DVERSION="$VER" -DROOT="$ROOT" -DHERE="$ROOT/packaging/windows" -DDISTDIR="$DISTDIR" \
  -DSIZE_KB="$SIZE_KB" -DOUTFILE="$ROOT/dist/AlgoridFetch-Setup-$VER.exe" packaging/windows/installer.nsi
cp "dist/AlgoridFetch-Setup-$VER.exe" dist/algorid-fetch-setup.exe
echo "built: dist/AlgoridFetch-Setup-$VER.exe (+ dist/algorid-fetch-setup.exe for releases)"
