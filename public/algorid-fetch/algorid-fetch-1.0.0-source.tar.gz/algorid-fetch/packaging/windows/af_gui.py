"""Windowed entry point: Algorid Fetch.exe"""
import sys

from algorid_fetch.cli import main

sys.exit(main(sys.argv[1:] or ["gui"]))
