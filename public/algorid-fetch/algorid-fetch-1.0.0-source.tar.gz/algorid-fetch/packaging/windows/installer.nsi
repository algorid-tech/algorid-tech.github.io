; Algorid Fetch installer for Windows 10 and 11 (64-bit). Per-user: no admin needed.
; Built by packaging/windows/build-windows.sh with makensis (NSIS 3).
Unicode true
Target amd64-unicode  ; 64-bit installer (the app itself needs 64-bit Windows)
!ifndef VERSION
  !define VERSION "1.0.0"
!endif
!define APPNAME "Algorid Fetch"
!define PUBLISHER "Algorid"
!define EXE "Algorid Fetch.exe"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\AlgoridFetch"
!define HOST "com.algorid.fetch"

Name "${APPNAME}"
OutFile "${OUTFILE}"
InstallDir "$LOCALAPPDATA\Programs\Algorid Fetch"
InstallDirRegKey HKCU "Software\Algorid\Fetch" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "${APPNAME} ${VERSION}"

VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "FileDescription" "${APPNAME} Setup"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"
VIAddVersionKey "LegalCopyright" "Copyright (c) 2026 Golam Mostafa. MIT License."

!include "MUI2.nsh"
!include "WinVer.nsh"
!include "x64.nsh"

!define MUI_ICON "${HERE}\algorid-fetch.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "${HERE}\wizard.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "${HERE}\wizard.bmp"
!define MUI_UNICON "${HERE}\algorid-fetch.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Welcome to ${APPNAME}"
!define MUI_WELCOMEPAGE_TEXT "Fast, resumable downloads for Windows.$\r$\n$\r$\nAlgorid Fetch splits each file across several connections, continues after pauses and restarts, and works with your browser through a small extension.$\r$\n$\r$\nClick Next to continue."
!define MUI_COMPONENTSPAGE_SMALLDESC
!define MUI_FINISHPAGE_RUN "$INSTDIR\${EXE}"
!define MUI_FINISHPAGE_RUN_PARAMETERS "gui --welcome"
!define MUI_FINISHPAGE_RUN_TEXT "Start Algorid Fetch and connect my browser"
!define MUI_FINISHPAGE_TEXT "${APPNAME} is installed and ready."

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_ICONSTOP "${APPNAME} needs Windows 10 or newer." /SD IDOK
    Abort
  ${EndIf}
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "${APPNAME} needs 64-bit Windows." /SD IDOK
    Abort
  ${EndIf}
FunctionEnd

Section "${APPNAME}" SecCore
  SectionIn RO
  ; Close a running copy so its files can be replaced (upgrade / reinstall).
  nsExec::Exec 'taskkill /F /IM "${EXE}"'
  nsExec::Exec 'taskkill /F /IM "algorid-fetch-native-host.exe"'
  Sleep 500
  SetOutPath "$INSTDIR"
  File /r "${DISTDIR}\*.*"
  File "/oname=LICENSE.txt" "${ROOT}\LICENSE"
  SetOutPath "$INSTDIR\extension"
  File /r "${ROOT}\extension\*.*"
  SetOutPath "$INSTDIR"

  CreateShortcut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0
  ; Let browser extensions start the app (native messaging, per user).
  nsExec::Exec '"$INSTDIR\algorid-fetch.exe" setup-browsers'

  WriteRegStr HKCU "Software\Algorid\Fetch" "InstallDir" "$INSTDIR"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINSTKEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\${EXE}"
  WriteRegStr HKCU "${UNINSTKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "${UNINSTKEY}" "QuietUninstallString" '"$INSTDIR\Uninstall.exe" /S'
  WriteRegStr HKCU "${UNINSTKEY}" "URLInfoAbout" "https://github.com/gmostafa1210/algorid-fetch"
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "EstimatedSize" ${SIZE_KB}
SectionEnd

Section "Desktop shortcut" SecDesktop
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0
SectionEnd

Section /o "Start with Windows (in the system tray)" SecAutostart
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${APPNAME}" '"$INSTDIR\${EXE}" gui --minimized'
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecCore} "The app, the command-line tool and the browser launcher."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "Put an Algorid Fetch icon on the desktop."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecAutostart} "Start minimized when you sign in. Not required: the browser extension starts the app when needed."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Section "Uninstall"
  nsExec::Exec 'taskkill /F /IM "${EXE}"'
  nsExec::Exec 'taskkill /F /IM "algorid-fetch-native-host.exe"'
  Sleep 500
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  Delete "$DESKTOP\${APPNAME}.lnk"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${APPNAME}"
  DeleteRegKey HKCU "Software\Google\Chrome\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\Chromium\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\Microsoft\Edge\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\Vivaldi\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\Mozilla\NativeMessagingHosts\${HOST}"
  DeleteRegKey HKCU "Software\Algorid\Fetch"
  DeleteRegKey /ifempty HKCU "Software\Algorid"
  DeleteRegKey HKCU "${UNINSTKEY}"
  RMDir /r "$INSTDIR"
  ; Settings, history and downloaded files are kept (AppData and Downloads).
SectionEnd
