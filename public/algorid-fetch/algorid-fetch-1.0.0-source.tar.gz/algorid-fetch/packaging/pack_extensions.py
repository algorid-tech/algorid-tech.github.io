"""Package the browser extension for Chromium browsers and for Firefox.

Both builds share every file; only manifest.json differs:
  * Chromium: service worker background, fixed "key" (stable extension ID).
  * Firefox:  background script, gecko ID, options_ui, no "key".
usage: python3 packaging/pack_extensions.py <version> <out_dir>
"""
import json
import os
import sys
import zipfile

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "extension")
FIREFOX_ID = "fetch@algorid"   # must match FIREFOX_EXTENSION_IDS in algorid_fetch/browsers.py


def firefox_manifest(m: dict) -> dict:
    f = {k: v for k, v in m.items() if k not in ("key", "background", "options_page")}
    f["background"] = {"scripts": ["background.js"]}
    f["options_ui"] = {"page": "popup.html", "open_in_tab": False}
    f["browser_specific_settings"] = {
        "gecko": {
            "id": FIREFOX_ID,
            "strict_min_version": "140.0",
            # Firefox requires extensions to declare data collection; this one
            # sends nothing anywhere except the app on 127.0.0.1.
            "data_collection_permissions": {"required": ["none"]},
        },
        "gecko_android": {"strict_min_version": "142.0"},
    }
    return f


def pack(out_path: str, manifest: dict) -> None:
    if os.path.exists(out_path):
        os.remove(out_path)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
        for d, _, files in os.walk(SRC):
            for name in sorted(files):
                full = os.path.join(d, name)
                rel = os.path.relpath(full, SRC)
                if rel != "manifest.json":
                    z.write(full, rel)


def main() -> None:
    version, out = sys.argv[1], sys.argv[2]
    with open(os.path.join(SRC, "manifest.json")) as f:
        m = json.load(f)
    m["version"] = version
    pack(os.path.join(out, f"algorid-fetch-chrome-extension-{version}.zip"), m)
    pack(os.path.join(out, f"algorid-fetch-firefox-{version}.xpi"), firefox_manifest(m))


if __name__ == "__main__":
    main()
