#!/usr/bin/env bash
# Builds dist/algorid-fetch_<ver>_all.deb and dist/algorid-fetch-chrome-extension-<ver>.zip
#   packaging/build-deb.sh
set -euo pipefail
cd "$(dirname "$0")/.."
VER=$(sed -n 's/^version = "\(.*\)"/\1/p' pyproject.toml)
PKG=algorid-fetch
OUT=dist
ROOT=$(mktemp -d)/${PKG}_${VER}_all
trap 'rm -rf "$(dirname "$ROOT")"' EXIT

# --- program files (pure Python, works with any Ubuntu python3 >= 3.10)
install -d "$ROOT/usr/lib/python3/dist-packages/algorid_fetch"
install -m644 algorid_fetch/*.py algorid_fetch/icon.svg algorid_fetch/icon.png "$ROOT/usr/lib/python3/dist-packages/algorid_fetch/"

install -d "$ROOT/usr/bin"
cat > "$ROOT/usr/bin/algorid-fetch" <<'EOF'
#!/usr/bin/python3
import sys
from algorid_fetch.cli import main
sys.exit(main())
EOF
chmod 755 "$ROOT/usr/bin/algorid-fetch"

cat > "$ROOT/usr/bin/algorid-fetch-native-host" <<'HOSTEOF'
#!/usr/bin/python3
import sys
from algorid_fetch.native_host import main
sys.exit(main())
HOSTEOF
chmod 755 "$ROOT/usr/bin/algorid-fetch-native-host"

# --- browser launcher registration (native messaging host manifests)
python3 - "$ROOT" <<'PY'
import json, os, sys
sys.path.insert(0, os.getcwd())
from algorid_fetch.browsers import HOST_NAME, chrome_manifest, firefox_manifest
root, host = sys.argv[1], "/usr/bin/algorid-fetch-native-host"
for d in ("etc/opt/chrome/native-messaging-hosts", "etc/chromium/native-messaging-hosts",
          "etc/opt/edge/native-messaging-hosts"):
    os.makedirs(os.path.join(root, d), exist_ok=True)
    with open(os.path.join(root, d, HOST_NAME + ".json"), "w") as f:
        json.dump(chrome_manifest(host), f, indent=2)
d = os.path.join(root, "usr/lib/mozilla/native-messaging-hosts")  # also read by Snap Firefox's portal
os.makedirs(d, exist_ok=True)
with open(os.path.join(d, HOST_NAME + ".json"), "w") as f:
    json.dump(firefox_manifest(host), f, indent=2)
PY
find "$ROOT/etc" "$ROOT/usr/lib/mozilla" -type f -exec chmod 644 {} +

# --- desktop integration
install -Dm644 algorid_fetch/icon.svg "$ROOT/usr/share/icons/hicolor/scalable/apps/algorid-fetch.svg"
for s in 16 32 48 128; do
  install -Dm644 "extension/icons/icon$s.png" "$ROOT/usr/share/icons/hicolor/${s}x${s}/apps/algorid-fetch.png"
done
install -d "$ROOT/usr/share/applications"
cat > "$ROOT/usr/share/applications/algorid-fetch.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=Algorid Fetch
GenericName=Downloader
Comment=Fast, resumable multi-connection downloads
Exec=algorid-fetch gui
Icon=algorid-fetch
Terminal=false
Categories=Network;FileTransfer;
Keywords=download;downloader;accelerator;resume;video;
StartupWMClass=algorid-fetch
Actions=AddUrl;

[Desktop Action AddUrl]
Name=New download
Exec=algorid-fetch gui
EOF

# optional headless daemon: systemctl --user enable --now algorid-fetch
install -Dm644 /dev/stdin "$ROOT/usr/lib/systemd/user/algorid-fetch.service" <<'EOF'
[Unit]
Description=Algorid Fetch download daemon
After=network-online.target

[Service]
ExecStart=/usr/bin/algorid-fetch daemon --resume
Restart=on-failure

[Install]
WantedBy=default.target
EOF

# browser extension shipped too, so "Load unpacked" can point at /usr/share/algorid-fetch/extension
install -d "$ROOT/usr/share/algorid-fetch"
cp -r extension "$ROOT/usr/share/algorid-fetch/extension"
find "$ROOT/usr/share/algorid-fetch" -type f -exec chmod 644 {} +

# --- docs
install -d "$ROOT/usr/share/doc/$PKG"
install -m644 README.md "$ROOT/usr/share/doc/$PKG/README.md"
cat > "$ROOT/usr/share/doc/$PKG/copyright" <<EOF
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Upstream-Name: algorid-fetch

Files: *
Copyright: $(date +%Y) Golam Mostafa
License: MIT
EOF
printf '%s (%s) stable; urgency=low\n\n  * Release %s.\n\n -- Golam Mostafa <noreply@algorid_fetch.local>  %s\n' \
  "$PKG" "$VER" "$VER" "$(date -R)" | gzip -9n > "$ROOT/usr/share/doc/$PKG/changelog.gz"

# --- control files
install -d "$ROOT/DEBIAN"
SIZE=$(du -sk "$ROOT/usr" | cut -f1)
cat > "$ROOT/DEBIAN/control" <<EOF
Package: $PKG
Version: $VER
Section: net
Priority: optional
Architecture: all
Installed-Size: $SIZE
Depends: python3 (>= 3.8), python3-pyqt6 | python3-pyqt5
Conflicts: kitedm
Replaces: kitedm
Recommends: libxcb-cursor0, ffmpeg
Suggests: qt6-wayland
Maintainer: Golam Mostafa <noreply@algorid_fetch.local>
Homepage: https://gmostafa1210.github.io
Description: fast, resumable multi-connection downloader
 Algorid Fetch speeds up downloads by splitting files across up to 32
 connections with adaptive range splitting, resumes after pause, crash or
 reboot, catches browser downloads through a Chromium extension, grabs
 videos via yt-dlp, and includes a terminal downloader and daemon.
EOF

cat > "$ROOT/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e
if [ "$1" = "configure" ]; then
  py3compile -p algorid-fetch 2>/dev/null || python3 -m compileall -q /usr/lib/python3/dist-packages/algorid_fetch >/dev/null 2>&1 || true
fi
exit 0
EOF
cat > "$ROOT/DEBIAN/prerm" <<'EOF'
#!/bin/sh
set -e
rm -rf /usr/lib/python3/dist-packages/algorid_fetch/__pycache__
exit 0
EOF
chmod 755 "$ROOT/DEBIAN/postinst" "$ROOT/DEBIAN/prerm"

mkdir -p "$OUT"
dpkg-deb --build --root-owner-group -Zxz "$ROOT" "$OUT/${PKG}_${VER}_all.deb" >/dev/null

# --- browser extensions (Chromium zip + Firefox xpi) from the same sources
python3 packaging/pack_extensions.py "$VER" "$OUT"

# version-free copy for GitHub releases: .../releases/latest/download/algorid-fetch_all.deb
cp "$OUT/${PKG}_${VER}_all.deb" "$OUT/${PKG}_all.deb"

echo "built: $OUT/${PKG}_${VER}_all.deb (+ $OUT/${PKG}_all.deb for releases)"
echo "built: $OUT/algorid-fetch-chrome-extension-$VER.zip"
echo "built: $OUT/algorid-fetch-firefox-$VER.xpi"
