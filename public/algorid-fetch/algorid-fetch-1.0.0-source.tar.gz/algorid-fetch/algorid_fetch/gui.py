"""PyQt6 desktop UI: queue table, category sidebar, connection map, tray, clipboard."""
from __future__ import annotations

import os
import re
import sys
import threading
import time

from .qt import (QAbstractTableModel, QModelIndex, QObject, QRectF, QSize,
                          QSortFilterProxyModel, Qt, QTimer, QUrl, pyqtSignal)
from .qt import (QAction, QColor, QDesktopServices, QGuiApplication, QIcon, QKeySequence,
                         QPainter, QPalette)
from .qt import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog,
                             QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView,
                             QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu,
                             QMessageBox, QPushButton, QSizePolicy, QSpinBox, QSplitter, QStyle,
                             QStyledItemDelegate, QStyleOptionProgressBar, QSystemTrayIcon,
                             QTableView, QToolBar, QVBoxLayout, QWidget)

from .qt import QT_API, prepare_app, qexec
from . import icons
from .api import ApiServer
from .config import VERSION, Config
from .engine import Status, human_size, human_time, probe
from .manager import Manager
from .media import (QUALITIES, auto_update_in_background, has_ffmpeg, install_video_tools,
                    is_media_url, video_tools_ready, video_tools_status)

ICON_PATH = os.path.join(os.path.dirname(__file__), "icon.svg")
URL_RE = re.compile(r"^https?://\S+$", re.I)

STATUS_TEXT = {
    Status.QUEUED: "Queued", Status.PROBING: "Connecting…", Status.DOWNLOADING: "Downloading",
    Status.PAUSED: "Paused", Status.COMPLETED: "Complete", Status.ERROR: "Error",
}
COLS = ["File name", "Size", "Progress", "Speed", "Time left", "Status", "Added"]
C_NAME, C_SIZE, C_PROG, C_SPEED, C_ETA, C_STATUS, C_ADDED = range(7)


def app_icon() -> QIcon:
    for path in (ICON_PATH, ICON_PATH[:-4] + ".png"):  # PNG if the SVG plugin is missing
        ic = QIcon(path)
        if not ic.isNull() and not ic.pixmap(32, 32).isNull():
            return ic
    return QIcon.fromTheme("folder-download")


_STATUS_ICONS: dict = {}


def status_icon(status: str):
    """Small colored icon per status, drawn by the app (no icon theme needed)."""
    if not _STATUS_ICONS:
        spec = {Status.COMPLETED: ("completed", "#16a34a"), Status.ERROR: ("error", "#dc2626"),
                Status.PAUSED: ("pause", "#d97706"), Status.DOWNLOADING: ("running", "#4f46e5"),
                Status.PROBING: ("running", "#4f46e5"), Status.QUEUED: ("incomplete", "#6b7280")}
        sel = QApplication.palette().color(QPalette.ColorRole.HighlightedText)
        for st, (name, color) in spec.items():
            _STATUS_ICONS[st] = icons.icon(name, QColor(color), sel)
    return _STATUS_ICONS.get(status)


# --------------------------------------------------------------------------- #
# Thread bridge: manager callbacks arrive on worker threads
# --------------------------------------------------------------------------- #
class Bridge(QObject):
    event = pyqtSignal(int, str)
    pair = pyqtSignal(object)  # PairRequest
    show = pyqtSignal()
    browser_add = pyqtSignal(dict)
    probed = pyqtSignal(object, object)  # (dialog token, RemoteInfo | Exception)
    ytdlp_ready = pyqtSignal(object, str)  # (continuation callable, error)


class PairRequest:
    """Carries a pairing question from the API thread to the GUI thread."""

    def __init__(self, origin: str):
        self.origin = origin
        self.approved = False
        self.done = threading.Event()


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
class DownloadModel(QAbstractTableModel):
    def __init__(self, manager: Manager):
        super().__init__()
        self.m = manager
        self.rows: list[dict] = []

    def refresh(self) -> bool:
        snap = sorted(self.m.snapshot(), key=lambda s: s["id"])
        if [s["id"] for s in snap] != [r["id"] for r in self.rows]:
            self.beginResetModel()
            self.rows = snap
            self.endResetModel()
            return True
        self.rows = snap
        if snap:
            self.dataChanged.emit(self.index(0, 0), self.index(len(snap) - 1, len(COLS) - 1))
        return False

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(COLS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return COLS[section]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        r = self.rows[index.row()]
        c = index.column()
        if role == Qt.ItemDataRole.UserRole:
            return r
        if role == Qt.ItemDataRole.UserRole + 1:  # sort key
            return {C_NAME: r["filename"].lower(), C_SIZE: r["size"] or 0,
                    C_PROG: r["progress"] or 0, C_SPEED: r["speed"], C_ETA: r["eta"] or 1e12,
                    C_STATUS: r["status"], C_ADDED: r["added"]}[c]
        if role == Qt.ItemDataRole.DisplayRole:
            if c == C_NAME:
                return r["filename"]
            if c == C_SIZE:
                return human_size(r["size"]) if r["size"] is not None else "Unknown"
            if c == C_PROG:
                return r["progress"]
            if c == C_SPEED:
                return f"{human_size(r['speed'])}/s" if r["speed"] else ""
            if c == C_ETA:
                return human_time(r["eta"]) if r["eta"] is not None else ""
            if c == C_STATUS:
                s = STATUS_TEXT.get(r["status"], r["status"])
                if r["status"] == Status.PAUSED and not r["downloaded"] and not r["path"]:
                    s = "Not started"
                if r["status"] == Status.DOWNLOADING and r["connections"]:
                    s += f" ({r['connections']} conn)"
                if r["status"] == Status.ERROR and r["error"]:
                    s += f": {r['error']}"
                return s
            if c == C_ADDED:
                return time.strftime("%b %d %H:%M", time.localtime(r["added"]))
        if role == Qt.ItemDataRole.ToolTipRole:
            return f"{r['url']}\n{r['path'] or ''}" + (f"\n{r['error']}" if r["error"] else "")
        if role == Qt.ItemDataRole.DecorationRole and c == C_NAME:
            return status_icon(r["status"])
        if role == Qt.ItemDataRole.TextAlignmentRole and c in (C_SIZE, C_SPEED, C_ETA):
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return None


class FilterProxy(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.mode = "all"
        self.text = ""
        self.setSortRole(Qt.ItemDataRole.UserRole + 1)

    def set_mode(self, mode):
        self.mode = mode
        self.invalidateFilter()

    def set_text(self, t):
        self.text = t.lower()
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        r = self.sourceModel().rows[row]
        if self.text and self.text not in r["filename"].lower() and self.text not in r["url"].lower():
            return False
        m = self.mode
        if m == "all":
            return True
        if m == "unfinished":
            return r["status"] != Status.COMPLETED
        if m == "finished":
            return r["status"] == Status.COMPLETED
        if m == "active":
            return r["status"] in (Status.DOWNLOADING, Status.PROBING, Status.QUEUED)
        return (r["category"] or "Other") == m


class ProgressDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        p = index.data(Qt.ItemDataRole.DisplayRole)
        r = index.data(Qt.ItemDataRole.UserRole)
        opt = QStyleOptionProgressBar()
        opt.rect = option.rect.adjusted(3, 4, -3, -4)
        opt.minimum, opt.maximum = 0, 1000
        if p is None:
            opt.progress, opt.text = 0, "-" if r["status"] != Status.DOWNLOADING else "…"
        else:
            opt.progress, opt.text = int(p * 1000), f"{p * 100:.1f}%"
        opt.textVisible = True
        opt.textAlignment = Qt.AlignmentFlag.AlignCenter
        QApplication.style().drawControl(QStyle.ControlElement.CE_ProgressBar, opt, painter)


# --------------------------------------------------------------------------- #
# Connection map: one bar per byte range
# --------------------------------------------------------------------------- #
class SegmentBar(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(26)
        self.size_ = None
        self.segments = []

    def set_data(self, size, segments):
        self.size_, self.segments = size, segments
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(1, 3, -1, -3)
        pal = self.palette()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(pal.color(QPalette.ColorRole.AlternateBase))
        p.drawRoundedRect(rect, 4, 4)
        if not self.size_ or not self.segments:
            return
        accent = pal.color(QPalette.ColorRole.Highlight)
        w = rect.width() / self.size_
        for start, end, pos in self.segments:
            end = self.size_ - 1 if end is None else end
            x0 = rect.left() + start * w
            done_w = max(0.0, (min(pos, end + 1) - start) * w)
            p.setBrush(accent)
            p.drawRect(QRectF(x0, rect.top(), done_w, rect.height()))
            if pos <= end:  # active edge
                p.setBrush(QColor(accent).lighter(150))
                p.drawRect(QRectF(x0 + done_w, rect.top(), max(1.5, 0.004 * rect.width()), rect.height()))
            p.setPen(pal.color(QPalette.ColorRole.Window))
            p.drawLine(int(x0), int(rect.top()), int(x0), int(rect.bottom()))
            p.setPen(Qt.PenStyle.NoPen)


# --------------------------------------------------------------------------- #
# Dialogs
# --------------------------------------------------------------------------- #
class AddDialog(QDialog):
    def __init__(self, parent, cfg: Config, bridge: Bridge, url="", filename="", headers=None,
                 media=False, quality=None, cookie_jar=None):
        super().__init__(parent)
        self.cfg, self.bridge, self.headers = cfg, bridge, headers or {}
        self.cookie_jar = cookie_jar
        self.setWindowTitle("New download")
        self.setWindowIcon(app_icon())
        self.setMinimumWidth(560)
        self.start_now = True
        self._token = object()

        self.url = QLineEdit(url)
        self.name = QLineEdit(filename)
        self.name.setPlaceholderText("auto (from server)")
        self.folder = QLineEdit()
        self.folder.setPlaceholderText(f"auto: {cfg['download_dir']} + category")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        frow = QHBoxLayout()
        frow.addWidget(self.folder)
        frow.addWidget(browse)
        self.conns = QSpinBox()
        self.conns.setRange(1, 32)
        self.conns.setValue(int(cfg["connections"]))
        self.media = QCheckBox("Grab video/audio with yt-dlp")
        self.media.setChecked(media or is_media_url(url))
        if not video_tools_ready():
            self.media.setToolTip("Video components (yt-dlp, Deno) are installed automatically the first time")
        self.quality = QComboBox()
        for key, label in QUALITIES:
            self.quality.addItem(label, key)
        qi = self.quality.findData(quality or "best")
        self.quality.setCurrentIndex(max(0, qi))
        self.quality_lbl = QLabel("Quality")
        self.ff_hint = QLabel("" if has_ffmpeg() else
                              "Tip: install ffmpeg for HD video (sudo apt install ffmpeg). "
                              "Without it YouTube is limited to 360p.")
        self.ff_hint.setWordWrap(True)
        self.ff_hint.setStyleSheet("color: gray")
        self.info = QLabel("")
        self.info.setStyleSheet("color: gray")

        form = QFormLayout()
        form.addRow("URL", self.url)
        form.addRow("Save as", self.name)
        form.addRow("Folder", frow)
        form.addRow("Connections", self.conns)
        form.addRow("", self.media)
        form.addRow(self.quality_lbl, self.quality)
        form.addRow("", self.ff_hint)
        form.addRow("", self.info)

        bb = QDialogButtonBox()
        self.b_start = bb.addButton("Start now", QDialogButtonBox.ButtonRole.AcceptRole)
        b_later = bb.addButton("Add paused", QDialogButtonBox.ButtonRole.AcceptRole)
        bb.addButton(QDialogButtonBox.StandardButton.Cancel)
        self.b_start.clicked.connect(lambda: self._done(True))
        b_later.clicked.connect(lambda: self._done(False))
        bb.rejected.connect(self.reject)
        self.b_start.setDefault(True)

        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)
        self.media.toggled.connect(self._media_toggled)
        self._media_toggled(self.media.isChecked())
        bridge.probed.connect(self._on_probed)
        self.url.editingFinished.connect(self._probe)
        if url:
            QTimer.singleShot(0, self._probe)

    def _media_toggled(self, on: bool):
        for w in (self.quality_lbl, self.quality):
            w.setVisible(on)
        self.ff_hint.setVisible(on and bool(self.ff_hint.text()))
        self.conns.setEnabled(not on)
        self.name.setPlaceholderText("auto (video title)" if on else "auto (from server)")
        if on:
            self.info.setText("Video will be fetched with yt-dlp")
        else:
            self._probe()

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Save to", self.folder.text() or self.cfg["download_dir"])
        if d:
            self.folder.setText(d)

    def _probe(self):
        url = self.url.text().strip()
        if not URL_RE.match(url) or self.media.isChecked():
            self.info.setText("")
            return
        self.info.setText("Checking…")
        token = self._token = object()

        def run():
            try:
                res = probe(url, self.headers, timeout=15)
            except Exception as e:  # noqa: BLE001
                res = e
            self.bridge.probed.emit(token, res)
        threading.Thread(target=run, daemon=True).start()

    def _on_probed(self, token, res):
        if token is not self._token:
            return
        if isinstance(res, Exception):
            self.info.setText(f"Could not check: {res}")
            return
        if not self.name.text():
            self.name.setPlaceholderText(res.filename)
        resume = "resume supported" if res.resumable else "no resume / single connection"
        self.info.setText(f"{human_size(res.size) if res.size is not None else 'Unknown size'} · {resume}"
                          f" · {res.content_type or ''}")

    def _done(self, start_now):
        if not URL_RE.match(self.url.text().strip()):
            QMessageBox.warning(self, "Algorid Fetch", "Enter a valid http(s) URL.")
            return
        self.start_now = start_now
        self.accept()

    def values(self) -> dict:
        return {"url": self.url.text().strip(), "filename": self.name.text().strip() or None,
                "dest_dir": self.folder.text().strip() or None, "connections": self.conns.value(),
                "headers": self.headers, "start": self.start_now,
                "kind": "media" if self.media.isChecked() else "http",
                "quality": self.quality.currentData() if self.media.isChecked() else None,
                "cookie_jar": self.cookie_jar}


class _YtBridge(QObject):
    done = pyqtSignal(str, str)


class SettingsDialog(QDialog):
    def __init__(self, parent, cfg: Config):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Algorid Fetch Settings")
        self.setMinimumWidth(520)
        self.dir = QLineEdit(cfg["download_dir"])
        b = QPushButton("Browse…")
        b.clicked.connect(lambda: self.dir.setText(
            QFileDialog.getExistingDirectory(self, "Download folder", self.dir.text()) or self.dir.text()))
        row = QHBoxLayout()
        row.addWidget(self.dir)
        row.addWidget(b)
        self.cat = QCheckBox("Sort into folders by type (Videos, Audio, Archives…)")
        self.cat.setChecked(bool(cfg["categorize"]))
        self.conns = QSpinBox()
        self.conns.setRange(1, 32)
        self.conns.setValue(int(cfg["connections"]))
        self.maxc = QSpinBox()
        self.maxc.setRange(1, 20)
        self.maxc.setValue(int(cfg["max_concurrent"]))
        self.limit = QSpinBox()
        self.limit.setRange(0, 1_000_000)
        self.limit.setSuffix(" KB/s")
        self.limit.setSpecialValueText("Unlimited")
        self.limit.setValue(int(cfg["speed_limit"] // 1024))
        self.clip = QCheckBox("Watch clipboard for download links")
        self.clip.setChecked(bool(cfg["clipboard_monitor"]))
        self.confirm = QCheckBox("Show dialog for downloads caught from the browser")
        self.confirm.setChecked(bool(cfg["browser_confirm_dialog"]))
        self.tray = QCheckBox("Closing the window keeps Algorid Fetch in the tray")
        self.tray.setChecked(bool(cfg["close_to_tray"]))
        self.notify = QCheckBox("Notify when a download completes")
        self.notify.setChecked(bool(cfg["notify_on_complete"]))
        tok = QLineEdit(cfg["api_token"])
        tok.setReadOnly(True)
        cp = QPushButton("Copy")
        cp.clicked.connect(lambda: QGuiApplication.clipboard().setText(cfg["api_token"]))
        trow = QHBoxLayout()
        trow.addWidget(tok)
        trow.addWidget(cp)

        f = QFormLayout()
        f.addRow("Download folder", row)
        f.addRow("", self.cat)
        f.addRow("Connections per file", self.conns)
        f.addRow("Simultaneous downloads", self.maxc)
        f.addRow("Global speed limit", self.limit)
        f.addRow("", self.clip)
        f.addRow("", self.confirm)
        f.addRow("", self.tray)
        f.addRow("", self.notify)
        f.addRow("Browser extension token", trow)
        f.addRow("", QLabel(f"API: http://127.0.0.1:{cfg['api_port']} · GUI: {QT_API}"))
        self.yt_lbl = QLabel("checking…")
        self.yt_btn = QPushButton("Install / update")
        self.yt_btn.clicked.connect(self._update_ytdlp)
        yrow = QHBoxLayout()
        yrow.addWidget(self.yt_lbl, 1)
        yrow.addWidget(self.yt_btn)
        f.addRow("Video downloads", yrow)
        self._yt_bridge = _YtBridge()
        self._yt_bridge.done.connect(self._yt_done)
        threading.Thread(target=lambda: self._yt_bridge.done.emit(video_tools_status(), ""),
                         daemon=True).start()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(f)
        lay.addWidget(bb)

    def _update_ytdlp(self):
        self.yt_btn.setEnabled(False)
        self.yt_lbl.setText("downloading latest yt-dlp and Deno…")

        def run():
            try:
                self._yt_bridge.done.emit(install_video_tools(update=True), "")
            except Exception as e:  # noqa: BLE001
                self._yt_bridge.done.emit(video_tools_status(), str(e))
        threading.Thread(target=run, daemon=True).start()

    def _yt_done(self, version, err):
        self.yt_btn.setEnabled(True)
        self.yt_lbl.setText(version + (f"  (update failed: {err})" if err else ""))

    def apply(self, manager: Manager):
        c = self.cfg
        c["download_dir"] = self.dir.text().strip() or c["download_dir"]
        c["categorize"] = self.cat.isChecked()
        c["connections"] = self.conns.value()
        c["max_concurrent"] = self.maxc.value()
        c["clipboard_monitor"] = self.clip.isChecked()
        c["browser_confirm_dialog"] = self.confirm.isChecked()
        c["close_to_tray"] = self.tray.isChecked()
        c["notify_on_complete"] = self.notify.isChecked()
        manager.set_speed_limit(self.limit.value() * 1024)  # also saves
        manager._schedule()


# --------------------------------------------------------------------------- #
# Main window
# --------------------------------------------------------------------------- #
class EmptyState(QWidget):
    """Shown over the empty list: what to do first."""

    def __init__(self, parent, on_new, on_browser):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo = QLabel()
        logo.setPixmap(app_icon().pixmap(64, 64))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title = QLabel("No downloads yet")
        f = title.font()
        f.setPointSizeF(f.pointSizeF() * 1.5)
        f.setBold(True)
        title.setFont(f)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text = QLabel("Copy a link and press <b>Ctrl+V</b>, click <b>New download</b>, or just download in "
                      "your browser: Algorid Fetch takes over once your browser is connected.")
        text.setWordWrap(True)
        text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text.setFixedWidth(440)
        row = QHBoxLayout()
        row.setAlignment(Qt.AlignmentFlag.AlignCenter)
        b1 = QPushButton("  New download")
        b1.setIcon(icons.icon("add", self.palette().color(QPalette.ColorRole.ButtonText), None))
        b1.clicked.connect(on_new)
        b2 = QPushButton("  Connect your browser")
        b2.setIcon(icons.icon("browser", self.palette().color(QPalette.ColorRole.ButtonText), None))
        b2.clicked.connect(on_browser)
        for b in (b1, b2):
            b.setMinimumHeight(34)
            row.addWidget(b)
        for w in (logo, title):
            lay.addWidget(w)
        lay.addWidget(text, 0, Qt.AlignmentFlag.AlignHCenter)
        lay.addSpacing(8)
        lay.addLayout(row)


def extension_dir() -> str | None:
    """Folder to choose in the browser's 'Load unpacked'."""
    here = os.path.dirname(os.path.abspath(__file__))
    cands = []
    if getattr(sys, "frozen", False):
        cands.append(os.path.join(os.path.dirname(sys.executable), "extension"))
    cands += ["/usr/share/algorid-fetch/extension", os.path.join(here, "..", "extension")]
    for c in cands:
        if os.path.isfile(os.path.join(c, "manifest.json")):
            return os.path.abspath(c)
    return None


RELEASES_URL = "https://github.com/gmostafa1210/algorid-fetch/releases/latest"


class ConnectBrowserDialog(QDialog):
    """Step-by-step browser setup with copy buttons and a live 'connected' check."""

    def __init__(self, parent, api_server):
        super().__init__(parent)
        self.api = api_server
        self.setWindowTitle("Connect your browser")
        self.setWindowIcon(app_icon())
        self.setMinimumWidth(560)
        text_color = self.palette().color(QPalette.ColorRole.ButtonText)
        lay = QVBoxLayout(self)
        intro = QLabel("Connect your browser once, and downloads you start there open in Algorid Fetch. "
                       "If the app is closed, the browser starts it for you.")
        intro.setWordWrap(True)
        lay.addWidget(intro)

        def step(n, html, *widgets):
            row = QHBoxLayout()
            num = QLabel(f"<b>{n}</b>")
            num.setFixedWidth(22)
            num.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
            row.addWidget(num)
            col = QVBoxLayout()
            lbl = QLabel(html)
            lbl.setWordWrap(True)
            lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            col.addWidget(lbl)
            if widgets:
                wr = QHBoxLayout()
                for w in widgets:
                    wr.addWidget(w)
                wr.addStretch(1)
                col.addLayout(wr)
            row.addLayout(col, 1)
            lay.addLayout(row)

        def copy_btn(label, value):
            b = QPushButton(label)
            b.setIcon(icons.icon("copy", text_color, None))
            b.clicked.connect(lambda: (QGuiApplication.clipboard().setText(value), b.setText("Copied")))
            return b

        head = QLabel("<b>Chrome, Edge, Brave, Vivaldi or Opera</b>")
        lay.addSpacing(6)
        lay.addWidget(head)
        step(1, "Open the extensions page: paste this into the address bar.",
             copy_btn("Copy chrome://extensions", "chrome://extensions"))
        step(2, "Turn on <b>Developer mode</b> (top right of that page).")
        folder = extension_dir()
        if folder:
            open_b = QPushButton("Open folder")
            open_b.setIcon(icons.icon("folder", text_color, None))
            open_b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(folder)))
            step(3, f"Click <b>Load unpacked</b> and choose this folder:<br><code>{folder}</code>",
                 copy_btn("Copy folder path", folder), open_b)
        else:
            step(3, "Click <b>Load unpacked</b> and choose the unzipped extension folder.")
        lay.addSpacing(6)
        lay.addWidget(QLabel("<b>Firefox</b>"))
        ff_btn = QPushButton("Open download page")
        ff_btn.setIcon(icons.icon("browser", text_color, None))
        ff_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(RELEASES_URL)))
        step("", "Install the Algorid Fetch add-on (the <code>.xpi</code> file) from the download page.", ff_btn)
        lay.addSpacing(10)

        self.status = QLabel()
        self.status.setStyleSheet("padding: 8px; border-radius: 6px; background: rgba(127,127,127,0.12);")
        lay.addWidget(self.status)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(self.reject)
        bb.accepted.connect(self.accept)
        lay.addWidget(bb)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(1000)
        self._refresh()

    def _refresh(self):
        seen = getattr(self.api, "last_extension_seen", 0)
        if seen and time.time() - seen < 90:
            self.status.setText("<span style='color:#16a34a'>●</span> Your browser is connected.")
        else:
            self.status.setText("<span style='color:#d97706'>●</span> Waiting for the browser extension…")


class MainWindow(QMainWindow):
    def __init__(self, cfg: Config, manager: Manager, bridge: Bridge):
        super().__init__()
        self.cfg, self.m, self.bridge = cfg, manager, bridge
        self.quitting = False
        self.setWindowTitle(f"Algorid Fetch {VERSION}")
        self.setWindowIcon(app_icon())
        self.resize(1180, 640)

        self.model = DownloadModel(manager)
        self.proxy = FilterProxy()
        self.proxy.setSourceModel(self.model)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(C_ADDED, Qt.SortOrder.DescendingOrder)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.setItemDelegateForColumn(C_PROG, ProgressDelegate(self.table))
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(C_NAME, QHeaderView.ResizeMode.Stretch)
        for c, w in ((C_SIZE, 85), (C_PROG, 130), (C_SPEED, 90), (C_ETA, 70), (C_STATUS, 150), (C_ADDED, 100)):
            self.table.setColumnWidth(c, w)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.doubleClicked.connect(self._double_click)
        self.table.selectionModel().selectionChanged.connect(lambda *_: self._update_details())
        self.empty = EmptyState(self.table.viewport(), lambda: self.open_add(), lambda: self.open_connect_browser())
        self.table.viewport().installEventFilter(self)
        self.api_server = None  # set by the app; used by the browser guide

        self.side = QListWidget()
        self.side.setMaximumWidth(200)
        self.side.setMinimumWidth(140)
        self.side.setIconSize(QSize(18, 18))
        self.side.setSpacing(1)
        accent = QColor("#4f46e5") if self.palette().color(QPalette.ColorRole.Base).lightness() > 128 \
            else QColor("#a5b4fc")
        # selected items: use the theme's own highlighted-text color (white on
        # dark highlights, dark on the light gray Windows uses)
        sel_text = self.palette().color(QPalette.ColorRole.HighlightedText)
        st = QApplication.style()
        style_name = (st.name() if hasattr(st, "name") else st.objectName()) or ""  # Qt6 / Qt5
        if style_name.lower().startswith("windows"):
            sel_text = None  # Windows styles draw selected list items dark on a light highlight
        for label, key, icon in [("Everything", "all", "all"),
                                 ("Running", "active", "running"),
                                 ("Incomplete", "unfinished", "incomplete"),
                                 ("Completed", "finished", "completed"),
                                 ("Videos", "Videos", "video"),
                                 ("Audio", "Audio", "audio"),
                                 ("Documents", "Documents", "document"),
                                 ("Archives", "Archives", "archive"),
                                 ("Apps", "Apps", "apps"),
                                 ("Images", "Images", "image"),
                                 ("Other", "Other", "other")]:
            it = QListWidgetItem(icons.icon(icon, accent, sel_text), label)
            it.setData(Qt.ItemDataRole.UserRole, key)
            self.side.addItem(it)
        self.side.setCurrentRow(0)
        self.side.currentItemChanged.connect(
            lambda cur, _: cur and self.proxy.set_mode(cur.data(Qt.ItemDataRole.UserRole)))

        self.seg = SegmentBar()
        self.details = QLabel("")
        self.details.setWordWrap(True)
        self.details.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(6, 4, 6, 6)
        bl.addWidget(self.details)
        bl.addWidget(self.seg)
        bl.addStretch(1)
        bottom.setMinimumHeight(110)

        right = QSplitter(Qt.Orientation.Vertical)
        right.addWidget(self.table)
        right.addWidget(bottom)
        right.setStretchFactor(0, 5)
        right.setStretchFactor(1, 1)
        split = QSplitter()
        split.addWidget(self.side)
        split.addWidget(right)
        split.setStretchFactor(1, 1)
        split.setSizes([170, 1000])
        self.setCentralWidget(split)

        self._build_toolbar()
        self.status_lbl = QLabel()
        self.statusBar().addPermanentWidget(self.status_lbl)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(500)
        self._tick()

    # ---------- UI building ---------- #
    def _act(self, text, icon, slot, shortcut=None):
        color = self.palette().color(QPalette.ColorRole.WindowText)
        a = QAction(icons.icon(icon, color, None) if icon else QIcon(), text, self)
        a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        return a

    def _build_toolbar(self):
        tb = QToolBar("Main")
        tb.setMovable(False)
        tb.setIconSize(QSize(22, 22))
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self.addToolBar(tb)
        self.a_add = self._act("New", "add", lambda: self.open_add(), "Ctrl+N")
        self.a_resume = self._act("Resume", "play", self.resume_sel)
        self.a_pause = self._act("Pause", "pause", self.pause_sel)
        a_rall = self._act("Resume all", "play-all", self.m.start_all)
        a_pall = self._act("Pause all", "pause-all", self.m.pause_all)
        self.a_del = self._act("Remove", "remove", lambda: self.remove_sel(False), "Delete")
        a_set = self._act("Settings", "settings", self.open_settings, "Ctrl+,")
        a_folder = self._act("Folder", "folder",
                             lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self.cfg["download_dir"])))
        for a in (self.a_add, None, self.a_resume, self.a_pause, a_rall, a_pall, self.a_del, None,
                  a_folder, a_set):
            tb.addSeparator() if a is None else tb.addAction(a)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search…")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(200)
        self.search.textChanged.connect(self.proxy.set_text)
        tb.addWidget(self.search)
        tb.addWidget(QLabel("  Limit "))
        self.limit_box = QComboBox()
        for label, v in [("Unlimited", 0), ("128 KB/s", 128), ("256 KB/s", 256), ("512 KB/s", 512),
                         ("1 MB/s", 1024), ("2 MB/s", 2048), ("5 MB/s", 5120), ("10 MB/s", 10240)]:
            self.limit_box.addItem(label, v * 1024)
        cur = self.limit_box.findData(int(self.cfg["speed_limit"]))
        if cur < 0:
            self.limit_box.addItem(f"{int(self.cfg['speed_limit']) // 1024} KB/s", int(self.cfg["speed_limit"]))
            cur = self.limit_box.count() - 1
        self.limit_box.setCurrentIndex(cur)
        self.limit_box.currentIndexChanged.connect(
            lambda i: self.m.set_speed_limit(self.limit_box.itemData(i)))
        tb.addWidget(self.limit_box)
        self.addAction(self._act("Paste URL", None, self._paste, "Ctrl+V"))
        self.addAction(self._act("Quit", None, self.quit, "Ctrl+Q"))

    # ---------- selection helpers ---------- #
    def selected(self) -> list[dict]:
        rows = {self.proxy.mapToSource(i).row() for i in self.table.selectionModel().selectedRows()}
        return [self.model.rows[r] for r in sorted(rows) if r < len(self.model.rows)]

    def _restore_selection(self, ids):
        sm = self.table.selectionModel()
        for r, row in enumerate(self.model.rows):
            if row["id"] in ids:
                idx = self.proxy.mapFromSource(self.model.index(r, 0))
                if idx.isValid():
                    sm.select(idx, sm.SelectionFlag.Select | sm.SelectionFlag.Rows)

    def eventFilter(self, obj, ev):
        if obj is self.table.viewport() and ev.type() == ev.Type.Resize:
            self.empty.setGeometry(self.table.viewport().rect())
        return super().eventFilter(obj, ev)

    def open_connect_browser(self):
        dlg = ConnectBrowserDialog(self, self.api_server)
        qexec(dlg)

    # ---------- periodic refresh ---------- #
    def _tick(self):
        sel = {r["id"] for r in self.selected()}
        if self.model.refresh():
            self._restore_selection(sel)
        rows = self.model.rows
        self.empty.setVisible(not rows)
        self.empty.setGeometry(self.table.viewport().rect())
        speed = sum(r["speed"] for r in rows)
        active = sum(1 for r in rows if r["status"] in (Status.DOWNLOADING, Status.PROBING))
        queued = sum(1 for r in rows if r["status"] == Status.QUEUED)
        self.status_lbl.setText(f"{active} active · {queued} queued · {human_size(speed)}/s")
        self.setWindowTitle(f"Algorid Fetch ({human_size(speed)}/s)" if active else f"Algorid Fetch {VERSION}")
        self._update_details()

    def _update_details(self):
        sel = self.selected()
        statuses = {r["status"] for r in sel}
        self.a_resume.setEnabled(bool(statuses & {Status.PAUSED, Status.ERROR}))
        self.a_pause.setEnabled(bool(statuses & {Status.DOWNLOADING, Status.PROBING, Status.QUEUED}))
        self.a_del.setEnabled(bool(sel))
        if len(sel) != 1:
            self.details.setText("" if not sel else f"{len(sel)} downloads selected")
            self.seg.set_data(None, [])
            self.seg.setVisible(False)
            return
        r = sel[0]
        segs = r["segments"]
        parts = [f"<b>{r['filename']}</b>", f"{human_size(r['downloaded'])} of {human_size(r['size'])}"]
        if r["status"] == Status.DOWNLOADING:
            parts.append(f"{r['connections']} connections · {len(segs)} segments")
        parts.append("resumable" if r["resumable"] else "not resumable")
        text = " · ".join(parts)
        if r["status"] == Status.ERROR and r["error"]:
            err = r["error"].replace("&", "&amp;").replace("<", "&lt;")
            text += f"<br><span style='color:#e5484d'><b>Error:</b> {err}</span>"
        self.details.setText(text)
        self.seg.set_data(r["size"], segs)
        self.seg.setVisible(bool(r["size"] and segs))

    # ---------- yt-dlp on demand ---------- #
    def ensure_ytdlp(self, then) -> None:
        """Run `then()` now if the video tools exist, else offer to install them first."""
        if video_tools_ready():
            auto_update_in_background()
            then()
            return
        ans = QMessageBox.question(
            self, "Algorid Fetch",
            "Downloading videos needs two free components that are not installed yet:\n"
            "  • yt-dlp (finds the video)\n  • Deno (needed by YouTube's player checks)\n\n"
            "Download them now? (about 80 MB, one time)")
        if ans != QMessageBox.StandardButton.Yes:
            return
        self.statusBar().showMessage("Installing video components (yt-dlp, Deno)…")

        def run():
            try:
                install_video_tools()
                self.bridge.ytdlp_ready.emit(then, "")
            except Exception as e:  # noqa: BLE001
                self.bridge.ytdlp_ready.emit(then, str(e))
        threading.Thread(target=run, daemon=True).start()

    def _ytdlp_ready(self, then, err: str):
        self.statusBar().clearMessage()
        if err:
            QMessageBox.warning(self, "Algorid Fetch", f"Could not install video components: {err}\n\n"
                                "Try again later from Settings, or run: algorid-fetch update-ytdlp")
            return
        self.statusBar().showMessage("Video components installed", 4000)
        then()

    # ---------- actions ---------- #
    def open_add(self, url="", filename="", headers=None, media=False, quality=None, cookie_jar=None):
        if not url:
            clip = QGuiApplication.clipboard().text().strip()
            url = clip if URL_RE.match(clip) else ""
        dlg = AddDialog(self, self.cfg, self.bridge, url, filename, headers, media, quality, cookie_jar)
        if qexec(dlg):
            v = dlg.values()

            def add():
                try:
                    self.m.add(v["url"], filename=v["filename"], dest_dir=v["dest_dir"],
                               connections=v["connections"], headers=v["headers"], start=v["start"],
                               kind=v["kind"], quality=v["quality"], cookie_jar=v["cookie_jar"])
                except ValueError as e:
                    QMessageBox.warning(self, "Algorid Fetch", str(e))
                self._tick()
            if v["kind"] == "media":
                self.ensure_ytdlp(add)
            else:
                add()

    def _paste(self):
        if self.search.hasFocus():
            self.search.paste()
            return
        self.open_add()

    def resume_sel(self):
        self._resume([r["id"] for r in self.selected()])

    def _resume(self, ids):
        media = [i for i in ids if (self.m.get(i) or {}).get("kind") == "media"]
        for i in ids:
            if i not in media:
                self.m.start(i)
        if media:
            self.ensure_ytdlp(lambda: [self.m.start(i) for i in media])

    def pause_sel(self):
        for r in self.selected():
            self.m.pause(r["id"])

    def remove_sel(self, with_file: bool):
        sel = self.selected()
        if not sel:
            return
        q = f"Remove {len(sel)} download(s) from the list?"
        if with_file:
            q = f"Remove {len(sel)} download(s) and DELETE the files from disk?"
        if QMessageBox.question(self, "Algorid Fetch", q) != QMessageBox.StandardButton.Yes:
            return
        for r in sel:
            self.m.remove(r["id"], delete_file=with_file)

    def open_settings(self):
        dlg = SettingsDialog(self, self.cfg)
        if qexec(dlg):
            dlg.apply(self.m)
            idx = self.limit_box.findData(int(self.cfg["speed_limit"]))
            if idx >= 0:
                self.limit_box.blockSignals(True)
                self.limit_box.setCurrentIndex(idx)
                self.limit_box.blockSignals(False)

    def _double_click(self, index):
        r = index.data(Qt.ItemDataRole.UserRole)
        if r["status"] == Status.COMPLETED and r["path"]:
            QDesktopServices.openUrl(QUrl.fromLocalFile(r["path"]))
        elif r["status"] in (Status.PAUSED, Status.ERROR):
            self._resume([r["id"]])
        else:
            self.m.pause(r["id"])

    def _context_menu(self, pos):
        sel = self.selected()
        if not sel:
            return
        r = sel[0]
        menu = QMenu(self)
        if r["status"] == Status.COMPLETED and r["path"]:
            menu.addAction(QIcon.fromTheme("document-open"), "Open",
                           lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(r["path"])))
        if r["path"]:
            menu.addAction(QIcon.fromTheme("folder-open"), "Open Folder",
                           lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(r["path"]))))
        menu.addSeparator()
        menu.addAction(self.a_resume)
        menu.addAction(self.a_pause)
        if r["error"]:
            menu.addAction(QIcon.fromTheme("edit-copy"), "Copy error details",
                           lambda: QGuiApplication.clipboard().setText(
                               f"{r['url']}\n{r['error']}\n\n{r.get('log') or ''}".strip()))
        menu.addAction(QIcon.fromTheme("view-refresh"), "Redownload",
                       lambda: [self.m.redownload(x["id"]) for x in sel])
        menu.addAction(QIcon.fromTheme("edit-copy"), "Copy URL",
                       lambda: QGuiApplication.clipboard().setText("\n".join(x["url"] for x in sel)))
        menu.addSeparator()
        menu.addAction(QIcon.fromTheme("list-remove"), "Remove from list", lambda: self.remove_sel(False))
        menu.addAction(QIcon.fromTheme("edit-delete"), "Remove and delete file", lambda: self.remove_sel(True))
        qexec(menu, self.table.viewport().mapToGlobal(pos))

    def closeEvent(self, ev):
        if not self.quitting and self.cfg["close_to_tray"] and QSystemTrayIcon.isSystemTrayAvailable():
            self.hide()
            ev.ignore()
            if not getattr(self, "_told_tray", False):
                self._told_tray = True
                tray = getattr(QApplication.instance(), "kite_tray", None)
                if tray is not None:
                    tray.showMessage("Algorid Fetch is still running",
                                     "Downloads continue. Open Algorid Fetch from the app grid to bring this window back, "
                                     "or use Ctrl+Q to quit.", QSystemTrayIcon.MessageIcon.Information, 6000)
            return
        self.quit()
        ev.accept()

    def quit(self):
        self.quitting = True
        QApplication.instance().quit()


# --------------------------------------------------------------------------- #
# Application wiring
# --------------------------------------------------------------------------- #
class KiteApp:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.bridge = Bridge()
        self.m = Manager(cfg)
        self.win = MainWindow(cfg, self.m, self.bridge)
        self.api = ApiServer(self.m, cfg, on_browser_add=self.bridge.browser_add.emit,
                             on_pair=self._pair_blocking, on_show=self.bridge.show.emit)
        self.bridge.show.connect(self.show)
        self.win.api_server = self.api
        self.bridge.pair.connect(self._ask_pair)
        self.m.subscribe(lambda i, k: k in ("completed", "error") and self.bridge.event.emit(i, k))
        self.bridge.event.connect(self._on_event)
        self.bridge.browser_add.connect(self._on_browser_add)
        self.bridge.ytdlp_ready.connect(self.win._ytdlp_ready)
        self._last_clip = QGuiApplication.clipboard().text()
        QGuiApplication.clipboard().dataChanged.connect(self._on_clipboard)
        self._tray()

    def _tray(self):
        self.tray = QSystemTrayIcon(app_icon())
        self.tray.setToolTip("Algorid Fetch")
        QApplication.instance().kite_tray = self.tray
        menu = QMenu()
        menu.addAction("Show Algorid Fetch", self.show)
        menu.addAction("New download…", lambda: (self.show(), self.win.open_add()))
        menu.addAction("Connect your browser…", lambda: (self.show(), self.win.open_connect_browser()))
        menu.addAction("Resume all", self.m.start_all)
        menu.addAction("Pause all", self.m.pause_all)
        menu.addSeparator()
        menu.addAction("Quit", self.win.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(
            lambda reason: reason == QSystemTrayIcon.ActivationReason.Trigger and self.toggle())
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

    def show(self):
        if self.win.isMinimized():
            self.win.showNormal()
        self.win.show()
        self.win.raise_()
        self.win.activateWindow()

    def toggle(self):
        self.win.hide() if self.win.isVisible() and self.win.isActiveWindow() else self.show()

    def _on_event(self, id_, kind):
        s = self.m.get(id_)
        if not s or not self.cfg["notify_on_complete"] or not self.tray.isVisible():
            return
        if kind == "completed":
            self.tray.showMessage("Download complete", s["filename"], QSystemTrayIcon.MessageIcon.Information, 4000)
        elif kind == "error":
            self.tray.showMessage("Download failed", f"{s['filename']}\n{s['error']}",
                                  QSystemTrayIcon.MessageIcon.Warning, 6000)

    def _pair_blocking(self, origin: str) -> bool:
        """Runs on the API thread: ask in the GUI, wait up to 2 minutes."""
        req = PairRequest(origin)
        self.bridge.pair.emit(req)
        req.done.wait(120)
        return req.approved

    def _ask_pair(self, req: "PairRequest"):
        self.show()
        ext_id = req.origin.split("://", 1)[-1].strip("/")
        box = QMessageBox(self.win)
        box.setWindowTitle("Connect browser extension")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("A browser extension wants to send downloads to Algorid Fetch.")
        box.setInformativeText(f"Extension ID: {ext_id}\n\nAllow only if you just clicked "
                               "“Connect” in the Algorid Fetch extension.")
        allow = box.addButton("Allow", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Deny", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(allow)
        QTimer.singleShot(115000, box.reject)  # don't outlive the API wait
        qexec(box)
        req.approved = box.clickedButton() is allow
        req.done.set()

    def _on_browser_add(self, payload: dict):
        self.show()

        def open_dialog():
            self.win.open_add(payload["url"], payload.get("filename") or "", payload.get("headers"),
                              bool(payload.get("media")), payload.get("quality"), payload.get("cookie_jar"))
        if payload.get("media"):
            self.win.ensure_ytdlp(open_dialog)
        else:
            open_dialog()

    def _on_clipboard(self):
        text = QGuiApplication.clipboard().text().strip()
        if text == self._last_clip or not self.cfg["clipboard_monitor"]:
            self._last_clip = text
            return
        self._last_clip = text
        if not URL_RE.match(text):
            return
        path = text.split("?", 1)[0].lower()
        exts = {e for v in self.cfg["categories"].values() for e in v.split()}
        if any(path.endswith("." + e) for e in exts) or is_media_url(text):
            if self.win.isActiveWindow():
                return  # the user is copying inside our own window
            self.show()
            self.win.open_add(text, media=is_media_url(text))

    def run(self, minimized: bool = False, welcome: bool = False) -> int:
        from .browsers import install_user_manifests
        threading.Thread(target=install_user_manifests, daemon=True).start()
        try:
            self.api.start()
        except OSError as e:
            QMessageBox.warning(self.win, "Algorid Fetch",
                                f"Browser integration disabled: port {self.cfg['api_port']} is busy ({e}).")
        if not (minimized and self.tray.isVisible()):
            self.show()
        if welcome:
            QTimer.singleShot(400, self.win.open_connect_browser)
        rc = qexec(QApplication.instance())
        self.m.shutdown()
        self.api.stop()
        return rc


def run_gui(cfg: Config | None = None, minimized: bool = False, welcome: bool = False) -> int:
    from .cli import _api, instance_running

    cfg = cfg or Config()
    if instance_running(cfg):
        # Second launch (app grid, terminal): bring the existing window forward.
        try:
            _api(cfg, "/show", {})
            return 0
        except Exception:  # noqa: BLE001
            print("A headless Algorid Fetch daemon is running on this port. Stop it with "
                  "`systemctl --user stop algorid-fetch` (or `pkill -f 'algorid-fetch daemon'`) to open the window.",
                  file=sys.stderr)
            return 1
    prepare_app()
    if os.name == "nt":  # own taskbar button/icon instead of "python"
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Algorid.Fetch")
        except Exception:  # noqa: BLE001
            pass
    QApplication.setApplicationName("Algorid Fetch")
    QApplication.setDesktopFileName("algorid-fetch")
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setWindowIcon(app_icon())
    return KiteApp(cfg).run(minimized, welcome)
