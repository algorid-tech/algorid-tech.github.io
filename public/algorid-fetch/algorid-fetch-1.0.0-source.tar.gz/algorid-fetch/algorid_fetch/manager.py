"""Download queue: persistence (SQLite), scheduling, global speed limit."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Callable

from .config import DB_PATH, LEGACY_CATEGORIES, Config
from .engine import Download, RateLimiter, Status
from .media import MediaDownload, is_media_url, ytdlp_command

SCHEMA = """
CREATE TABLE IF NOT EXISTS downloads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'http',
    filename TEXT,
    path TEXT,
    dest_dir TEXT,
    category TEXT,
    status TEXT NOT NULL,
    size INTEGER,
    downloaded INTEGER DEFAULT 0,
    connections INTEGER,
    headers TEXT,
    error TEXT,
    added REAL,
    finished REAL,
    options TEXT
);
"""

RUNNING = (Status.PROBING, Status.DOWNLOADING)


class Store:
    def __init__(self, path: str = DB_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.db.executescript(SCHEMA)
            cols = {r[1] for r in self.db.execute("PRAGMA table_info(downloads)")}
            if "options" not in cols:  # databases created by earlier builds
                self.db.execute("ALTER TABLE downloads ADD COLUMN options TEXT")
                self.db.commit()
        try:
            os.chmod(path, 0o600)  # headers may hold cookies
        except OSError:
            pass

    def insert(self, **f) -> int:
        cols = ",".join(f)
        with self.lock, self.db:
            cur = self.db.execute(f"INSERT INTO downloads ({cols}) VALUES ({','.join('?' * len(f))})",
                                  tuple(f.values()))
            return cur.lastrowid

    def update(self, id_: int, **f) -> None:
        sets = ",".join(f"{k}=?" for k in f)
        with self.lock, self.db:
            self.db.execute(f"UPDATE downloads SET {sets} WHERE id=?", (*f.values(), id_))

    def delete(self, id_: int) -> None:
        with self.lock, self.db:
            self.db.execute("DELETE FROM downloads WHERE id=?", (id_,))

    def all(self) -> list[sqlite3.Row]:
        with self.lock:
            return self.db.execute("SELECT * FROM downloads ORDER BY id").fetchall()


class Item:
    def __init__(self, id_: int, url: str, kind: str, task, connections: int, headers: dict,
                 added: float, finished: float | None = None, category: str | None = None,
                 options: dict | None = None):
        self.id = id_
        self.url = url
        self.kind = kind
        self.task = task
        self.connections = connections
        self.headers = headers
        self.added = added
        self.finished = finished
        self.category = category
        self.options = options or {}
        self.queued = False  # waiting for a free slot

    @property
    def status(self) -> str:
        if self.queued and not self.task.is_running():
            return Status.QUEUED
        return self.task.status

    def snapshot(self) -> dict:
        t = self.task
        return {
            "id": self.id,
            "url": self.url,
            "kind": self.kind,
            "quality": self.options.get("quality"),
            "filename": t.filename or self.url.rsplit("/", 1)[-1][:80],
            "path": t.path,
            "category": LEGACY_CATEGORIES.get(self.category, self.category),
            "status": self.status,
            "size": t.size,
            "downloaded": t.downloaded,
            "progress": t.progress,
            "speed": t.speed if t.is_running() else 0.0,
            "eta": t.eta if t.is_running() else None,
            "connections": t.active_connections,
            "resumable": t.resumable,
            "error": t.error,
            "log": getattr(t, "log", ""),
            "added": self.added,
            "finished": self.finished,
            "segments": t.segment_map(),
        }


class Manager:
    def __init__(self, config: Config | None = None, store: Store | None = None):
        self.config = config or Config()
        self.store = store or Store()
        self.items: dict[int, Item] = {}
        self.global_limiter = RateLimiter(self.config["speed_limit"])
        self._lock = threading.RLock()
        self._listeners: list[Callable[[int, str], None]] = []
        self._last_persist: dict[int, float] = {}
        self._load()

    # ---------------- events ---------------- #
    def subscribe(self, fn: Callable[[int, str], None]) -> None:
        self._listeners.append(fn)

    def _notify(self, id_: int, kind: str) -> None:
        for fn in list(self._listeners):
            try:
                fn(id_, kind)
            except Exception:
                pass

    # ---------------- construction ---------------- #
    def _make_task(self, id_, url, kind, filename, path, dest_dir, connections, headers, options=None):
        def on_event(task, ev, _id=id_):
            self._on_task_event(_id, ev)

        target = dest_dir or self._dir_resolver(id_)
        if kind == "media":
            return MediaDownload(url, target, filename=filename, headers=headers, path=path,
                                 on_event=on_event, speed_limit=self.config["speed_limit"],
                                 quality=(options or {}).get("quality"),
                                 cookie_jar=(options or {}).get("cookies"))
        return Download(url, target, filename=filename, connections=connections, headers=headers,
                        limiters=[self.global_limiter], path=path, on_event=on_event)

    def _dir_resolver(self, id_):
        def resolve(filename: str) -> str:
            item = self.items.get(id_)
            if item is not None:
                item.category = self.config.category_for(filename)
            return self.config.dir_for(filename)
        return resolve

    def _load(self) -> None:
        for r in self.store.all():
            headers = json.loads(r["headers"] or "{}")
            options = json.loads(r["options"] or "{}")
            path = r["path"]
            if path:  # partial files written before the rename used .kdm* suffixes
                for old, new in ((".kdmpart", ".afpart"), (".kdmstate", ".afstate")):
                    if os.path.exists(path + old) and not os.path.exists(path + new):
                        try:
                            os.replace(path + old, path + new)
                        except OSError:
                            pass
            task = self._make_task(r["id"], r["url"], r["kind"], r["filename"], path,
                                   r["dest_dir"], r["connections"] or self.config["connections"], headers,
                                   options)
            st = r["status"]
            if st in RUNNING or st == Status.QUEUED:
                st = Status.PAUSED  # never auto-start after a restart
            task.status = st
            task.size = r["size"]
            task.error = r["error"]
            if st == Status.COMPLETED:
                task.filename = r["filename"]
            if hasattr(task, "_done"):
                task._done = r["downloaded"] or 0
            elif path:
                st_file = path + ".afstate"
                if os.path.exists(st_file):
                    try:
                        with open(st_file) as f:
                            from .engine import Segment
                            task.segments = [Segment(*s) for s in json.load(f)["segments"]]
                    except (OSError, ValueError, KeyError, TypeError):
                        pass
            self.items[r["id"]] = Item(r["id"], r["url"], r["kind"], task, r["connections"] or 8,
                                       headers, r["added"] or 0, r["finished"], r["category"], options)

    # ---------------- public API ---------------- #
    def add(self, url: str, filename: str | None = None, dest_dir: str | None = None,
            connections: int | None = None, headers: dict | None = None, start: bool = True,
            kind: str | None = None, quality: str | None = None,
            cookie_jar: list | None = None) -> int:
        url = url.strip()
        if not url.lower().startswith(("http://", "https://")):
            raise ValueError("only http(s) URLs are supported")
        if kind is None:
            # Video-site links always go to yt-dlp (never download the HTML page)
            kind = "media" if is_media_url(url) else "http"
        connections = connections or self.config["connections"]
        headers = {k: v for k, v in (headers or {}).items() if v}
        options = {"quality": quality} if quality else {}
        if cookie_jar and kind == "media":
            options["cookies"] = cookie_jar  # DB is 0600; never shown in the UI
        now = time.time()
        id_ = self.store.insert(url=url, kind=kind, filename=filename, dest_dir=dest_dir,
                                status=Status.PAUSED, connections=connections,
                                headers=json.dumps(headers), added=now, options=json.dumps(options))
        with self._lock:
            # Register the Item before the task exists so the dir resolver sees it.
            self.items[id_] = Item(id_, url, kind, None, connections, headers, now, options=options)
            self.items[id_].task = self._make_task(id_, url, kind, filename, None, dest_dir,
                                                   connections, headers, options)
            self.items[id_].task.status = Status.PAUSED
        self._notify(id_, "added")
        if start:
            self.start(id_)
        return id_

    def start(self, id_: int) -> None:
        with self._lock:
            item = self.items[id_]
            if item.task.is_running() or item.task.status == Status.COMPLETED:
                return
            item.queued = True
        self._persist(id_, force=True)
        self._notify(id_, "status")
        self._schedule()

    def pause(self, id_: int) -> None:
        with self._lock:
            item = self.items.get(id_)
            if not item:
                return
            item.queued = False
        item.task.pause(wait=False)
        if not item.task.is_running() and item.task.status not in (Status.COMPLETED, Status.ERROR):
            item.task.status = Status.PAUSED
        self._persist(id_, force=True)
        self._notify(id_, "status")

    def remove(self, id_: int, delete_file: bool = False) -> None:
        with self._lock:
            item = self.items.pop(id_, None)
        if not item:
            return
        item.queued = False
        item.task.pause(wait=True)
        item.task.discard_files()
        if delete_file and item.task.path and os.path.isfile(item.task.path) \
                and item.task.status == Status.COMPLETED:
            os.remove(item.task.path)
        self.store.delete(id_)
        self._notify(id_, "removed")
        self._schedule()

    def redownload(self, id_: int) -> None:
        with self._lock:
            item = self.items[id_]
            item.task.pause(wait=True)
            item.task.discard_files()
            item.task = self._make_task(id_, item.url, item.kind, None, None, None,
                                        item.connections, item.headers, item.options)
            item.finished = None
        self.start(id_)

    def start_all(self) -> None:
        for id_, it in list(self.items.items()):
            if it.task.status in (Status.PAUSED, Status.ERROR, Status.QUEUED):
                self.start(id_)

    def pause_all(self) -> None:
        for id_ in list(self.items):
            self.pause(id_)

    def set_speed_limit(self, rate: float) -> None:
        self.config["speed_limit"] = rate
        self.config.save()
        self.global_limiter.set_rate(rate)

    def snapshot(self) -> list[dict]:
        with self._lock:
            return [it.snapshot() for it in self.items.values()]

    def get(self, id_: int) -> dict | None:
        it = self.items.get(id_)
        return it.snapshot() if it else None

    def shutdown(self) -> None:
        running = [it for it in self.items.values() if it.task.is_running()]
        for it in running:
            it.task.pause(wait=False)
        for it in running:
            it.task.pause(wait=True)
            self._persist(it.id, force=True)

    # ---------------- internals ---------------- #
    def _schedule(self) -> None:
        with self._lock:
            running = sum(1 for it in self.items.values() if it.task.is_running())
            slots = max(0, int(self.config["max_concurrent"]) - running)
            for it in sorted(self.items.values(), key=lambda i: i.id):
                if slots <= 0:
                    break
                if it.queued and not it.task.is_running():
                    it.queued = False
                    it.task.start()
                    slots -= 1

    def _on_task_event(self, id_: int, kind: str) -> None:
        item = self.items.get(id_)
        if not item:
            return
        if kind == "status":
            st = item.task.status
            if st == Status.COMPLETED:
                item.finished = time.time()
            self._persist(id_, force=True)
            self._notify(id_, "completed" if st == Status.COMPLETED else
                         "error" if st == Status.ERROR else "status")
            if st in (Status.COMPLETED, Status.ERROR, Status.PAUSED):
                # Task thread is about to exit; schedule after it does.
                threading.Thread(target=self._schedule_after, args=(item.task,), daemon=True).start()
        else:
            self._persist(id_)
            self._notify(id_, "progress")

    def _schedule_after(self, task) -> None:
        t = getattr(task, "_thread", None)
        if t and t is not threading.current_thread():
            t.join(10)
        self._schedule()

    def _persist(self, id_: int, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_persist.get(id_, 0) < 3:
            return
        self._last_persist[id_] = now
        item = self.items.get(id_)
        if not item:
            return
        t = item.task
        self.store.update(id_, filename=t.filename, path=t.path, status=item.status, size=t.size,
                          downloaded=t.downloaded, error=t.error, finished=item.finished,
                          category=item.category)
