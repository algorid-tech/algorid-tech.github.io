"""Local HTTP API on 127.0.0.1 used by the browser extension and the CLI.

Security model
--------------
* Binds to loopback only.
* Requests carrying a web Origin (http/https) are refused, so a random web page
  cannot make the app download files (CSRF). Extensions send
  ``chrome-extension://`` / ``moz-extension://`` origins; the CLI sends none.
* POSTs need the ``X-Algorid-Token`` header, which forces a CORS preflight that
  this server never approves for web pages. The token is random per install
  and lives in config.json (0600); it is never part of the source code.
* Pairing: an extension calls POST /pair, the desktop app asks the user
  "Allow this extension?", and only on Allow is the token returned. This keeps
  other installed extensions from silently using Algorid Fetch.
"""
from __future__ import annotations

import hmac
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable

from .config import VERSION, Config

ALLOWED_ORIGIN_PREFIXES = ("chrome-extension://", "moz-extension://", "extension://")


def build_headers(payload: dict) -> dict:
    h = {}
    if payload.get("referrer"):
        h["Referer"] = payload["referrer"]
    if payload.get("user_agent"):
        h["User-Agent"] = payload["user_agent"]
    cookies = payload.get("cookies")
    if isinstance(cookies, list):
        cookies = "; ".join(f"{c['name']}={c['value']}" for c in cookies if "name" in c)
    if cookies:
        h["Cookie"] = cookies
    return h


class ApiServer:
    def __init__(self, manager, config: Config, on_browser_add: Callable[[dict], None] | None = None,
                 on_pair: Callable[[str], bool] | None = None,
                 on_show: Callable[[], None] | None = None):
        self.manager = manager
        self.config = config
        self.on_browser_add = on_browser_add
        self.on_pair = on_pair          # asks the user; returns True to approve
        self._pair_lock = threading.Lock()
        self.on_show = on_show          # raise the window (second launch)
        self.last_extension_seen = 0.0  # for "Your browser is connected"
        self.httpd: ThreadingHTTPServer | None = None

    def start(self) -> None:
        api = self

        class Handler(BaseHTTPRequestHandler):
            server_version = f"AlgoridFetch/{VERSION}"

            def log_message(self, *a):
                pass

            def _origin_ok(self) -> bool:
                origin = self.headers.get("Origin")
                return not origin or origin.startswith(ALLOWED_ORIGIN_PREFIXES)

            def _token_ok(self) -> bool:
                tok = self.headers.get("X-Algorid-Token", "")
                return hmac.compare_digest(tok.encode(), api.config["api_token"].encode())

            def _send(self, code: int, obj) -> None:
                body = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                origin = self.headers.get("Origin")
                if origin and origin.startswith(ALLOWED_ORIGIN_PREFIXES):
                    self.send_header("Access-Control-Allow-Origin", origin)
                self.end_headers()
                self.wfile.write(body)

            def do_OPTIONS(self):
                if not self._origin_ok():
                    return self._send(403, {"error": "origin not allowed"})
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", ""))
                self.send_header("Access-Control-Allow-Methods", "GET, POST")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Algorid-Token")
                self.end_headers()

            def do_GET(self):
                if not self._origin_ok():
                    return self._send(403, {"error": "origin not allowed"})
                origin = self.headers.get("Origin", "")
                if self._token_ok() and origin.startswith(ALLOWED_ORIGIN_PREFIXES):
                    api.last_extension_seen = time.time()
                if self.path == "/ping":
                    return self._send(200, {"app": "algorid-fetch", "version": VERSION,
                                            "authorized": self._token_ok(),
                                            "pairing": api.on_pair is not None})
                if not self._token_ok():
                    return self._send(401, {"error": "bad token"})
                if self.path == "/list":
                    snap = api.manager.snapshot()
                    for s in snap:
                        s.pop("segments", None)
                    return self._send(200, snap)
                self._send(404, {"error": "not found"})

            def do_POST(self):
                if not self._origin_ok():
                    return self._send(403, {"error": "origin not allowed"})
                if self.path == "/pair":
                    return self._pair()
                if not self._token_ok():
                    return self._send(401, {"error": "bad token"})
                try:
                    n = int(self.headers.get("Content-Length", "0"))
                    if n > 1_000_000:
                        return self._send(413, {"error": "too large"})
                    payload = json.loads(self.rfile.read(n) or b"{}")
                except (ValueError, json.JSONDecodeError):
                    return self._send(400, {"error": "invalid json"})
                if self.path == "/add":
                    return self._add(payload)
                if self.path == "/show":
                    if api.on_show is None:
                        return self._send(501, {"error": "headless daemon has no window"})
                    api.on_show()
                    return self._send(200, {"ok": True})
                if self.path in ("/pause", "/resume", "/remove"):
                    id_ = payload.get("id")
                    if id_ not in api.manager.items:
                        return self._send(404, {"error": "unknown id"})
                    {"/pause": api.manager.pause, "/resume": api.manager.start,
                     "/remove": api.manager.remove}[self.path](id_)
                    return self._send(200, {"ok": True})
                self._send(404, {"error": "not found"})

            def _pair(self):
                origin = self.headers.get("Origin", "")
                if not origin.startswith(ALLOWED_ORIGIN_PREFIXES):
                    return self._send(403, {"error": "only browser extensions can pair"})
                if api.on_pair is None:
                    return self._send(501, {"error": "open the Algorid Fetch window to pair, or paste the "
                                                     "token from `algorid-fetch token`"})
                if not api._pair_lock.acquire(blocking=False):
                    return self._send(409, {"error": "another pairing request is waiting"})
                try:
                    approved = api.on_pair(origin)
                finally:
                    api._pair_lock.release()
                if not approved:
                    return self._send(403, {"error": "denied in Algorid Fetch"})
                self._send(200, {"token": api.config["api_token"]})

            def _add(self, payload):
                url = str(payload.get("url", ""))
                if not url.lower().startswith(("http://", "https://")):
                    return self._send(400, {"error": "url must be http(s)"})
                payload["headers"] = build_headers(payload)
                jar = payload.get("cookies")
                payload["cookie_jar"] = [c for c in jar if isinstance(c, dict) and c.get("domain")] \
                    if isinstance(jar, list) else None
                if payload.get("ask") and api.on_browser_add and api.config["browser_confirm_dialog"]:
                    api.on_browser_add(payload)
                    return self._send(202, {"pending": True})
                kind = "media" if payload.get("media") else payload.get("kind")
                id_ = api.manager.add(url, filename=payload.get("filename") or None,
                                      headers=payload["headers"], kind=kind,
                                      connections=payload.get("connections"),
                                      quality=payload.get("quality"),
                                      cookie_jar=payload.get("cookie_jar"))
                self._send(200, {"id": id_})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", int(self.config["api_port"])), Handler)
        self.httpd.daemon_threads = True
        threading.Thread(target=self.httpd.serve_forever, daemon=True, name="af-api").start()

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
