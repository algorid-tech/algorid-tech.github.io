"""The app's own line icons, drawn with QPainter.

Desktop icon themes differ (Windows has none at all), so the toolbar and
sidebar draw their icons here: same look everywhere, no SVG plugin needed.
Each icon is drawn in a 24x24 box with a 2px round stroke.
"""
from __future__ import annotations

from .qt import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap, QPointF, QRectF, Qt


def _pen(color: QColor) -> QPen:
    pen = QPen(color, 2.0)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    return pen


def _poly(p: QPainter, pts, close=False, fill=None):
    path = QPainterPath(QPointF(*pts[0]))
    for x, y in pts[1:]:
        path.lineTo(x, y)
    if close:
        path.closeSubpath()
    if fill is not None:
        p.fillPath(path, fill)
    p.drawPath(path)


def _draw(name: str, p: QPainter, c: QColor) -> None:  # noqa: C901 - one branch per icon
    if name == "add":
        _poly(p, [(12, 5), (12, 19)]); _poly(p, [(5, 12), (19, 12)])
    elif name == "play":
        _poly(p, [(8, 5), (19, 12), (8, 19)], close=True, fill=c)
    elif name == "pause":
        p.fillRect(QRectF(6.5, 5, 3.5, 14), c); p.fillRect(QRectF(14, 5, 3.5, 14), c)
    elif name == "play-all":
        _poly(p, [(4, 6), (12, 12), (4, 18)], close=True, fill=c)
        _poly(p, [(12, 6), (20, 12), (12, 18)], close=True, fill=c)
    elif name == "pause-all":
        p.drawEllipse(QRectF(3, 3, 18, 18))
        _poly(p, [(10, 9), (10, 15)]); _poly(p, [(14, 9), (14, 15)])
    elif name == "remove":
        _poly(p, [(4, 7), (20, 7)]); _poly(p, [(9, 7), (9.5, 4), (14.5, 4), (15, 7)])
        _poly(p, [(6, 7), (7, 20), (17, 20), (18, 7)])
    elif name == "folder":
        _poly(p, [(3, 6), (9, 6), (11, 8), (21, 8), (21, 19), (3, 19)], close=True)
    elif name == "settings":
        p.drawEllipse(QRectF(9, 9, 6, 6))
        for a, b in [((12, 2.5), (12, 5.5)), ((12, 18.5), (12, 21.5)), ((2.5, 12), (5.5, 12)),
                     ((18.5, 12), (21.5, 12)), ((5.3, 5.3), (7.4, 7.4)), ((16.6, 16.6), (18.7, 18.7)),
                     ((5.3, 18.7), (7.4, 16.6)), ((16.6, 7.4), (18.7, 5.3))]:
            _poly(p, [a, b])
        p.drawEllipse(QRectF(6, 6, 12, 12))
    elif name == "all":
        for y in (6, 12, 18):
            _poly(p, [(8, y), (20, y)]); p.drawPoint(QPointF(4, y))
    elif name == "running":
        _poly(p, [(12, 4), (12, 15)]); _poly(p, [(7, 10), (12, 15), (17, 10)]); _poly(p, [(5, 20), (19, 20)])
    elif name == "incomplete":
        p.drawEllipse(QRectF(3, 3, 18, 18)); _poly(p, [(12, 7), (12, 12), (15.5, 14)])
    elif name == "completed":
        _poly(p, [(5, 12.5), (10, 17.5), (19, 7)])
    elif name == "video":
        p.drawRoundedRect(QRectF(3, 6, 13, 12), 2, 2); _poly(p, [(16, 10), (21, 7), (21, 17), (16, 14)])
    elif name == "audio":
        _poly(p, [(9, 18), (9, 6), (19, 4), (19, 16)])
        p.drawEllipse(QRectF(4, 15, 5, 5)); p.drawEllipse(QRectF(14, 13, 5, 5))
    elif name == "document":
        _poly(p, [(6, 3), (14, 3), (19, 8), (19, 21), (6, 21)], close=True); _poly(p, [(14, 3), (14, 8), (19, 8)])
        _poly(p, [(9, 13), (16, 13)]); _poly(p, [(9, 17), (16, 17)])
    elif name == "archive":
        p.drawRect(QRectF(4, 4, 16, 5)); _poly(p, [(5, 9), (5, 20), (19, 20), (19, 9)]); _poly(p, [(10, 13), (14, 13)])
    elif name == "apps":
        for x, y in ((4, 4), (13, 4), (4, 13), (13, 13)):
            p.drawRoundedRect(QRectF(x, y, 7, 7), 1.5, 1.5)
    elif name == "image":
        p.drawRoundedRect(QRectF(3, 5, 18, 14), 2, 2); _poly(p, [(5, 17), (10, 11), (14, 15), (16, 13), (19, 17)])
        p.drawEllipse(QRectF(14.5, 7.5, 3, 3))
    elif name == "other":
        for x in (6, 12, 18):
            p.setBrush(c); p.drawEllipse(QPointF(x, 12), 1.3, 1.3); p.setBrush(Qt.BrushStyle.NoBrush)
    elif name == "browser":
        p.drawRoundedRect(QRectF(3, 4, 18, 16), 2, 2); _poly(p, [(3, 9), (21, 9)])
        p.drawPoint(QPointF(6, 6.5)); p.drawPoint(QPointF(9, 6.5))
    elif name == "error":
        p.drawEllipse(QRectF(3, 3, 18, 18)); _poly(p, [(12, 7.5), (12, 13)]); p.drawPoint(QPointF(12, 16.5))
    elif name == "copy":
        p.drawRoundedRect(QRectF(8, 8, 12, 12), 2, 2); _poly(p, [(16, 8), (16, 4), (4, 4), (4, 16), (8, 16)])


def icon(name: str, color: QColor, selected: QColor | None = QColor("white")) -> QIcon:
    """Icon in `color`; rows/items that are selected (blue highlight) get `selected`."""
    ic = QIcon()
    _paint_into(ic, name, color, QIcon.Mode.Normal)
    if selected is not None:
        _paint_into(ic, name, selected, QIcon.Mode.Selected)
    return ic


def _paint_into(ic: QIcon, name: str, color: QColor, mode) -> None:
    for size in (16, 24, 32, 48):
        pm = QPixmap(size, size)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.scale(size / 24.0, size / 24.0)
        p.setPen(_pen(color))
        p.setBrush(Qt.BrushStyle.NoBrush)
        _draw(name, p, color)
        p.end()
        ic.addPixmap(pm, mode)
