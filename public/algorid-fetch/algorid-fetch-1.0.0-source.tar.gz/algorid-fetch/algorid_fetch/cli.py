"""algorid-fetch command line.

  algorid-fetch                      open the GUI
  algorid-fetch get URL [URL...]     download in the terminal (no GUI needed)
  algorid-fetch add URL [--media]    send to the running GUI/daemon queue
  algorid-fetch list                 show the running instance's queue
  algorid-fetch daemon               headless queue + browser API (servers, VPS)
  algorid-fetch token                print the browser-extension token
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import signal
import sys
import threading
import time
import urllib.error
import urllib.request

from .config import VERSION, Config
from .engine import Download, RateLimiter, Status, human_size, human_time, parse_rate


def _api(cfg: Config, path: str, payload: dict | None = None, timeout: float = 3):
    url = f"http://127.0.0.1:{cfg['api_port']}{path}"
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json", "X-Algorid-Token": cfg["api_token"]})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # never proxy loopback
    with opener.open(req, timeout=timeout) as r:
        return json.loads(r.read() or b"null")


def instance_running(cfg: Config) -> bool:
    try:
        return _api(cfg, "/ping").get("app") == "algorid-fetch"
    except (OSError, ValueError, AttributeError):
        return False


def _parse_headers(items):
    out = {}
    for h in items or []:
        k, _, v = h.partition(":")
        out[k.strip()] = v.strip()
    return out


def _bar(d: Download, width: int) -> str:
    p = d.progress
    w = max(10, width - 62)
    if p is None:
        filled = "?" * 3
        bar = filled.ljust(w)
        pct = " ?%"
    else:
        n = int(p * w)
        bar = "█" * n + "░" * (w - n)
        pct = f"{p * 100:5.1f}%"
    return (f"\r{bar} {pct} {human_size(d.downloaded):>10}/{human_size(d.size):<10} "
            f"{human_size(d.speed) + '/s':>11} ETA {human_time(d.eta):>8} [{d.active_connections:>2}c]")


def cmd_get(a, cfg: Config) -> int:
    limiter = RateLimiter(parse_rate(a.limit))
    headers = _parse_headers(a.header)
    if a.referer:
        headers["Referer"] = a.referer
    out = a.output or (os.getcwd() if not a.categorize else None)
    rc = 0
    for url in a.urls:
        d = Download(url, out or cfg.dir_for, filename=a.name, connections=a.connections,
                     headers=headers, limiters=[limiter])
        interrupted = threading.Event()

        def on_sigint(*_):
            interrupted.set()
            d.pause(wait=False)

        old = signal.signal(signal.SIGINT, on_sigint)
        d.start()
        tty = sys.stderr.isatty()
        while d.is_running():
            if tty and d.status == Status.DOWNLOADING:
                sys.stderr.write(_bar(d, shutil.get_terminal_size().columns))
                sys.stderr.flush()
            time.sleep(0.25)
        d.wait()
        signal.signal(signal.SIGINT, old)
        if tty:
            sys.stderr.write("\n")
        if d.status == Status.COMPLETED:
            msg = f"✔ {d.path} ({human_size(d.size)})"
            if a.sha256:
                h = hashlib.sha256()
                with open(d.path, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""):
                        h.update(chunk)
                ok = h.hexdigest().lower() == a.sha256.lower()
                msg += " sha256 OK" if ok else f" sha256 MISMATCH ({h.hexdigest()})"
                rc = rc or (0 if ok else 3)
            print(msg)
        elif d.status == Status.PAUSED:
            print(f"⏸ paused, rerun the same command to resume: {d.path}{'.afpart'}")
            return 130
        else:
            print(f"✘ {url}: {d.error}", file=sys.stderr)
            rc = 1
    return rc


def cmd_add(a, cfg: Config) -> int:
    if not instance_running(cfg):
        print("Algorid Fetch is not running. Start it with `algorid-fetch` or `algorid-fetch daemon`, "
              "or download directly with `algorid-fetch get URL`.", file=sys.stderr)
        return 2
    for url in a.urls:
        r = _api(cfg, "/add", {"url": url, "media": a.media, "filename": a.name,
                               "connections": a.connections, "referrer": a.referer})
        print(f"queued #{r.get('id')}: {url}")
    return 0


def cmd_list(a, cfg: Config) -> int:
    if not instance_running(cfg):
        print("Algorid Fetch is not running.", file=sys.stderr)
        return 2
    for s in _api(cfg, "/list"):
        p = f"{s['progress'] * 100:5.1f}%" if s["progress"] is not None else "   ?%"
        print(f"#{s['id']:<4} {s['status']:<11} {p} {human_size(s['size']):>10} "
              f"{human_size(s['speed']) + '/s':>11}  {s['filename']}")
    return 0


def cmd_daemon(a, cfg: Config) -> int:
    from .api import ApiServer
    from .manager import Manager

    if instance_running(cfg):
        print("another Algorid Fetch instance is already running", file=sys.stderr)
        return 2
    mgr = Manager(cfg)
    api = ApiServer(mgr, cfg)
    api.start()
    print(f"Algorid Fetch daemon on 127.0.0.1:{cfg['api_port']} (Ctrl+C to stop)")
    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    if a.resume:
        mgr.start_all()
    stop.wait()
    print("saving state...")
    mgr.shutdown()
    api.stop()
    return 0


def _windows_console_safe() -> None:
    """Windows consoles and pipes may not be UTF-8: never crash on ✔ or █."""
    if os.name != "nt":
        return
    for stream in (sys.stdout, sys.stderr):
        if stream is None:  # windowed build has no console
            continue
        try:
            if stream.isatty():
                stream.reconfigure(errors="replace")
            else:
                stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None) -> int:
    _windows_console_safe()
    p = argparse.ArgumentParser(prog="algorid-fetch", description="Algorid Fetch: fast, resumable multi-connection downloads")
    p.add_argument("--version", action="version", version=f"algorid-fetch {VERSION}")
    sub = p.add_subparsers(dest="cmd")

    g = sub.add_parser("get", help="download now, in this terminal")
    g.add_argument("urls", nargs="+")
    g.add_argument("-c", "--connections", type=int, default=None)
    g.add_argument("-o", "--output", help="directory (default: current dir)")
    g.add_argument("-n", "--name", help="output filename (single URL)")
    g.add_argument("-l", "--limit", default="0", help="speed limit, e.g. 500K, 2M")
    g.add_argument("-H", "--header", action="append", help="'Name: value' (repeatable)")
    g.add_argument("-r", "--referer")
    g.add_argument("--categorize", action="store_true", help="save into category folders")
    g.add_argument("--sha256", help="verify the file after download")

    ad = sub.add_parser("add", help="queue in the running app")
    ad.add_argument("urls", nargs="+")
    ad.add_argument("--media", action="store_true", help="grab video/audio via yt-dlp")
    ad.add_argument("-n", "--name")
    ad.add_argument("-c", "--connections", type=int)
    ad.add_argument("-r", "--referer")

    sub.add_parser("list", help="show queue of the running app")
    dm = sub.add_parser("daemon", help="run headless with the browser API")
    dm.add_argument("--resume", action="store_true", help="resume incomplete downloads on start")
    sub.add_parser("token", help="print the browser extension token")
    sub.add_parser("setup-browsers", help="register the browser launcher for this user")
    sub.add_parser("update-ytdlp", help="install/update video components (yt-dlp + Deno)")
    gp = sub.add_parser("gui", help="open the GUI (default)")
    gp.add_argument("--minimized", action="store_true", help="start hidden in the tray")
    gp.add_argument("--welcome", action="store_true", help="show the browser setup guide")

    a = p.parse_args(argv)
    cfg = Config()
    if a.cmd == "get":
        a.connections = a.connections or cfg["connections"]
        return cmd_get(a, cfg)
    if a.cmd == "add":
        return cmd_add(a, cfg)
    if a.cmd == "list":
        return cmd_list(a, cfg)
    if a.cmd == "daemon":
        return cmd_daemon(a, cfg)
    if a.cmd == "setup-browsers":
        from .browsers import host_path, install_user_manifests
        if not host_path():
            print("launcher not found (algorid-fetch-native-host); reinstall the package", file=sys.stderr)
            return 1
        for p in install_user_manifests():
            print(f"registered: {p}")
        print("browser launcher is set up")
        return 0
    if a.cmd == "update-ytdlp":
        from .media import install_video_tools, video_tools_status
        print(f"current: {video_tools_status()}")
        try:
            print(f"now:     {install_video_tools(update=True)}")
            return 0
        except Exception as e:  # noqa: BLE001
            print(f"failed: {e}", file=sys.stderr)
            return 1
    if a.cmd == "token":
        print(cfg["api_token"])
        return 0
    from .gui import run_gui
    return run_gui(cfg, minimized=getattr(a, "minimized", False), welcome=getattr(a, "welcome", False))


if __name__ == "__main__":
    sys.exit(main())
