"""Video/audio grabbing through yt-dlp (optional), with the Download interface."""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import threading
import urllib.parse

from .config import DATA_DIR, MEDIA_HOSTS
from .engine import Status

# Ubuntu's apt yt-dlp is often too old for YouTube; Algorid Fetch can keep its own
# up-to-date standalone build here (no Python version requirements).
IS_WINDOWS = os.name == "nt"
EXE = ".exe" if IS_WINDOWS else ""
BIN_DIR = os.path.join(DATA_DIR, "bin")
# Console tools must not flash a window when the GUI runs them on Windows.
NO_WINDOW = {"creationflags": 0x08000000} if IS_WINDOWS else {}

PRIVATE_YTDLP = os.path.join(BIN_DIR, "yt-dlp" + EXE)
YTDLP_ASSETS = {"x86_64": "yt-dlp.exe", "amd64": "yt-dlp.exe", "x86": "yt-dlp_x86.exe"} if IS_WINDOWS else {
                "x86_64": "yt-dlp_linux", "amd64": "yt-dlp_linux",
                "aarch64": "yt-dlp_linux_aarch64", "arm64": "yt-dlp_linux_aarch64",
                "armv7l": "yt-dlp_linux_armv7l"}


def ytdlp_command() -> list[str] | None:
    if os.access(PRIVATE_YTDLP, os.X_OK):
        return [PRIVATE_YTDLP]
    exe = shutil.which("yt-dlp")
    if exe:
        return [exe]
    try:
        import yt_dlp  # noqa: F401
        return [sys.executable, "-m", "yt_dlp"]
    except ImportError:
        return None


QUALITIES = [("best", "Best available"), ("2160", "4K (2160p)"), ("1440", "1440p"),
             ("1080", "1080p"), ("720", "720p"), ("480", "480p"), ("360", "360p"),
             ("audio", "Audio only (m4a)")]


PRIVATE_FFMPEG = os.path.join(BIN_DIR, "ffmpeg" + EXE)
FFMPEG_WINDOWS_URL = ("https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/"
                      "ffmpeg-master-latest-win64-gpl.zip")


def ffmpeg_location() -> str | None:
    if os.path.exists(PRIVATE_FFMPEG):
        return PRIVATE_FFMPEG
    return shutil.which("ffmpeg")


def has_ffmpeg() -> bool:
    return ffmpeg_location() is not None


def install_ffmpeg() -> str:
    """Windows only: fetch ffmpeg.exe + ffprobe.exe (yt-dlp's recommended builds)."""
    import zipfile

    from .engine import Download

    os.makedirs(BIN_DIR, exist_ok=True)
    zpath = os.path.join(BIN_DIR, "ffmpeg-download.zip")
    for p in (zpath, zpath + ".afpart", zpath + ".afstate"):
        if os.path.exists(p):
            os.remove(p)
    dl = Download(FFMPEG_WINDOWS_URL, BIN_DIR, path=zpath, connections=8)
    dl.start()
    if dl.wait() != Status.COMPLETED:
        raise RuntimeError(dl.error or "ffmpeg download failed")
    try:
        with zipfile.ZipFile(zpath) as z:
            for member in z.namelist():
                base = member.rsplit("/", 1)[-1]
                if base in ("ffmpeg.exe", "ffprobe.exe") and "/bin/" in member:
                    with open(os.path.join(BIN_DIR, base + ".new"), "wb") as out:
                        out.write(z.read(member))
                    os.replace(os.path.join(BIN_DIR, base + ".new"), os.path.join(BIN_DIR, base))
    finally:
        os.remove(zpath)
    if not os.path.exists(PRIVATE_FFMPEG):
        raise RuntimeError("ffmpeg.exe not found in the download")
    return "ok"


def format_for(quality: str | None) -> str:
    """yt-dlp format selector. Above 360p, YouTube serves video and audio
    separately, so HD needs ffmpeg to merge them; without it we pick the best
    single-file format instead of failing."""
    ff = has_ffmpeg()
    if quality == "audio":
        return "ba[ext=m4a]/ba/b"
    if not quality or quality == "best":
        return "bv*+ba/b" if ff else "b"
    h = int(quality)
    if ff:
        return f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b"
    return f"b[height<={h}]/b"


def ytdlp_version() -> str | None:
    cmd = ytdlp_command()
    if not cmd:
        return None
    try:
        r = subprocess.run(cmd + ["--version"], capture_output=True, text=True, timeout=30, **NO_WINDOW)
        return r.stdout.strip() or None
    except (OSError, subprocess.TimeoutExpired):
        return None


def install_ytdlp(on_progress=None) -> str:
    """Download the latest standalone yt-dlp into PRIVATE_YTDLP. Returns version."""
    import platform

    from .engine import Download

    asset = YTDLP_ASSETS.get(platform.machine().lower())
    if not asset:
        raise RuntimeError(f"no yt-dlp build for {platform.machine()}; use: pipx install yt-dlp")
    d = os.path.dirname(PRIVATE_YTDLP)
    os.makedirs(d, exist_ok=True)
    tmp = PRIVATE_YTDLP + ".new"
    for p in (tmp, tmp + ".afpart", tmp + ".afstate"):
        if os.path.exists(p):
            os.remove(p)
    dl = Download(f"https://github.com/yt-dlp/yt-dlp/releases/latest/download/{asset}", d,
                  path=tmp, connections=4,
                  on_event=(lambda t, k: on_progress(t)) if on_progress else None)
    dl.start()
    if dl.wait() != Status.COMPLETED:
        raise RuntimeError(dl.error or "download failed")
    os.chmod(tmp, 0o755)
    r = subprocess.run([tmp, "--version"], capture_output=True, text=True, timeout=60, **NO_WINDOW)
    if r.returncode != 0:
        os.remove(tmp)
        raise RuntimeError("downloaded yt-dlp does not run on this system")
    os.replace(tmp, PRIVATE_YTDLP)
    return r.stdout.strip()


# --------------------------------------------------------------------------- #
# JavaScript runtime: since yt-dlp 2025.11 YouTube needs one (Deno recommended)
# to solve its player challenges. Ubuntu's nodejs is too old on 22.04/24.04,
# so Algorid Fetch keeps its own Deno next to its yt-dlp.
# --------------------------------------------------------------------------- #
PRIVATE_DENO = os.path.join(BIN_DIR, "deno" + EXE)
DENO_ASSETS = {"x86_64": "deno-x86_64-pc-windows-msvc.zip", "amd64": "deno-x86_64-pc-windows-msvc.zip"} \
    if IS_WINDOWS else {"x86_64": "deno-x86_64-unknown-linux-gnu.zip", "amd64": "deno-x86_64-unknown-linux-gnu.zip",
               "aarch64": "deno-aarch64-unknown-linux-gnu.zip", "arm64": "deno-aarch64-unknown-linux-gnu.zip"}


def _node_ok(path: str) -> bool:
    try:
        v = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=15, **NO_WINDOW).stdout
        return int(v.strip().lstrip("v").split(".")[0]) >= 20  # yt-dlp minimum
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return False


def js_runtime() -> tuple[str, str] | None:
    """(name, path) of a JS runtime yt-dlp can use, preferring Algorid Fetch's Deno."""
    if os.access(PRIVATE_DENO, os.X_OK):
        return "deno", PRIVATE_DENO
    deno = shutil.which("deno")
    if deno:
        return "deno", deno
    node = shutil.which("node") or shutil.which("nodejs")
    if node and _node_ok(node):
        return "node", node
    return None


def deno_version() -> str | None:
    rt = js_runtime()
    if not rt:
        return None
    try:
        out = subprocess.run([rt[1], "--version"], capture_output=True, text=True, timeout=15, **NO_WINDOW).stdout
        first = out.strip().splitlines()[0] if out.strip() else ""
        return f"{rt[0]} {first.split()[1].lstrip('v')}" if len(first.split()) > 1 else rt[0]
    except (OSError, subprocess.TimeoutExpired, IndexError):
        return rt[0]


def install_deno(on_progress=None) -> str:
    """Download Deno's official single-file build into PRIVATE_DENO."""
    import platform
    import zipfile

    from .engine import Download

    asset = DENO_ASSETS.get(platform.machine().lower())
    if not asset:
        raise RuntimeError(f"no Deno build for {platform.machine()}; install Node.js 20+ instead")
    d = os.path.dirname(PRIVATE_DENO)
    os.makedirs(d, exist_ok=True)
    zpath = os.path.join(d, "deno-download.zip")
    for p in (zpath, zpath + ".afpart", zpath + ".afstate"):
        if os.path.exists(p):
            os.remove(p)
    dl = Download(f"https://github.com/denoland/deno/releases/latest/download/{asset}", d,
                  path=zpath, connections=4,
                  on_event=(lambda t, k: on_progress(t)) if on_progress else None)
    dl.start()
    if dl.wait() != Status.COMPLETED:
        raise RuntimeError(dl.error or "Deno download failed")
    tmp = PRIVATE_DENO + ".new"
    try:
        with zipfile.ZipFile(zpath) as z, open(tmp, "wb") as out:
            out.write(z.read("deno" + EXE))  # extract only the one expected member
    finally:
        os.remove(zpath)
    os.chmod(tmp, 0o755)
    r = subprocess.run([tmp, "--version"], capture_output=True, text=True, timeout=60, **NO_WINDOW)
    if r.returncode != 0:
        os.remove(tmp)
        raise RuntimeError("downloaded Deno does not run on this system")
    os.replace(tmp, PRIVATE_DENO)
    return r.stdout.split()[1] if len(r.stdout.split()) > 1 else "ok"


def video_tools_ready() -> bool:
    return bool(ytdlp_command() and js_runtime() and (has_ffmpeg() or not IS_WINDOWS))


def install_video_tools(update: bool = False) -> str:
    """Install (or update) yt-dlp and Deno. Returns a short status line."""
    if update or not ytdlp_command():
        install_ytdlp()
    if (update and os.path.exists(PRIVATE_DENO)) or not js_runtime():
        install_deno()
    if IS_WINDOWS and (not has_ffmpeg() or (update and os.path.exists(PRIVATE_FFMPEG))):
        install_ffmpeg()
    return video_tools_status()


def video_tools_status() -> str:
    y, j = ytdlp_version(), deno_version()
    return f"yt-dlp {y or 'missing'} · {j or 'JS runtime missing'}"


def auto_update_in_background(max_age_days: int = 7) -> None:
    """YouTube changes often; refresh Algorid Fetch's own yt-dlp weekly, quietly."""
    import threading
    import time

    try:
        age = time.time() - os.path.getmtime(PRIVATE_YTDLP)
    except OSError:
        return  # not ours (system yt-dlp) or not installed
    if age < max_age_days * 86400:
        return

    def run():
        try:
            subprocess.run([PRIVATE_YTDLP, "-U"], capture_output=True, timeout=300, **NO_WINDOW)
            os.utime(PRIVATE_YTDLP)  # don't retry on every download if already current
        except (OSError, subprocess.TimeoutExpired):
            pass
    threading.Thread(target=run, daemon=True, name="af-ytdlp-update").start()


# yt-dlp messages -> what the user should do
_HINTS = [
    ("not a bot", "YouTube wants to confirm you're not a bot. Log in to YouTube in Chrome and use the "
                  "extension's Download button (it passes your login), or try again later."),
    ("Sign in to confirm your age", "Age-restricted video: log in to YouTube in Chrome and use the "
                                    "extension's Download button."),
    ("Requested format is not available", "YouTube didn't offer that quality. Update video components "
                                          "(Settings → Video downloads), or pick 'Best available'."),
    ("n challenge", "YouTube changed its player. Update video components (Settings → Video downloads)."),
    ("JavaScript runtime", "A JavaScript runtime is needed for YouTube. Install video components "
                           "(Settings → Video downloads)."),
    ("HTTP Error 403", "The site refused the download (403). If the video needs a login, use the "
                       "extension's Download button while logged in; otherwise update video "
                       "components (Settings → Video downloads)."),
    ("Private video", "This video is private."),
    ("Video unavailable", "This video is unavailable (removed, private or blocked in your country)."),
    ("members-only", "Members-only video: log in to YouTube in Chrome and use the extension's button."),
    ("Unsupported URL", "This page has no downloadable video that yt-dlp recognizes."),
    ("ffmpeg", "ffmpeg is needed for this quality: sudo apt install ffmpeg (or choose a lower quality)."),
]


def explain(text: str) -> str | None:
    low = text.lower()
    for needle, hint in _HINTS:
        if needle.lower() in low:
            return hint
    return None


def is_media_url(url: str) -> bool:
    host = (urllib.parse.urlparse(url).hostname or "").lower()
    return any(host == h or host.endswith("." + h) for h in MEDIA_HOSTS)


class MediaDownload:
    kind = "media"
    PREFIX = "AFP"

    def __init__(self, url, dest_dir, filename=None, headers=None, on_event=None,
                 quality=None, speed_limit=0, path=None, cookie_jar=None, **_):
        self.url = url
        self.dest_dir = dest_dir
        self.headers = dict(headers or {})
        self.on_event = on_event
        self.quality = quality
        self.cookie_jar = cookie_jar or []
        self.speed_limit = speed_limit
        self.path = path
        self.filename = os.path.basename(path) if path else filename
        self.size = None
        self.speed = 0.0
        self.eta = None
        self.status = Status.QUEUED
        self.error = None
        self.resumable = True
        self.segments = []
        self._done = 0
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._paused = False
        self._tail: list[str] = []
        self.log = ""

    downloaded = property(lambda self: self._done)
    active_connections = property(lambda self: 1 if self.is_running() else 0)

    @property
    def progress(self):
        return min(1.0, self._done / self.size) if self.size else None

    def segment_map(self):
        return [(0, (self.size or 1) - 1, self._done)] if self.size else []

    def is_running(self):
        return bool(self._thread and self._thread.is_alive())

    def _emit(self, kind):
        if self.on_event:
            try:
                self.on_event(self, kind)
            except Exception:
                pass

    def start(self):
        if self.is_running():
            return
        self._paused = False
        self.error = None
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def pause(self, wait=True):
        self._paused = True
        if self._proc and self._proc.poll() is None:
            if IS_WINDOWS:
                self._proc.terminate()  # yt-dlp keeps its .part file and resumes later
            else:
                self._proc.send_signal(signal.SIGINT)
        if wait and self._thread:
            self._thread.join(15)
            if self._proc and self._proc.poll() is None:
                self._proc.kill()

    def wait(self, timeout=None):
        if self._thread:
            self._thread.join(timeout)
        return self.status

    def discard_files(self):
        pass  # yt-dlp manages its own .part files

    def _run(self):
        cmd = ytdlp_command()
        if not cmd:
            self.error = "yt-dlp is not installed: run `algorid-fetch update-ytdlp` (or Settings → yt-dlp), then Resume"
            self.status = Status.ERROR
            self._emit("status")
            return
        d = self.dest_dir("video.mp4") if callable(self.dest_dir) else self.dest_dir
        d = os.path.expanduser(d)
        os.makedirs(d, exist_ok=True)
        p = self.PREFIX
        args = cmd + [
            "--newline", "--progress", "--no-simulate", "--continue", "--no-playlist",
            "-f", format_for(self.quality), "-S", "res,ext:mp4:m4a", "-P", d,
            "-o", self.filename or "%(title).180B [%(id)s].%(ext)s",
            "--progress-template",
            f"download:{p}P %(progress.downloaded_bytes)s %(progress.total_bytes)s "
            f"%(progress.total_bytes_estimate)s %(progress.speed)s %(progress.eta)s",
            "--print", f"before_dl:{p}N %(filename)s",
            "--print", f"after_move:{p}F %(filepath)s",
        ]
        cookie_file = self._write_cookie_file() if self.cookie_jar else None
        if cookie_file:
            args += ["--cookies", cookie_file]
        rt = js_runtime()
        if rt:
            args += ["--js-runtimes", f"{rt[0]}:{rt[1]}"]
        ff = ffmpeg_location()
        if ff:
            args += ["--ffmpeg-location", ff]
        if self.speed_limit:
            args += ["-r", str(int(self.speed_limit))]
        for k, v in self.headers.items():
            # yt-dlp picks its own per-client user agents for YouTube and
            # others; forcing the browser's breaks extraction on some sites.
            if v and k.lower() != "user-agent" and not (cookie_file and k.lower() == "cookie"):
                args += ["--add-header", f"{k}:{v}"]
        args.append(self.url)
        self.status = Status.DOWNLOADING
        self._emit("status")
        try:
            self._proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                          text=True, bufsize=1, encoding="utf-8", errors="replace",
                                          **NO_WINDOW)
            for line in self._proc.stdout:
                self._parse(line.rstrip("\n"))
            rc = self._proc.wait()
        except OSError as e:
            rc, self._tail = -1, [str(e)]
        finally:
            if cookie_file and os.path.exists(cookie_file):
                os.remove(cookie_file)
        self.speed, self.eta = 0.0, None
        if self._paused:
            self.status = Status.PAUSED
        elif rc == 0:
            self.status = Status.COMPLETED
            if self.size:
                self._done = self.size
        else:
            errs = [ln for ln in self._tail if "ERROR" in ln] or self._tail[-1:]
            raw = (errs[-1] if errs else f"yt-dlp exited with {rc}")
            raw = raw.replace("ERROR: ", "", 1).split("; please report this issue")[0].strip()
            hint = explain("\n".join(self._tail))
            self.error = (f"{hint} [{raw[:200]}]" if hint else raw[:300])
            self.log = "\n".join(self._tail)
            self.status = Status.ERROR
        self._emit("status")

    def _write_cookie_file(self) -> str | None:
        """Browser cookies -> Netscape cookies.txt (0600), so yt-dlp sends the
        right cookies to every host it touches (Drive uses several *.google.com)."""
        import time as _t
        d = os.path.join(DATA_DIR, "run")
        os.makedirs(d, mode=0o700, exist_ok=True)
        path = os.path.join(d, f"cookies-{os.getpid()}-{id(self)}.txt")
        lines = ["# Netscape HTTP Cookie File"]
        fallback = int(_t.time()) + 86400
        for c in self.cookie_jar:
            try:
                name, value, domain = str(c["name"]), str(c.get("value", "")), str(c["domain"])
            except (KeyError, TypeError):
                continue
            if any(ch in name + value + domain for ch in "\t\n\r"):
                continue
            host_only = bool(c.get("hostOnly"))
            if host_only:
                domain = domain.lstrip(".")
            elif not domain.startswith("."):
                domain = "." + domain
            exp = c.get("expirationDate")
            lines.append("\t".join([domain, "FALSE" if host_only else "TRUE", str(c.get("path") or "/"),
                                    "TRUE" if c.get("secure") else "FALSE",
                                    str(int(exp)) if exp else str(fallback), name, value]))
        if len(lines) == 1:
            return None
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write("\n".join(lines) + "\n")
        return path

    def _parse(self, line: str):
        p = self.PREFIX
        if line.startswith(p + "P "):
            parts = line.split()[1:]
            num = lambda s: float(s) if s not in ("NA", "None") else None  # noqa: E731
            vals = [num(x) for x in parts] + [None] * 5
            done, total, est, speed, eta = vals[:5]
            self._done = int(done or 0)
            self.size = int(total or est) if (total or est) else self.size
            self.speed = speed or 0.0
            self.eta = eta
            self._emit("progress")
        elif line.startswith(p + "N "):
            self.path = line[len(p) + 2:]
            self.filename = os.path.basename(self.path)
            self._emit("status")
        elif line.startswith(p + "F "):
            self.path = line[len(p) + 2:]
            self.filename = os.path.basename(self.path)
        else:
            self._tail = (self._tail + [line])[-40:]
