"""Native messaging host: the browser extension runs this to check on the app
and to start it when it is closed.

Protocol (Chrome/Firefox native messaging): 4-byte native-endian length, then
UTF-8 JSON, on stdin/stdout. Requests: {"cmd": "status"} or {"cmd": "launch"}.
Only extensions listed in the host manifest can start this program, so it may
return the API token, which connects the extension without a pairing dialog.
"""
from __future__ import annotations

import json
import os
import struct
import subprocess
import sys
import time

MAX_MSG = 1024 * 1024


def _binary_stdio() -> None:
    if os.name == "nt":  # no CRLF translation on the message pipe
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)


def _app_command() -> list[str]:
    """How to start the GUI from here (frozen Windows build or Python install)."""
    if getattr(sys, "frozen", False):
        return [os.path.join(os.path.dirname(sys.executable), "Algorid Fetch.exe"), "gui", "--minimized"]
    return [sys.executable, "-m", "algorid_fetch", "gui", "--minimized"]


def _spawn_detached(cmd: list[str]) -> None:
    common = dict(stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                  close_fds=True, cwd=os.path.expanduser("~"))
    if os.name != "nt":
        subprocess.Popen(cmd, start_new_session=True, **common)
        return
    # Browsers run native hosts inside a Windows job object that is killed with
    # the host; the app must break away from it to keep running.
    DETACHED, NEW_GROUP, BREAKAWAY = 0x00000008, 0x00000200, 0x01000000
    try:
        subprocess.Popen(cmd, creationflags=DETACHED | NEW_GROUP | BREAKAWAY, **common)
    except OSError:
        subprocess.Popen(cmd, creationflags=DETACHED | NEW_GROUP, **common)


def _read() -> dict | None:
    raw = sys.stdin.buffer.read(4)
    if len(raw) < 4:
        return None
    (n,) = struct.unpack("=I", raw)
    if n > MAX_MSG:
        return None
    try:
        return json.loads(sys.stdin.buffer.read(n) or b"{}")
    except ValueError:
        return {}


def _send(obj: dict) -> None:
    data = json.dumps(obj).encode()
    sys.stdout.buffer.write(struct.pack("=I", len(data)) + data)
    sys.stdout.buffer.flush()


def _status(cfg, launched: bool = False) -> dict:
    from .cli import instance_running
    from .config import VERSION

    running = instance_running(cfg)
    out = {"ok": True, "installed": True, "running": running, "launched": launched,
           "version": VERSION, "port": int(cfg["api_port"])}
    if running:
        out["token"] = cfg["api_token"]
    return out


def _launch(cfg) -> dict:
    from .cli import instance_running

    if instance_running(cfg):
        return _status(cfg)
    # Detached from the browser: closing the browser (or this short-lived
    # host) never takes the app down with it.
    _spawn_detached(_app_command())
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        if instance_running(cfg):
            return _status(cfg, launched=True)
        time.sleep(0.25)
    return {"ok": False, "installed": True, "running": False,
            "error": "Algorid Fetch did not start within 20 seconds"}


def main() -> int:
    from .config import Config

    _binary_stdio()
    cfg = Config()
    while True:
        msg = _read()
        if msg is None:
            return 0
        cmd = msg.get("cmd")
        try:
            if cmd == "status":
                _send(_status(cfg))
            elif cmd == "launch":
                _send(_launch(cfg))
            else:
                _send({"ok": False, "error": f"unknown command {cmd!r}"})
        except Exception as e:  # noqa: BLE001 - never crash without answering
            _send({"ok": False, "error": str(e)})


if __name__ == "__main__":
    sys.exit(main())
