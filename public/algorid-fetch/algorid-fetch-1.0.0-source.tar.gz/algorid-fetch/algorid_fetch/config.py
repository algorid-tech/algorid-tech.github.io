"""Settings stored in ~/.config/algorid-fetch/config.json (XDG aware)."""
from __future__ import annotations

import json
import os
import re
import secrets
import threading

APP = "algorid-fetch"
VERSION = "1.0.0"

IS_WINDOWS = os.name == "nt"
if IS_WINDOWS:
    _roaming = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
    _local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
    CONFIG_DIR = os.path.join(_roaming, "Algorid Fetch")
    DATA_DIR = os.path.join(_local, "Algorid Fetch")
else:
    CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), APP)
    DATA_DIR = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")), APP)
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
DB_PATH = os.path.join(DATA_DIR, "downloads.db")

CATEGORIES = {
    "Videos": "mp4 mkv avi mov webm flv wmv m4v 3gp ts",
    "Audio": "mp3 flac wav aac ogg m4a opus wma",
    "Documents": "pdf doc docx xls xlsx ppt pptx odt ods odp txt csv epub md rtf",
    "Archives": "zip rar 7z tar gz tgz bz2 xz zst iso",
    "Apps": "deb rpm appimage sh run exe msi apk snap flatpak bin",
    "Images": "jpg jpeg png gif webp svg bmp tiff heic",
}
OTHER = "Other"
# names used by builds before the rename -> current names (history rows, old configs)
LEGACY_CATEGORIES = {"Video": "Videos", "Music": "Audio", "Compressed": "Archives",
                     "Programs": "Apps", "General": OTHER}

MEDIA_HOSTS = (
    "youtube.com", "youtu.be", "vimeo.com", "facebook.com", "fb.watch", "x.com",
    "twitter.com", "tiktok.com", "instagram.com", "dailymotion.com", "twitch.tv",
    "soundcloud.com", "bilibili.com", "reddit.com",
)


def _windows_downloads() -> str:
    """The user's real Downloads folder (it can be moved to another drive)."""
    try:
        import ctypes
        import uuid
        from ctypes import wintypes

        guid = uuid.UUID("374DE290-123F-4565-9164-39C4925E467B")  # FOLDERID_Downloads
        buf = ctypes.c_wchar_p()
        g = (ctypes.c_byte * 16).from_buffer_copy(guid.bytes_le)
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(buf)) == 0:
            path = buf.value
            ctypes.windll.ole32.CoTaskMemFree(buf)
            if path:
                return path
        _ = wintypes  # keep import for type availability
    except Exception:  # noqa: BLE001
        pass
    return os.path.join(os.path.expanduser("~"), "Downloads")


def xdg_download_dir() -> str:
    if IS_WINDOWS:
        return _windows_downloads()
    path = os.path.join(os.path.expanduser("~/.config"), "user-dirs.dirs")
    try:
        with open(path) as f:
            for line in f:
                m = re.match(r'\s*XDG_DOWNLOAD_DIR="(.+)"', line)
                if m:
                    return os.path.expandvars(m.group(1).replace("$HOME", os.path.expanduser("~")))
    except OSError:
        pass
    return os.path.expanduser("~/Downloads")


DEFAULTS = {
    "download_dir": xdg_download_dir(),
    "categorize": True,
    "connections": 8,
    "max_concurrent": 3,
    "speed_limit": 0,            # bytes/sec, 0 = unlimited
    "api_port": 6812,
    "api_token": "",             # filled on first run
    "clipboard_monitor": True,
    "browser_confirm_dialog": True,
    "close_to_tray": True,
    "notify_on_complete": True,
    "categories": CATEGORIES,
}


def migrate_legacy_dirs() -> None:
    """Copy settings, history and video tools from the pre-rename 'kitedm' folders."""
    import shutil

    for new in (CONFIG_DIR, DATA_DIR):
        old = os.path.join(os.path.dirname(new), "kitedm")
        if os.path.isdir(old) and not os.path.exists(new):
            try:
                shutil.copytree(old, new, symlinks=True)
            except OSError:
                continue
    cfg = os.path.join(CONFIG_DIR, "config.json")
    try:
        with open(cfg) as f:
            data = json.load(f)
        if any(k in LEGACY_CATEGORIES for k in data.get("categories", {})):
            data.pop("categories")  # old names; use the current defaults
            with open(cfg, "w") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
    except (OSError, ValueError):
        pass


class Config:
    def __init__(self, path: str = CONFIG_PATH):
        if path == CONFIG_PATH:
            migrate_legacy_dirs()
        self.path = path
        self._lock = threading.Lock()
        self.data = dict(DEFAULTS)
        self.load()

    def load(self) -> None:
        try:
            with open(self.path) as f:
                self.data.update(json.load(f))
        except (OSError, ValueError):
            pass
        if not self.data.get("api_token"):
            self.data["api_token"] = secrets.token_urlsafe(24)
            self.save()

    def save(self) -> None:
        with self._lock:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            os.replace(tmp, self.path)

    def __getitem__(self, k):
        return self.data.get(k, DEFAULTS.get(k))

    def __setitem__(self, k, v):
        self.data[k] = v

    def category_for(self, filename: str) -> str:
        ext = os.path.splitext(filename)[1].lower().lstrip(".")
        for cat, exts in self["categories"].items():
            if ext in exts.split():
                return cat
        return OTHER

    def dir_for(self, filename: str) -> str:
        base = os.path.expanduser(self["download_dir"])
        if not self["categorize"]:
            return base
        cat = self.category_for(filename)
        return base if cat == OTHER else os.path.join(base, cat)
