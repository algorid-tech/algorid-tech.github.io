"""Native messaging registration, so the browser extension can start the app.

Browsers only let an extension talk to a native program that is registered in a
small JSON "host manifest" naming the program and the extension IDs allowed to
use it. The .deb installs system-wide manifests for Chrome, Chromium, Edge and
Firefox (including Ubuntu's Snap Firefox, which reads /usr/lib/mozilla through a
desktop portal). The app also writes per-user manifests for browsers that only
read from the home folder (Brave, Vivaldi, Opera) and for non-.deb installs.
"""
from __future__ import annotations

import json
import os
import shutil
import sys

HOST_NAME = "com.algorid.fetch"
DESCRIPTION = "Algorid Fetch launcher"

# Chromium-family IDs allowed to use the host: the fixed ID of the unpacked
# extension (from the "key" in manifest.json). Add the Chrome Web Store ID here
# once the extension is published there.
CHROME_EXTENSION_IDS = ["facabaigmbmloeddimcngijadpcjdjmf"]
FIREFOX_EXTENSION_IDS = ["fetch@algorid"]

HOME = os.path.expanduser("~")
CONFIG_HOME = os.environ.get("XDG_CONFIG_HOME", os.path.join(HOME, ".config"))
CHROMIUM_USER_DIRS = [
    "google-chrome", "google-chrome-beta", "google-chrome-unstable", "chromium",
    "BraveSoftware/Brave-Browser", "vivaldi", "microsoft-edge", "microsoft-edge-beta", "opera",
]
FIREFOX_USER_DIR = os.path.join(HOME, ".mozilla", "native-messaging-hosts")


def chrome_manifest(host_path: str) -> dict:
    return {"name": HOST_NAME, "description": DESCRIPTION, "path": host_path, "type": "stdio",
            "allowed_origins": [f"chrome-extension://{i}/" for i in CHROME_EXTENSION_IDS]}


def firefox_manifest(host_path: str) -> dict:
    return {"name": HOST_NAME, "description": DESCRIPTION, "path": host_path, "type": "stdio",
            "allowed_extensions": FIREFOX_EXTENSION_IDS}


WINDOWS_REG_KEYS = {  # HKCU\<key>\com.algorid.fetch -> manifest path
    "chrome": [r"Software\Google\Chrome\NativeMessagingHosts", r"Software\Chromium\NativeMessagingHosts",
               r"Software\Microsoft\Edge\NativeMessagingHosts",
               r"Software\BraveSoftware\Brave-Browser\NativeMessagingHosts",
               r"Software\Vivaldi\NativeMessagingHosts"],
    "firefox": [r"Software\Mozilla\NativeMessagingHosts"],
}


def host_path() -> str | None:
    """Absolute path of the launcher, wherever this copy is installed."""
    if getattr(sys, "frozen", False):  # Windows build: next to the app
        cand = os.path.join(os.path.dirname(sys.executable), "algorid-fetch-native-host.exe")
        return cand if os.path.exists(cand) else None
    exe = shutil.which("algorid-fetch-native-host")
    if exe:
        return os.path.realpath(exe)
    cand = os.path.join(os.path.dirname(sys.executable), "algorid-fetch-native-host")
    return cand if os.access(cand, os.X_OK) else None


def _write(path: str, data: dict) -> bool:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        body = json.dumps(data, indent=2) + "\n"
        try:
            with open(path) as f:
                if f.read() == body:
                    return False
        except OSError:
            pass
        with open(path, "w") as f:
            f.write(body)
        return True
    except OSError:
        return False


def _install_windows(path: str) -> list[str]:
    import winreg

    from .config import DATA_DIR

    d = os.path.join(DATA_DIR, "native-messaging")
    files = {"chrome": os.path.join(d, HOST_NAME + ".chrome.json"),
             "firefox": os.path.join(d, HOST_NAME + ".firefox.json")}
    _write(files["chrome"], chrome_manifest(path))
    _write(files["firefox"], firefox_manifest(path))
    done = []
    for kind, keys in WINDOWS_REG_KEYS.items():
        for key in keys:
            try:
                with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key + "\\" + HOST_NAME) as k:
                    winreg.SetValueEx(k, "", 0, winreg.REG_SZ, files[kind])
                done.append("HKCU\\" + key)
            except OSError:
                continue
    return done


def remove_user_registration() -> None:
    if os.name != "nt":
        return
    import winreg
    for keys in WINDOWS_REG_KEYS.values():
        for key in keys:
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key + "\\" + HOST_NAME)
            except OSError:
                pass


def install_user_manifests(path: str | None = None) -> list[str]:
    """Register the launcher for every browser profile folder that exists."""
    path = path or host_path()
    if not path:
        return []
    if os.name == "nt":
        return _install_windows(path)
    written = []
    for d in CHROMIUM_USER_DIRS:
        base = os.path.join(CONFIG_HOME, d)
        if os.path.isdir(base):
            target = os.path.join(base, "NativeMessagingHosts", HOST_NAME + ".json")
            if _write(target, chrome_manifest(path)):
                written.append(target)
    if os.path.isdir(os.path.join(HOME, ".mozilla")) or os.path.isdir(os.path.join(HOME, "snap", "firefox")):
        target = os.path.join(FIREFOX_USER_DIR, HOST_NAME + ".json")
        if _write(target, firefox_manifest(path)):
            written.append(target)
    return written
