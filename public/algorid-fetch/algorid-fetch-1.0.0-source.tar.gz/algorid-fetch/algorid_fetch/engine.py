"""Segmented HTTP(S) download engine with adaptive range splitting.

How it works
------------
1. probe() asks for ``Range: bytes=0-0`` to learn the size, whether the server
   honours ranges, the filename (Content-Disposition) and validators (ETag,
   Last-Modified).
2. The file is split into N byte ranges, one per connection, and written in
   place with ``os.pwrite`` into a preallocated ``.afpart`` file.
3. Adaptive splitting: when a connection finishes its range it does not sit
   idle. It takes the largest range still in progress, splits it in half and
   downloads the back half; the original connection stops at the new boundary.
   Every connection stays busy until the very end.
4. Progress is checkpointed to a ``.afstate`` JSON file, so a pause, crash or
   reboot resumes from the exact byte offsets.

Only the standard library is used, so the engine runs on any Ubuntu Python.
"""
from __future__ import annotations

import email.message
import http.client
import json
import mimetypes
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable, Iterable

CHUNK = 64 * 1024
MIN_SEGMENT = 256 * 1024          # never split a remaining range below 2x this
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 8
USER_AGENT = (
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0 Safari/537.36 AlgoridFetch/1.0"
)
FATAL_HTTP = {400, 401, 403, 404, 405, 410, 451}
THROTTLE_HTTP = {429, 503}

O_BINARY = getattr(os, "O_BINARY", 0)  # Windows: no newline translation


def _pwrite(fd: int, data: bytes, offset: int) -> None:
    """Positional write. Windows has no os.pwrite; callers hold the download
    lock, so seek+write cannot interleave with another writer."""
    if hasattr(os, "pwrite"):
        while data:
            n = os.pwrite(fd, data, offset)
            data, offset = data[n:], offset + n
        return
    os.lseek(fd, offset, os.SEEK_SET)
    while data:
        n = os.write(fd, data)
        data = data[n:]


RETIRED = object()  # sentinel: worker gave its range back

PART_SUFFIX = ".afpart"
STATE_SUFFIX = ".afstate"


class Status:
    QUEUED = "queued"
    PROBING = "probing"
    DOWNLOADING = "downloading"
    PAUSED = "paused"
    COMPLETED = "completed"
    ERROR = "error"


class DownloadError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Rate limiting
# --------------------------------------------------------------------------- #
class RateLimiter:
    """Token bucket shared by any number of threads. rate=0 means unlimited."""

    def __init__(self, rate: float = 0):
        self.rate = float(rate)
        self._lock = threading.Lock()
        self._tokens = 0.0
        self._t = time.monotonic()

    def set_rate(self, rate: float) -> None:
        with self._lock:
            self.rate = float(rate)
            self._tokens = 0.0
            self._t = time.monotonic()

    def consume(self, n: int) -> None:
        if self.rate <= 0:
            return
        with self._lock:
            now = time.monotonic()
            self._tokens = min(self.rate, self._tokens + (now - self._t) * self.rate)
            self._t = now
            self._tokens -= n
            wait = -self._tokens / self.rate if self._tokens < 0 else 0.0
        if wait > 0:
            time.sleep(min(wait, 5.0))


# --------------------------------------------------------------------------- #
# Remote probing
# --------------------------------------------------------------------------- #
@dataclass
class RemoteInfo:
    url: str
    final_url: str
    size: int | None
    resumable: bool
    filename: str
    etag: str | None
    last_modified: str | None
    content_type: str | None


def _request(url: str, headers: dict | None, rng: str | None, timeout: float):
    h = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity", "Accept": "*/*"}
    if headers:
        h.update({k: v for k, v in headers.items() if v})
    if rng:
        h["Range"] = rng
    req = urllib.request.Request(url, headers=h)
    return urllib.request.urlopen(req, timeout=timeout)


_UNSAFE = re.compile(r'[\x00-\x1f/\\<>:"|?*]')


_WIN_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def sanitize_filename(name: str) -> str:
    name = _UNSAFE.sub("_", name).strip().strip(".")
    if os.path.splitext(name)[0].upper() in _WIN_RESERVED:
        name = "_" + name
    if not name:
        name = "download"
    if len(name.encode()) > 240:
        stem, ext = os.path.splitext(name)
        name = stem[: 240 - len(ext.encode())] + ext
    return name


def filename_from_headers(cd: str | None, url: str, ctype: str | None) -> str:
    name = None
    if cd:
        msg = email.message.Message()
        msg["content-disposition"] = cd
        name = msg.get_filename()  # handles RFC 2231 filename*=UTF-8''...
    if not name:
        path = urllib.parse.urlparse(url).path
        name = urllib.parse.unquote(path.rsplit("/", 1)[-1])
    name = sanitize_filename(name or "download")
    if "." not in name and ctype:
        ext = mimetypes.guess_extension(ctype.split(";")[0].strip())
        if ext:
            name += ext
    return name


def probe(url: str, headers: dict | None = None, timeout: float = DEFAULT_TIMEOUT) -> RemoteInfo:
    try:
        resp = _request(url, headers, "bytes=0-0", timeout)
    except urllib.error.HTTPError as e:
        if e.code != 416:
            raise
        resp = _request(url, headers, None, timeout)  # some servers dislike 0-0
    try:
        h = resp.headers
        size, resumable = None, False
        cr = h.get("Content-Range")
        if resp.status == 206 and cr:
            m = re.match(r"bytes\s+\d+-\d+/(\d+|\*)", cr.strip())
            if m and m.group(1) != "*":
                size, resumable = int(m.group(1)), True
        if size is None:
            cl = h.get("Content-Length")
            size = int(cl) if cl and cl.isdigit() and resp.status == 200 else None
        final = resp.geturl()
        ctype = h.get("Content-Type")
        return RemoteInfo(
            url=url,
            final_url=final,
            size=size,
            resumable=resumable,
            filename=filename_from_headers(h.get("Content-Disposition"), final, ctype),
            etag=h.get("ETag"),
            last_modified=h.get("Last-Modified"),
            content_type=ctype,
        )
    finally:
        resp.close()


def _state_url(path: str) -> str | None:
    try:
        with open(path + STATE_SUFFIX) as f:
            return json.load(f).get("url") if os.path.exists(path + PART_SUFFIX) else None
    except (OSError, ValueError):
        return None


def unique_path(path: str) -> str:
    if not os.path.exists(path) and not os.path.exists(path + PART_SUFFIX):
        return path
    stem, ext = os.path.splitext(path)
    i = 1
    while True:
        cand = f"{stem} ({i}){ext}"
        if not os.path.exists(cand) and not os.path.exists(cand + PART_SUFFIX):
            return cand
        i += 1


# --------------------------------------------------------------------------- #
# Download
# --------------------------------------------------------------------------- #
@dataclass
class Segment:
    start: int
    end: int | None  # inclusive, None = unknown length (stream to EOF)
    pos: int

    @property
    def remaining(self) -> int | None:
        return None if self.end is None else self.end - self.pos + 1

    @property
    def done(self) -> bool:
        return self.end is not None and self.pos > self.end


class Download:
    """One file. Thread-safe; call start(), pause(), wait()."""

    def __init__(
        self,
        url: str,
        dest_dir: str | Callable[[str], str],
        filename: str | None = None,
        connections: int = 8,
        headers: dict | None = None,
        limiters: Iterable[RateLimiter] = (),
        path: str | None = None,
        on_event: Callable[["Download", str], None] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ):
        self.url = url
        self.dest_dir = dest_dir
        self.requested_filename = filename
        self.connections = max(1, min(32, int(connections)))
        self.headers = dict(headers or {})
        self.limiters = list(limiters)
        self.on_event = on_event
        self.timeout = timeout
        self.max_retries = max_retries

        self.path: str | None = path       # final path, fixed after first probe
        self.filename: str | None = os.path.basename(path) if path else filename
        self.size: int | None = None
        self.resumable = False
        self.etag: str | None = None
        self.last_modified: str | None = None
        self.content_type: str | None = None

        self.status = Status.QUEUED
        self.error: str | None = None
        self.segments: list[Segment] = []
        self.speed = 0.0

        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._fd: int | None = None
        self._active: set[int] = set()
        self._workers_alive = 0
        self._fatal: Exception | None = None
        self._session_bytes = 0

    # ---------------- public API ---------------- #
    @property
    def part_path(self) -> str | None:
        return self.path + PART_SUFFIX if self.path else None

    @property
    def state_path(self) -> str | None:
        return self.path + STATE_SUFFIX if self.path else None

    @property
    def downloaded(self) -> int:
        with self._lock:
            if self.status == Status.COMPLETED and self.size is not None:
                return self.size
            return sum(s.pos - s.start for s in self.segments)

    @property
    def progress(self) -> float | None:
        if not self.size:
            return 1.0 if self.status == Status.COMPLETED else None
        return min(1.0, self.downloaded / self.size)

    @property
    def eta(self) -> float | None:
        if not self.size or self.speed <= 1:
            return None
        return max(0.0, (self.size - self.downloaded) / self.speed)

    @property
    def active_connections(self) -> int:
        return self._workers_alive

    def segment_map(self) -> list[tuple[int, int | None, int]]:
        with self._lock:
            return [(s.start, s.end, s.pos) for s in self.segments]

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> None:
        if self.is_running():
            return
        self._stop.clear()
        self._fatal = None
        self.error = None
        self._thread = threading.Thread(target=self._run, name=f"af:{self.url[:40]}", daemon=True)
        self._thread.start()

    def pause(self, wait: bool = True) -> None:
        self._stop.set()
        if wait and self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=self.timeout + 5)

    def wait(self, timeout: float | None = None) -> str:
        if self._thread:
            self._thread.join(timeout)
        return self.status

    def discard_files(self) -> None:
        for p in (self.part_path, self.state_path):
            if p and os.path.exists(p):
                os.remove(p)

    # ---------------- internals ---------------- #
    def _emit(self, kind: str) -> None:
        if self.on_event:
            try:
                self.on_event(self, kind)
            except Exception:
                pass

    def _set_status(self, st: str) -> None:
        self.status = st
        self._emit("status")

    def _resolve_dir(self, filename: str) -> str:
        d = self.dest_dir(filename) if callable(self.dest_dir) else self.dest_dir
        d = os.path.expanduser(d)
        os.makedirs(d, exist_ok=True)
        return d

    def _load_state(self) -> dict | None:
        sp = self.state_path
        if not sp or not os.path.exists(sp) or not os.path.exists(self.part_path):
            return None
        try:
            with open(sp) as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def _save_state(self) -> None:
        if not self.state_path or self.status == Status.COMPLETED:
            return
        with self._lock:
            data = {
                "version": 1,
                "url": self.url,
                "size": self.size,
                "resumable": self.resumable,
                "etag": self.etag,
                "last_modified": self.last_modified,
                "segments": [[s.start, s.end, s.pos] for s in self.segments],
            }
        tmp = self.state_path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | O_BINARY, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(data, f)
        os.replace(tmp, self.state_path)

    def _plan_segments(self) -> None:
        size = self.size
        if size is None or not self.resumable:
            self.segments = [Segment(0, None if size is None else size - 1, 0)]
            return
        n = max(1, min(self.connections, size // MIN_SEGMENT or 1))
        step = size // n
        segs, start = [], 0
        for i in range(n):
            end = size - 1 if i == n - 1 else start + step - 1
            segs.append(Segment(start, end, start))
            start = end + 1
        self.segments = segs

    def _run(self) -> None:
        try:
            self._set_status(Status.PROBING)
            info = probe(self.url, self.headers, self.timeout)
            self.content_type = info.content_type

            if self.path is None:
                name = sanitize_filename(self.requested_filename or info.filename)
                cand = os.path.join(self._resolve_dir(name), name)
                if _state_url(cand) == self.url:
                    self.path = cand  # same URL left a partial file here: resume it
                else:
                    self.path = unique_path(cand)
                self.filename = os.path.basename(self.path)
            state = self._load_state()
            reuse = (
                state is not None
                and info.resumable
                and state.get("resumable")
                and state.get("size") == info.size
                and (not info.etag or not state.get("etag") or info.etag == state.get("etag"))
            )
            if not reuse:
                self.discard_files()  # server file changed or no usable state

            self.size, self.resumable = info.size, info.resumable
            self.etag, self.last_modified = info.etag, info.last_modified

            with self._lock:
                if reuse:
                    self.segments = [Segment(a, b, c) for a, b, c in state["segments"]]
                else:
                    self._plan_segments()

            self._fd = os.open(self.part_path, os.O_RDWR | os.O_CREAT | O_BINARY, 0o644)
            if self.size and os.fstat(self._fd).st_size < self.size:
                try:
                    os.posix_fallocate(self._fd, 0, self.size)
                except (OSError, AttributeError):
                    os.ftruncate(self._fd, self.size)
            self._save_state()
            self._set_status(Status.DOWNLOADING)

            if self.size == 0:
                self.segments = []
            else:
                self._run_workers()

            if self._fatal is not None:
                raise self._fatal
            if self._stop.is_set() and not self._all_done():
                self._close_fd()
                self._save_state()
                self.speed = 0.0
                self._set_status(Status.PAUSED)
                return
            if not self._all_done():
                raise DownloadError("download ended with missing ranges")
            self._finalize()
        except Exception as e:  # noqa: BLE001 - surface every failure to the UI
            self._close_fd()
            try:
                self._save_state()
            except Exception:
                pass
            self.speed = 0.0
            self.error = _describe(e)
            self._set_status(Status.ERROR)

    def _all_done(self) -> bool:
        with self._lock:
            return all(s.done for s in self.segments)

    def _close_fd(self) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            finally:
                self._fd = None

    def _finalize(self) -> None:
        os.fsync(self._fd)
        if self.size is None:
            self.size = os.fstat(self._fd).st_size
        else:
            os.ftruncate(self._fd, self.size)
        self._close_fd()
        final = self.path
        if os.path.exists(final):
            final = unique_path(final)
        os.replace(self.part_path, final)
        if os.path.exists(self.path + STATE_SUFFIX):
            os.remove(self.path + STATE_SUFFIX)
        self.path, self.filename = final, os.path.basename(final)
        self.speed = 0.0
        self._set_status(Status.COMPLETED)

    def _run_workers(self) -> None:
        threads = []
        n = self.connections if self.resumable else 1
        for i in range(n):
            idx = self._next_segment()
            if idx is None:
                break
            t = threading.Thread(target=self._worker, args=(idx,), daemon=True, name=f"af-w{i}")
            with self._lock:
                self._workers_alive += 1
            threads.append(t)
            t.start()

        last_bytes, last_t, last_save = self._session_bytes, time.monotonic(), time.monotonic()
        while any(t.is_alive() for t in threads):
            time.sleep(0.5)
            now = time.monotonic()
            b = self._session_bytes
            inst = (b - last_bytes) / max(1e-6, now - last_t)
            self.speed = inst if self.speed == 0 else 0.6 * self.speed + 0.4 * inst
            last_bytes, last_t = b, now
            if now - last_save > 2:
                self._save_state()
                last_save = now
            self._emit("progress")
        for t in threads:
            t.join()

    def _next_segment(self) -> int | None:
        """Hand out an unassigned range, or split the largest active one."""
        with self._lock:
            for i, s in enumerate(self.segments):
                if not s.done and i not in self._active:
                    self._active.add(i)
                    return i
            if not self.resumable:
                return None
            best, best_rem = None, 0
            for i in self._active:
                rem = self.segments[i].remaining or 0
                if rem >= 2 * MIN_SEGMENT and rem > best_rem:
                    best, best_rem = i, rem
            if best is None:
                return None
            s = self.segments[best]
            mid = s.pos + best_rem // 2
            new = Segment(mid, s.end, mid)
            s.end = mid - 1
            self.segments.append(new)
            idx = len(self.segments) - 1
            self._active.add(idx)
            return idx

    def _worker(self, idx: int | None) -> None:
        result = None
        try:
            while idx is not None and not self._stop.is_set():
                result = self._fetch(idx)
                with self._lock:
                    self._active.discard(idx)
                if result is not True or self._stop.is_set():
                    break
                idx = self._next_segment()
        finally:
            with self._lock:
                if idx is not None:
                    self._active.discard(idx)
                if result is not RETIRED:
                    self._workers_alive -= 1

    def _fetch(self, idx: int):
        """Download one segment. True = done, False = stopped, RETIRED = dropped."""
        s = self.segments[idx]
        attempts = 0
        while not self._stop.is_set():
            with self._lock:
                if s.done:
                    return True
                if not self.resumable and s.pos:
                    s.pos = 0  # cannot resume mid-stream, start over
                start, end = s.pos, s.end
            rng = f"bytes={start}-{'' if end is None else end}" if self.resumable else None
            progressed = False
            try:
                resp = _request(self.url, self.headers, rng, self.timeout)
                with resp:
                    if self.resumable:
                        cr = resp.headers.get("Content-Range", "")
                        if resp.status != 206 or not re.match(rf"bytes\s+{start}-", cr):
                            raise DownloadError(f"server ignored range request (HTTP {resp.status})")
                    while not self._stop.is_set():
                        chunk = resp.read(CHUNK)
                        if not chunk:
                            break
                        for lim in self.limiters:
                            lim.consume(len(chunk))
                        with self._lock:
                            if s.end is not None:
                                allow = s.end - s.pos + 1
                                if allow <= 0:
                                    break
                                if len(chunk) > allow:
                                    chunk = chunk[:allow]
                            _pwrite(self._fd, chunk, s.pos)
                            s.pos += len(chunk)
                            self._session_bytes += len(chunk)
                            progressed = True
                            if s.done:
                                break
                with self._lock:
                    if s.done:
                        return True
                    if s.end is None and not self._stop.is_set():
                        s.end = s.pos - 1  # unknown-length stream reached EOF
                        return True
                if self._stop.is_set():
                    return False
                raise DownloadError("connection closed early")
            except Exception as e:  # noqa: BLE001
                if self._stop.is_set():
                    return False
                code = getattr(e, "code", None)
                range_ignored = isinstance(e, DownloadError) and "ignored range" in str(e)
                if code in THROTTLE_HTTP or code == 403 or range_ignored:
                    # Server caps parallel connections: hand the range back and
                    # retire this worker; a surviving one will pick it up.
                    with self._lock:
                        if self._workers_alive > 1:
                            self._workers_alive -= 1
                            return RETIRED
                if code in FATAL_HTTP or range_ignored:
                    self._fatal = e
                    self._stop.set()
                    return False
                attempts = 0 if progressed else attempts + 1
                if attempts > self.max_retries:
                    self._fatal = e
                    self._stop.set()
                    return False
                self._stop.wait(min(30.0, 0.5 * 2 ** attempts))
        return False


def _describe(e: Exception) -> str:
    if isinstance(e, urllib.error.HTTPError):
        return f"HTTP {e.code} {e.reason}"
    if isinstance(e, urllib.error.URLError):
        return f"Network error: {e.reason}"
    if isinstance(e, http.client.HTTPException):
        return f"Protocol error: {e.__class__.__name__}"
    return str(e) or e.__class__.__name__


# --------------------------------------------------------------------------- #
# Formatting helpers shared by CLI and GUI
# --------------------------------------------------------------------------- #
def human_size(n: float | None) -> str:
    if n is None:
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.2f} {unit}"
        n /= 1024
    return f"{n:.2f} TB"


def human_time(sec: float | None) -> str:
    if sec is None:
        return "--"
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}h {m:02d}m" if h else (f"{m}m {s:02d}s" if m else f"{s}s")


def parse_rate(text: str | int | float | None) -> float:
    """'500K', '2M', '1.5MB', '0' -> bytes per second."""
    if text in (None, "", 0, "0"):
        return 0.0
    if isinstance(text, (int, float)):
        return float(text)
    m = re.fullmatch(r"\s*([\d.]+)\s*([kKmMgG]?)[bB]?(?:/s)?\s*", str(text))
    if not m:
        raise ValueError(f"invalid rate: {text!r}")
    mult = {"": 1, "k": 1024, "m": 1024**2, "g": 1024**3}[m.group(2).lower()]
    return float(m.group(1)) * mult
