"""Qt binding shim: PyQt6 when available, PyQt5 otherwise.

Ubuntu 24.04+ ships python3-pyqt6; 20.04 and 22.04 only ship python3-pyqt5.
The GUI is written against PyQt6-style scoped enums (Qt.ItemDataRole.X),
which PyQt5 5.11+ also accepts; older PyQt5 builds get those names added.
"""
from __future__ import annotations

try:
    from PyQt6.QtCore import *  # noqa: F401,F403
    from PyQt6.QtGui import *  # noqa: F401,F403
    from PyQt6.QtWidgets import *  # noqa: F401,F403
    from PyQt6 import QtCore as _QtCore, QtGui as _QtGui, QtWidgets as _QtWidgets
    QT_API = "PyQt6"
except ImportError:
    from PyQt5.QtCore import *  # noqa: F401,F403
    from PyQt5.QtGui import *  # noqa: F401,F403
    from PyQt5.QtWidgets import *  # noqa: F401,F403
    from PyQt5 import QtCore as _QtCore, QtGui as _QtGui, QtWidgets as _QtWidgets
    QT_API = "PyQt5"


def _promote_scoped_enums() -> None:
    """Make Qt.ItemDataRole.DisplayRole work on PyQt5 builds that lack it."""
    for mod in (_QtCore, _QtGui, _QtWidgets):
        for cname in dir(mod):
            cls = getattr(mod, cname, None)
            if not isinstance(cls, type):
                continue
            for aname in dir(cls):
                if not aname[:1].isupper():
                    continue
                try:
                    val = getattr(cls, aname)
                    etype = type(val)
                    if getattr(cls, etype.__name__, None) is etype and not hasattr(etype, aname):
                        setattr(etype, aname, val)
                except Exception:  # noqa: BLE001 - best effort per attribute
                    continue


if QT_API == "PyQt5" and not hasattr(_QtCore.Qt.ItemDataRole, "DisplayRole"):
    _promote_scoped_enums()


def qexec(obj, *args):
    """exec() on PyQt6, exec_() fallback for old PyQt5."""
    fn = getattr(obj, "exec", None) or getattr(obj, "exec_")
    return fn(*args)


def prepare_app() -> None:
    """Call before creating QApplication."""
    if QT_API == "PyQt5":
        # Qt6 scales automatically; Qt5 needs this for HiDPI laptops
        for attr in ("AA_EnableHighDpiScaling", "AA_UseHighDpiPixmaps"):
            a = getattr(_QtCore.Qt.ApplicationAttribute, attr, None) or getattr(_QtCore.Qt, attr, None)
            if a is not None:
                _QtWidgets.QApplication.setAttribute(a, True)
