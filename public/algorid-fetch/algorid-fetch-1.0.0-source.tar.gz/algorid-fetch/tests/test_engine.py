import hashlib
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from algorid_fetch import engine  # noqa: E402
from algorid_fetch.engine import Download, RateLimiter, Status  # noqa: E402
import rangeserver  # noqa: E402
from rangeserver import Cfg  # noqa: E402


def sha(b):
    return hashlib.sha256(b).hexdigest()


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = rangeserver.serve()
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"

    def setUp(self):
        Cfg.data = os.urandom(6 * 1024 * 1024 + 12345)
        Cfg.ranges, Cfg.max_conn, Cfg.bps, Cfg.drop_every, Cfg.disposition = True, 0, 0, 0, None
        Cfg.fast_first = False
        self.tmp = tempfile.mkdtemp()

    def _check(self, d):
        self.assertEqual(d.status, Status.COMPLETED, d.error)
        with open(d.path, "rb") as f:
            self.assertEqual(sha(f.read()), sha(Cfg.data))
        self.assertFalse(os.path.exists(d.path + engine.PART_SUFFIX))
        self.assertFalse(os.path.exists(d.path + engine.STATE_SUFFIX))

    def test_segmented(self):
        d = Download(f"{self.base}/files/test.bin", self.tmp, connections=8)
        d.start()
        d.wait(60)
        self._check(d)
        self.assertEqual(d.filename, "test.bin")

    def test_dynamic_split(self):
        # Slow server: when early segments finish, the engine must split others.
        Cfg.bps = 1024 * 1024
        Cfg.fast_first = True
        d = Download(f"{self.base}/a.bin", self.tmp, connections=4)
        d.start()
        d.wait(60)
        self._check(d)
        self.assertGreater(len(d.segments), 4, "expected dynamic splits")

    def test_pause_resume(self):
        Cfg.bps = 256 * 1024
        d = Download(f"{self.base}/p.bin", self.tmp, connections=4)
        d.start()
        time.sleep(1.5)
        d.pause()
        self.assertEqual(d.status, Status.PAUSED)
        got = d.downloaded
        self.assertGreater(got, 0)
        self.assertTrue(os.path.exists(d.state_path))
        Cfg.bps = 0
        # Resume with a fresh object, as after an app restart.
        d2 = Download(d.url, self.tmp, path=d.path, connections=4)
        d2.start()
        d2.wait(60)
        self._check(d2)

    def test_no_range_server(self):
        Cfg.ranges = False
        d = Download(f"{self.base}/n.bin", self.tmp, connections=8)
        d.start()
        d.wait(60)
        self._check(d)
        self.assertFalse(d.resumable)

    def test_flaky_connection(self):
        Cfg.drop_every = 300 * 1024
        d = Download(f"{self.base}/f.bin", self.tmp, connections=6)
        d.start()
        d.wait(120)
        self._check(d)

    def test_connection_cap(self):
        Cfg.max_conn = 2
        Cfg.bps = 8 * 1024 * 1024
        d = Download(f"{self.base}/c.bin", self.tmp, connections=8)
        d.start()
        d.wait(120)
        self._check(d)

    def test_content_disposition_and_unique(self):
        Cfg.disposition = "attachment; filename*=UTF-8''%E0%A6%AC%E0%A6%87.pdf"
        d1 = Download(f"{self.base}/dl?id=1", self.tmp)
        d1.start(); d1.wait(60)
        d2 = Download(f"{self.base}/dl?id=1", self.tmp)
        d2.start(); d2.wait(60)
        self._check(d1); self._check(d2)
        self.assertEqual(d1.filename, "বই.pdf")
        self.assertEqual(d2.filename, "বই (1).pdf")

    def test_404(self):
        orig = rangeserver.H._serve

        def nf(h):
            h.send_response(404); h.send_header("Content-Length", "0"); h.end_headers()
        rangeserver.H._serve = nf
        try:
            d = Download(f"{self.base}/missing", self.tmp)
            d.start(); d.wait(30)
            self.assertEqual(d.status, Status.ERROR)
            self.assertIn("404", d.error)
        finally:
            rangeserver.H._serve = orig

    def test_rate_limit(self):
        Cfg.data = os.urandom(2 * 1024 * 1024)
        lim = RateLimiter(1024 * 1024)
        d = Download(f"{self.base}/r.bin", self.tmp, connections=4, limiters=[lim])
        t = time.monotonic()
        d.start(); d.wait(60)
        el = time.monotonic() - t
        self._check(d)
        self.assertGreater(el, 1.5)

    def test_parse_rate(self):
        self.assertEqual(engine.parse_rate("500K"), 500 * 1024)
        self.assertEqual(engine.parse_rate("2MB/s"), 2 * 1024 * 1024)
        self.assertEqual(engine.parse_rate("0"), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
