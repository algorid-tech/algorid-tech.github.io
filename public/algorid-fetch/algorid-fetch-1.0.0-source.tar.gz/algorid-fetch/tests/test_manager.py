import hashlib
import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

TMP = tempfile.mkdtemp()
os.environ["XDG_CONFIG_HOME"] = os.path.join(TMP, "cfg")
os.environ["XDG_DATA_HOME"] = os.path.join(TMP, "data")
ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(__file__))

from algorid_fetch.api import ApiServer  # noqa: E402
from algorid_fetch.config import Config  # noqa: E402
from algorid_fetch.engine import Status  # noqa: E402
from algorid_fetch.manager import Manager, Store  # noqa: E402
import rangeserver  # noqa: E402
from rangeserver import Cfg  # noqa: E402

NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait_until(fn, timeout=60):
    t = time.monotonic()
    while time.monotonic() - t < timeout:
        if fn():
            return True
        time.sleep(0.1)
    return False


class ManagerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = rangeserver.serve()
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"

    def setUp(self):
        Cfg.data = os.urandom(3 * 1024 * 1024)
        Cfg.ranges, Cfg.max_conn, Cfg.bps, Cfg.drop_every, Cfg.disposition = True, 0, 0, 0, None
        Cfg.fast_first = False
        self.dir = tempfile.mkdtemp()
        self.cfg = Config(os.path.join(self.dir, "config.json"))
        self.cfg["download_dir"] = os.path.join(self.dir, "dl")
        self.cfg["max_concurrent"] = 2
        self.cfg["api_port"] = free_port()
        self.cfg.save()
        self.db = os.path.join(self.dir, "db.sqlite")

    def _sha(self, path):
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()

    def test_queue_concurrency_and_categories(self):
        Cfg.bps = 2 * 1024 * 1024
        m = Manager(self.cfg, Store(self.db))
        peak = [0]
        m.subscribe(lambda i, k: peak.__setitem__(
            0, max(peak[0], sum(1 for it in m.items.values() if it.task.is_running()))))
        ids = [m.add(f"{self.base}/f{i}.{ext}") for i, ext in enumerate(["zip", "mp4", "pdf", "xyz"])]
        self.assertTrue(wait_until(lambda: all(m.get(i)["status"] == Status.COMPLETED for i in ids), 90),
                        [m.get(i)["status"] for i in ids])
        self.assertLessEqual(peak[0], 2)
        paths = [m.get(i)["path"] for i in ids]
        self.assertIn(os.path.join("dl", "Archives", "f0.zip"), paths[0])
        self.assertIn(os.path.join("dl", "Videos", "f1.mp4"), paths[1])
        self.assertIn(os.path.join("dl", "Documents", "f2.pdf"), paths[2])
        self.assertTrue(paths[3].endswith(os.path.join("dl", "f3.xyz")))
        ref = hashlib.sha256(Cfg.data).hexdigest()
        for p in paths:
            self.assertEqual(self._sha(p), ref)

    def test_restart_persists_and_resumes(self):
        Cfg.bps = 300 * 1024
        m = Manager(self.cfg, Store(self.db))
        i = m.add(f"{self.base}/big.iso")
        self.assertTrue(wait_until(lambda: m.get(i)["downloaded"] > 200_000, 20))
        m.shutdown()
        got = m.get(i)["downloaded"]
        Cfg.bps = 0
        m2 = Manager(self.cfg, Store(self.db))  # simulates app restart
        snap = m2.get(i)
        self.assertEqual(snap["status"], Status.PAUSED)
        self.assertGreaterEqual(snap["downloaded"], got * 0.5)
        hits_before = Cfg.hits
        m2.start(i)
        self.assertTrue(wait_until(lambda: m2.get(i)["status"] == Status.COMPLETED, 60), m2.get(i))
        self.assertEqual(self._sha(m2.get(i)["path"]), hashlib.sha256(Cfg.data).hexdigest())
        self.assertGreater(Cfg.hits, hits_before)

    def test_api_security_and_add(self):
        m = Manager(self.cfg, Store(self.db))
        api = ApiServer(m, self.cfg)
        api.start()
        url = f"http://127.0.0.1:{self.cfg['api_port']}"
        try:
            def call(path, body=None, headers=None):
                req = urllib.request.Request(url + path, data=json.dumps(body).encode() if body else None,
                                             headers=headers or {})
                try:
                    with NOPROXY.open(req, timeout=5) as r:
                        return r.status, json.loads(r.read())
                except urllib.error.HTTPError as e:
                    return e.code, json.loads(e.read() or b"{}")

            tok = {"X-Algorid-Token": self.cfg["api_token"], "Content-Type": "application/json"}
            self.assertEqual(call("/ping")[0], 200)
            self.assertEqual(call("/add", {"url": f"{self.base}/x.bin"})[0], 401)
            self.assertEqual(call("/add", {"url": f"{self.base}/x.bin"},
                                  {**tok, "Origin": "https://evil.example"})[0], 403)
            self.assertEqual(call("/add", {"url": "file:///etc/passwd"}, tok)[0], 400)
            code, body = call("/add", {"url": f"{self.base}/x.bin", "referrer": "https://site/",
                                       "cookies": [{"name": "sid", "value": "abc"}]},
                              {**tok, "Origin": "chrome-extension://abcdef"})
            self.assertEqual(code, 200)
            item = m.items[body["id"]]
            self.assertEqual(item.headers["Cookie"], "sid=abc")
            self.assertEqual(item.headers["Referer"], "https://site/")
            self.assertTrue(wait_until(lambda: m.get(body["id"])["status"] == Status.COMPLETED, 30))
            code, lst = call("/list", headers=tok)
            self.assertEqual(lst[0]["status"], Status.COMPLETED)
        finally:
            api.stop()

    def test_old_database_migrates(self):
        import sqlite3
        db = sqlite3.connect(self.db)
        db.executescript("""CREATE TABLE downloads (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL,
            kind TEXT NOT NULL DEFAULT 'http', filename TEXT, path TEXT, dest_dir TEXT, category TEXT,
            status TEXT NOT NULL, size INTEGER, downloaded INTEGER DEFAULT 0, connections INTEGER,
            headers TEXT, error TEXT, added REAL, finished REAL);
            INSERT INTO downloads (url, kind, status, added) VALUES ('https://youtu.be/x', 'media', 'error', 1);""")
        db.commit(); db.close()
        m = Manager(self.cfg, Store(self.db))       # must not crash on the old schema
        self.assertEqual(m.snapshot()[0]["url"], "https://youtu.be/x")
        i = m.add(f"{self.base}/q.mp4", kind="media", quality="720", start=False)
        m2 = Manager(self.cfg, Store(self.db))
        self.assertEqual(m2.get(i)["quality"], "720")
        self.assertEqual(m2.items[i].task.quality, "720")

    def test_video_links_use_ytdlp(self):
        m = Manager(self.cfg, Store(self.db))
        i = m.add("https://www.youtube.com/watch?v=abc", start=False)
        self.assertEqual(m.get(i)["kind"], "media")
        from algorid_fetch.media import format_for
        self.assertIn("height<=720", format_for("720"))
        self.assertEqual(format_for("audio"), "ba[ext=m4a]/ba/b")

    def test_pairing(self):
        m = Manager(self.cfg, Store(self.db))
        answers = []
        api = ApiServer(m, self.cfg, on_pair=lambda origin: answers.pop(0))
        api.start()
        url = f"http://127.0.0.1:{self.cfg['api_port']}/pair"

        def pair(origin):
            h = {"Origin": origin} if origin else {}
            req = urllib.request.Request(url, data=b"{}", headers=h, method="POST")
            try:
                with NOPROXY.open(req, timeout=5) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                with e:
                    return e.code, json.loads(e.read() or b"{}")
        try:
            answers.append(True)
            code, body = pair("chrome-extension://abc")
            self.assertEqual((code, body.get("token")), (200, self.cfg["api_token"]))
            answers.append(False)
            self.assertEqual(pair("chrome-extension://abc")[0], 403)  # user clicked Deny
            self.assertEqual(pair("https://evil.example")[0], 403)    # web pages never pair
            self.assertEqual(pair(None)[0], 403)                      # nor non-extension callers
            self.assertEqual(answers, [])                             # dialog only shown twice
        finally:
            api.stop()
        headless = ApiServer(m, self.cfg)  # daemon mode: no window to ask in
        headless.start()
        try:
            self.assertEqual(pair("chrome-extension://abc")[0], 501)
        finally:
            headless.stop()

    def test_cli_get_interrupt_and_resume(self):
        Cfg.bps = 100 * 1024
        env = dict(os.environ, PYTHONPATH=ROOT, XDG_CONFIG_HOME=os.path.join(self.dir, "x"))
        for k in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"):
            env.pop(k, None)
        out = os.path.join(self.dir, "cli")
        os.makedirs(out)
        cmd = [sys.executable, "-m", "algorid_fetch.cli", "get", f"{self.base}/cli.bin", "-o", out, "-c", "4"]
        p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(2)
        p.send_signal(signal.SIGINT)
        stdout, _ = p.communicate(30)
        self.assertEqual(p.returncode, 130, stdout)
        self.assertTrue(os.path.exists(os.path.join(out, "cli.bin.afpart")))
        Cfg.bps = 0
        r = subprocess.run(cmd + ["--sha256", hashlib.sha256(Cfg.data).hexdigest()],
                           env=env, capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("sha256 OK", r.stdout)
        self.assertEqual(os.listdir(out), ["cli.bin"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
