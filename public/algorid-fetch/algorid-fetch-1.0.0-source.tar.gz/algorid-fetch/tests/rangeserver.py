"""Test HTTP server: Range support, optional throttling, connection caps, drops."""
from __future__ import annotations

import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Cfg:
    data = b""
    ranges = True
    max_conn = 0          # 0 = unlimited; extra connections get 503
    bps = 0               # per-connection throttle, bytes/sec
    drop_every = 0        # close connection after N bytes (simulates flaky net)
    disposition = None
    active = 0
    lock = threading.Lock()
    hits = 0
    fast_first = False    # range starting at 0 is unthrottled (uneven peers)


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_GET(self):
        with Cfg.lock:
            Cfg.hits += 1
            if Cfg.max_conn and Cfg.active >= Cfg.max_conn and "bytes=0-0" not in self.headers.get("Range", ""):
                self.send_response(503)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            Cfg.active += 1
        try:
            self._serve()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with Cfg.lock:
                Cfg.active -= 1

    def _serve(self):
        data, size = Cfg.data, len(Cfg.data)
        rng = self.headers.get("Range")
        start, end, code = 0, size - 1, 200
        if Cfg.ranges and rng:
            m = re.match(r"bytes=(\d+)-(\d*)", rng)
            start = int(m.group(1))
            end = min(int(m.group(2)), size - 1) if m.group(2) else size - 1
            code = 206
        body_len = end - start + 1
        self.send_response(code)
        self.send_header("Content-Length", str(body_len))
        self.send_header("ETag", '"v1"')
        self.send_header("Content-Type", "application/octet-stream")
        if Cfg.ranges:
            self.send_header("Accept-Ranges", "bytes")
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        if Cfg.disposition:
            self.send_header("Content-Disposition", Cfg.disposition)
        self.end_headers()
        sent, pos, step = 0, start, 16 * 1024
        while pos <= end:
            n = min(step, end - pos + 1)
            self.wfile.write(data[pos:pos + n])
            pos += n
            sent += n
            if Cfg.drop_every and sent >= Cfg.drop_every and pos <= end:
                self.close_connection = True
                return
            if Cfg.bps and not (Cfg.fast_first and start == 0):
                time.sleep(n / Cfg.bps)


def serve(port=0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
