# Algorid Fetch

Fast, resumable downloads for Linux and Windows. Algorid Fetch splits each file across many
connections, keeps every connection busy until the end, survives pauses, crashes
and reboots, and works with your browser through a small extension.

![Algorid Fetch main window](screenshot.png)

## Features

- **Multi-connection downloads:** 1 to 32 connections per file (default 8).
- **Adaptive range splitting:** when a connection finishes its part, it takes over
  half of the largest remaining part, so nothing sits idle near the end.
- **Resume anywhere:** byte-exact progress is saved continuously; downloads continue
  after a pause, a crash or a reboot. Changed files on the server are detected and
  restarted cleanly.
- **Browser extension** for Chrome, Brave, Edge, Vivaldi and Opera: hands browser
  downloads to the app with your login cookies, so protected links work too.
- **Video saving** through yt-dlp for sites that allow it, with a quality picker
  (best, 1080p, 720p, 480p, 360p, audio only).
- **Queue and speed limit:** choose how many files run at once and cap total speed.
- **Folders by type:** Videos, Audio, Documents, Archives, Apps and Images.
- **Clipboard watch:** copy a link to a file and the New download dialog opens.
- **Terminal and server use:** `algorid-fetch get URL` in any shell, and a headless
  daemon for servers.

## Install

### Windows 10 and 11

Download and run `AlgoridFetch-Setup-1.0.0.exe` (64-bit). Setup takes about half a
minute, needs no administrator rights, adds Start-menu and desktop shortcuts, and
registers the browser launcher. When it finishes, it opens a short guide for
connecting your browser. Remove it from Settings → Apps; your settings
(`%APPDATA%\Algorid Fetch`) and downloaded files are kept.

The installer is not code-signed yet, so Windows may show "Windows protected your
PC": click **More info**, then **Run anyway**. A code-signing certificate removes
this warning.

### Ubuntu and Debian

```bash
sudo apt install ./algorid-fetch_1.0.0_all.deb
```

Use `apt` rather than `dpkg -i` so the GUI toolkit (PyQt) is installed with it. If you
already ran `dpkg -i`, finish with `sudo apt -f install`. Then open **Algorid Fetch**
from the app grid, or run `algorid-fetch`.

Remove with `sudo apt remove algorid-fetch`. Settings and history stay in
`~/.config/algorid-fetch` and `~/.local/share/algorid-fetch`.

Coming from KiteDM (the earlier name)? Installing this package replaces it and
brings over your settings, history and video components automatically.

### Supported systems

| Ubuntu | Python | GUI toolkit apt installs |
|---|---|---|
| 20.04 LTS | 3.8 | PyQt5 |
| 22.04 LTS | 3.10 | PyQt5 |
| 24.04 LTS | 3.12 | PyQt6 |
| 25.10 | 3.13 | PyQt6 |
| 26.04 LTS | 3.14 | PyQt6 |

20.04, 22.04, 24.04 and 26.04 are tested by installing the package on clean systems.
Debian 11+, Linux Mint 20+, Pop!_OS and other Ubuntu-based systems work the same way.

### Browser extensions

Chromium-based browsers (Chrome, Brave, Edge, Vivaldi, Opera):

1. Unzip `algorid-fetch-chrome-extension-1.0.0.zip` into a folder you will keep, or use
   the copy the package installs at `/usr/share/algorid-fetch/extension`.
2. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked** and
   select that folder.

Firefox (including Ubuntu's default Snap Firefox): install
`algorid-fetch-firefox-1.0.0.xpi`. Release Firefox only installs extensions signed by
Mozilla, so publish it on addons.mozilla.org (listed, or unlisted for self-hosting);
for testing, load it from `about:debugging` → This Firefox → Load Temporary Add-on.

What the extension does:

- **App closed?** It starts Algorid Fetch automatically and hands the download over.
  This uses the browser's native messaging feature: the package registers a small
  launcher, `algorid-fetch-native-host`, for Chrome, Chromium, Edge and Firefox; the
  app registers it for Brave, Vivaldi and Opera the first time it runs (or run
  `algorid-fetch setup-browsers`). The extension also connects itself this way, with
  no pairing step.
- **App not installed?** The browser downloads the file normally and the extension
  opens a short setup page with a download button and the install command. The page
  notices when the app is installed and connects by itself.
- **Videos:** hover over or play a video and click **Fetch video**, then pick a quality.
- Right-click a link for **Fetch link with Algorid Fetch**, or a selection for
  **Fetch all links in selection**.

Snap-packaged Chromium cannot start programs outside its sandbox, so there the app has
to be open already; the extension then asks you to **Allow** it once.

### Videos

Hover over or play a video and click **Fetch video**, then pick a quality. The first
time, the app offers to download two free components into
`~/.local/share/algorid-fetch/bin`: yt-dlp and Deno (a JavaScript runtime some sites
require). yt-dlp is refreshed weekly; update both from Settings → Video downloads or
with `algorid-fetch update-ytdlp`. 720p and above usually needs ffmpeg, which `apt`
installs with the package. If a video fails, select it to see why and what to do.

## Command line

```bash
algorid-fetch                          # open the app
algorid-fetch get URL -c 16 -o ~/Downloads
algorid-fetch get URL --limit 2M --sha256 <hash>
algorid-fetch get URL -H "Authorization: Bearer xyz" -r https://referer/
algorid-fetch add URL [--media]        # queue in the running app or daemon
algorid-fetch list
algorid-fetch daemon --resume          # headless, keeps the browser link up
algorid-fetch update-ytdlp             # install/update video components
algorid-fetch setup-browsers           # register the browser launcher for this user
```

`Ctrl+C` during `algorid-fetch get` pauses; run the same command again to resume.
On a server: `systemctl --user enable --now algorid-fetch`.

## How it works

1. **Probe:** a `Range: bytes=0-0` request reveals the size, range support, the file
   name (`Content-Disposition`, including Unicode names) and the ETag.
2. **Plan:** the file is split into equal byte ranges and preallocated on disk.
3. **Download:** each range runs on its own connection and is written in place.
4. **Rebalance:** a free connection splits the largest active range at its midpoint
   and takes the back half.
5. **Recover:** temporary errors retry with backoff; servers that limit connections
   make surplus connections hand back their range instead of failing the download;
   servers without range support fall back to one connection.
6. **Finish:** progress is checkpointed every 2 seconds; the file is synced and
   renamed when complete.

```
algorid_fetch/
  engine.py    segmented downloader (Python standard library only)
  manager.py   queue, scheduling, SQLite history, speed limit
  media.py     yt-dlp integration, video components, error explanations
  api.py       127.0.0.1 API for the extension and CLI
  gui.py       Qt UI (PyQt6, or PyQt5 on older Ubuntu via qt.py)
  cli.py       get / add / list / daemon / token / update-ytdlp / setup-browsers
  native_host.py, browsers.py   launcher the extension uses to start the app
extension/     Chromium MV3 extension
packaging/     build-deb.sh
tests/         local test server and automated tests
```

Run the tests with `python3 tests/test_engine.py && python3 tests/test_manager.py`.
Build everything with `packaging/build-deb.sh`; `dist/` then holds the `.deb`, a
version-free copy `algorid-fetch_all.deb`, the Chromium `.zip` and the Firefox `.xpi`.

The Windows installer builds on Linux too: `packaging/windows/build-windows.sh`
(needs `sudo apt install wine64 nsis`). It runs Windows Python and PyInstaller inside
Wine and packs the result with NSIS into `dist/AlgoridFetch-Setup-<version>.exe`
plus `dist/algorid-fetch-setup.exe`. The Windows build uses Qt 6.6 (Windows 10 1809+
and Windows 11), because newer Qt needs a Windows system library that Wine lacks.

### Publishing a release

- Attach `algorid-fetch_all.deb` and `algorid-fetch-setup.exe` to every GitHub release
  under those exact names: the extension's setup page links to
  `releases/latest/download/<name>` and picks the right one for the user's system.
  If the repository is not `gmostafa1210/algorid-fetch`, change `RELEASES` in
  `extension/welcome.js`.
- Chrome Web Store: remove the `"key"` line from `extension/manifest.json` before
  uploading, then add the store's extension ID to `CHROME_EXTENSION_IDS` in
  `algorid_fetch/browsers.py` so the launcher accepts it.

## Security

The app's API listens on `127.0.0.1` only and rejects requests from web pages, so a
website cannot start downloads. Every write needs a token that is generated randomly
on each install and is not part of the source code. The extension receives it only
after you click **Allow** in the app. Settings, history and partial-download state
are stored with owner-only permissions because they can contain cookies.

## Responsible use

Only download content you have the right to download. Respect the terms of the
sites you use and the rights of content owners. Algorid Fetch does not bypass DRM
or other copy protection. Video support relies on yt-dlp, a separate project, which
is fetched from its official releases only when you ask for it.

## License

MIT. See `LICENSE`. Algorid Fetch is an independent project and is not affiliated
with any other download software or its makers.
