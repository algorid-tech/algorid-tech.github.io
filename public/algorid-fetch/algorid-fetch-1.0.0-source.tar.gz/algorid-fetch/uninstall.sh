#!/usr/bin/env bash
# Removes Algorid Fetch program files. Keeps your downloads, settings and history
# unless you pass --purge.
set -euo pipefail
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
systemctl --user disable --now algorid-fetch 2>/dev/null || true
rm -rf "$DATA/algorid-fetch/venv"
rm -f "$HOME"/.config/*/NativeMessagingHosts/com.algorid.fetch.json "$HOME"/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts/com.algorid.fetch.json "$HOME/.mozilla/native-messaging-hosts/com.algorid.fetch.json"
rm -f "$HOME/.local/bin/algorid-fetch" "$HOME/.local/bin/algorid-fetch-native-host" "$DATA/applications/algorid-fetch.desktop" \
      "$DATA/icons/hicolor/scalable/apps/algorid-fetch.svg" "$HOME/.config/autostart/algorid-fetch.desktop" \
      "$HOME/.config/systemd/user/algorid-fetch.service"
if [ "${1:-}" = "--purge" ]; then
  rm -rf "$DATA/algorid-fetch" "${XDG_CONFIG_HOME:-$HOME/.config}/algorid-fetch"
  echo "Algorid Fetch removed, including settings and download history."
else
  echo "Algorid Fetch removed. Settings/history kept (run with --purge to delete them)."
fi
